import asyncio
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from api.cleanup import downloads_cleanup_loop
from common.config import settings
from api.streaming import router as streaming_router

# Routers
from api.routes import admin, engagement, library, lyrics, metadata, overview_social, search, social, subscription, system, tracks, user

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - [%(levelname)s] - %(message)s"
)
logger = logging.getLogger(__name__)

app = FastAPI(title="Hydra Web API")

_cors_origins = [
    o.strip()
    for o in getattr(settings, "CORS_ORIGINS", "http://localhost:5173").split(",")
    if o.strip()
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(system.router)
app.include_router(admin.router, prefix="/api")
app.include_router(search.router, prefix="/api")
app.include_router(tracks.router, prefix="/api")
app.include_router(metadata.router, prefix="/api")
app.include_router(engagement.router, prefix="/api")
app.include_router(library.router, prefix="/api")
app.include_router(user.router, prefix="/api")
app.include_router(overview_social.router, prefix="/api")
app.include_router(subscription.router, prefix="/api")
app.include_router(social.router, prefix="/api")
app.include_router(lyrics.router, prefix="/api")
app.include_router(streaming_router, prefix="/api/stream")


@app.on_event("startup")
async def startup_event():
    asyncio.create_task(downloads_cleanup_loop())


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8005)
