from typing import List, Literal, Optional

from pydantic import BaseModel, Field


class FavoriteToggleRequest(BaseModel):
    track_id: str


class RemoveTracksRequest(BaseModel):
    track_ids: List[str]


class UserSettingsUpdate(BaseModel):
    language: Optional[Literal["uk", "de", "en"]] = None
    silent_mode: Optional[bool] = None
    music_preferences: Optional[dict] = None
    onboarding_completed: Optional[bool] = None
    filter_explicit: Optional[bool] = None


class ListenAnalyticsBody(BaseModel):
    playback_position: Optional[float] = Field(None, ge=0)


class ImportPlaylistRequest(BaseModel):
    url: str
    title: Optional[str] = None
