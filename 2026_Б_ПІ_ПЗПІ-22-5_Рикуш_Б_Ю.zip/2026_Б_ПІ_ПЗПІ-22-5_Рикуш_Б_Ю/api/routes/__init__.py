"""Modular FastAPI routers (included from api.main)."""
