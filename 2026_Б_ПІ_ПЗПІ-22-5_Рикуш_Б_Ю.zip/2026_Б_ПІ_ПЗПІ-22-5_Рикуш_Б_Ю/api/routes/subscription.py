import logging
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_current_user
from common.database import get_db
from common.models import AccountTier, SubscriptionPayment, User

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Subscription"])

PLANS = {
    "free": {"tier": AccountTier.FREE, "price": Decimal("0"), "label": "Free"},
    "plus": {"tier": AccountTier.PLUS, "price": Decimal("99"), "label": "Plus"},
    "premium": {"tier": AccountTier.PREMIUM, "price": Decimal("199"), "label": "Premium"},
}


class CheckoutRequest(BaseModel):
    plan: Literal["plus", "premium"]
    provider: Literal["telegram_stars", "manual"] = "telegram_stars"


class CheckoutConfirm(BaseModel):
    plan: Literal["plus", "premium"]
    transaction_id: Optional[str] = None
    provider: str = "telegram_stars"


@router.get("/subscription/plans")
async def list_plans(_user_id: int = Depends(get_current_user)):
    return {
        "plans": [
            {
                "id": "free",
                "name": "Free",
                "price": 0,
                "currency": "UAH",
                "features": ["R2 streaming", "Basic search", "Playlists"],
            },
            {
                "id": "plus",
                "name": "Plus",
                "price": float(PLANS["plus"]["price"]),
                "currency": "UAH",
                "features": ["Priority queue", "Higher quality", "No ads"],
            },
            {
                "id": "premium",
                "name": "Premium",
                "price": float(PLANS["premium"]["price"]),
                "currency": "UAH",
                "features": ["Local streaming", "Offline to Telegram", "Full quality"],
            },
        ]
    }


@router.get("/subscription/status")
async def subscription_status(
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    user = await db.scalar(select(User).where(User.user_id == user_id))
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    expires = getattr(user, "subscription_expires_at", None)
    return {
        "tier": user.tier.value if hasattr(user.tier, "value") else user.tier,
        "expires_at": expires.isoformat() if expires else None,
        "is_active": user.is_premium or user.tier != AccountTier.FREE,
    }


@router.post("/subscription/checkout")
async def create_checkout(
    body: CheckoutRequest,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    plan = PLANS.get(body.plan)
    if not plan:
        raise HTTPException(status_code=400, detail="Invalid plan")

    return {
        "status": "pending",
        "plan": body.plan,
        "amount": float(plan["price"]),
        "currency": "UAH",
        "provider": body.provider,
        "invoice_payload": f"hydra_sub:{user_id}:{body.plan}",
        "stars_amount": int(plan["price"]),
    }


@router.post("/subscription/confirm")
async def confirm_checkout(
    body: CheckoutConfirm,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    plan = PLANS.get(body.plan)
    if not plan:
        raise HTTPException(status_code=400, detail="Invalid plan")

    user = await db.scalar(select(User).where(User.user_id == user_id))
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.tier = plan["tier"]
    if hasattr(user, "subscription_type"):
        user.subscription_type = body.plan
    if hasattr(user, "subscription_expires_at"):
        user.subscription_expires_at = datetime.now(timezone.utc) + timedelta(days=30)

    payment = SubscriptionPayment(
        user_id=user_id,
        amount=plan["price"],
        currency="UAH",
        plan_type=body.plan,
        payment_provider=body.provider,
        transaction_id=body.transaction_id or f"manual_{user_id}_{body.plan}",
    )
    db.add(payment)
    await db.commit()

    return {
        "status": "ok",
        "tier": user.tier.value if hasattr(user.tier, "value") else user.tier,
        "expires_at": user.subscription_expires_at.isoformat()
        if getattr(user, "subscription_expires_at", None)
        else None,
    }
