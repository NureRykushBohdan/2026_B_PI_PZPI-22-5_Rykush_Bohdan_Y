"""Admin API: компактний дашборд + безпечне прибирання «привидів» consumer у Redis."""

from __future__ import annotations

import json
import logging
import os
import re
from datetime import datetime, timezone
from typing import Any, Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select, text
from sqlalchemy.orm import load_only

from common.analytics import analytics
from common.config import settings
from common.database import AsyncSessionLocal
from common.models import DownloadHistory, GoogleAccount, NetworkNode, Track
from common.redis_client import redis_client

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Admin"])

STREAM_MAIN = redis_client.STREAM_KEY
GROUP = redis_client.GROUP_NAME
STREAM_DE = "hydra:stream:de"
LIST_KEYS = ("metadata_queue", "explore_queue", "tg_send_queue")
EXPLORE_LANGS = ("uk", "en", "de", "ru")
CACHE_KEYS = (
    "cache:new_releases",
    "cache:charts_ua",
    "cache:charts_global",
    "cache:last_update_ts",
    "cache:updating_lock",
)


class GoogleAccountPatch(BaseModel):
    is_active: Optional[bool] = None
    reset_errors: bool = False
    assigned_worker_id: Optional[int] = Field(None, ge=1, le=99)


class NetworkNodePatch(BaseModel):
    name: Optional[str] = Field(None, max_length=255)
    connection_type: Optional[str] = Field(None, max_length=50)
    host: Optional[str] = Field(None, max_length=255)
    port: Optional[int] = Field(None, ge=1, le=65535)


class RefreshExploreBody(BaseModel):
    langs: list[str] = Field(default_factory=lambda: list(EXPLORE_LANGS))


class ClearQueueBody(BaseModel):
    queue: str
    dry_run: bool = True


def _secret_configured(val: Any) -> bool:
    if val is None:
        return False
    if hasattr(val, "get_secret_value"):
        return bool(val.get_secret_value())
    return bool(str(val).strip())

_STALE_CONSUMER_IDLE_MS = 3 * 60 * 1000
# worker_12 / worker_12_abc (старий формат) / worker_12_suffix
_WORKER_CONSUMER_RE = re.compile(r"^worker_(\d+)")


def _require_admin(x_admin_key: Optional[str] = Header(None, alias="X-Admin-Key")) -> None:
    raw = getattr(settings, "ADMIN_API_KEY", None)
    if raw is None:
        return
    expected = (
        raw.get_secret_value()
        if hasattr(raw, "get_secret_value")
        else (str(raw) if raw else "")
    ).strip()
    if not expected:
        return
    if (x_admin_key or "").strip() != expected:
        raise HTTPException(status_code=401, detail="Invalid or missing X-Admin-Key")


async def _ready_bits() -> dict[str, Any]:
    checks: dict[str, Any] = {}
    try:
        async with AsyncSessionLocal() as db:
            await db.execute(text("SELECT 1"))
        checks["database"] = "ok"
    except Exception as e:
        checks["database"] = str(e)
    try:
        await redis_client.redis.ping()
        checks["redis"] = "ok"
    except Exception as e:
        checks["redis"] = str(e)
    checks["ready"] = checks.get("database") == "ok" and checks.get("redis") == "ok"
    return checks


def _charts_updated_at_iso(raw: Any) -> Optional[str]:
    if raw is None:
        return None
    try:
        ts = float(raw)
    except (TypeError, ValueError):
        return None
    try:
        return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()
    except (OSError, OverflowError, ValueError):
        return None


def _summarize_consumers(
    consumers_detail: list[dict[str, Any]],
    *,
    verbose: bool,
) -> dict[str, Any]:
    by_w: dict[int, dict[str, Any]] = {}
    unknown = 0
    flat: list[dict[str, Any]] = []

    for c in consumers_detail:
        name = c.get("name") or ""
        idle = int(c.get("idle_ms", 0) or 0)
        pending = int(c.get("pending", 0) or 0)
        flat.append({"name": name, "pending": pending, "idle_ms": idle})
        m = _WORKER_CONSUMER_RE.match(name)
        if not m:
            unknown += 1
            continue
        wid = int(m.group(1))
        b = by_w.setdefault(
            wid,
            {
                "registered": 0,
                "pending": 0,
                "min_idle_ms": None,
                "stale": 0,
                "recent": 0,
            },
        )
        b["registered"] += 1
        b["pending"] += pending
        if b["min_idle_ms"] is None or idle < b["min_idle_ms"]:
            b["min_idle_ms"] = idle
        if idle > _STALE_CONSUMER_IDLE_MS:
            b["stale"] += 1
        else:
            b["recent"] += 1

    workers = [
        {
            "id": wid,
            "names": b["registered"],
            "pending": b["pending"],
            "idle_ms": b["min_idle_ms"],
            "ghosts": b["stale"],
            "live": b["recent"],
        }
        for wid, b in sorted(by_w.items(), key=lambda x: x[0])
    ]

    out: dict[str, Any] = {
        "registered_total": len(consumers_detail),
        "stale_after_idle_ms": _STALE_CONSUMER_IDLE_MS,
        "workers": workers,
    }
    if unknown:
        out["unknown_consumers"] = unknown
    if verbose:
        flat.sort(key=lambda x: x["idle_ms"])
        out["lowest_idle_sample"] = flat[:10]
    return out


async def _stream_section_redis(stream_key: str, *, verbose: bool) -> Optional[dict[str, Any]]:
    """None, якщо ключа stream немає."""
    r = redis_client.redis
    try:
        info = await r.xinfo_stream(stream_key)
    except Exception as e:
        err = str(e).lower()
        if "no such key" in err or "unknown key" in err:
            return None
        return {"error": str(e)}

    section: dict[str, Any] = {
        "key": stream_key,
        "messages": int(info.get("length", 0)),
        "pending": 0,
        "last_id": None,
        "workers": [],
        "recent_tasks": [],
    }

    try:
        groups = await r.xinfo_groups(stream_key)
    except Exception as e:
        section["groups_error"] = str(e)
        return section

    g0 = groups[0] if groups else None
    gname = g0.get("name") if isinstance(g0, dict) else None
    if isinstance(g0, dict):
        section["pending"] = int(g0.get("pending", 0) or 0)
        section["last_id"] = g0.get("last-delivered-id") or g0.get("last_delivered_id")

    consumers_detail: list[dict[str, Any]] = []
    if gname:
        try:
            cons = await r.xinfo_consumers(stream_key, gname)
            for c in cons:
                if not isinstance(c, dict):
                    continue
                consumers_detail.append(
                    {
                        "name": c.get("name"),
                        "pending": int(c.get("pending", 0) or 0),
                        "idle_ms": int(c.get("idle", 0) or 0),
                    }
                )
        except Exception as e:
            section["consumers_error"] = str(e)

    summary = _summarize_consumers(consumers_detail, verbose=verbose)
    section["registered_consumers"] = summary["registered_total"]
    section["workers"] = summary["workers"]
    section["stale_after_idle_ms"] = summary["stale_after_idle_ms"]
    if summary.get("unknown_consumers"):
        section["unknown_consumers"] = summary["unknown_consumers"]
    if verbose and summary.get("lowest_idle_sample"):
        section["lowest_idle_sample"] = summary["lowest_idle_sample"]

    try:
        rows = await r.xrevrange(stream_key, max="+", min="-", count=10)
        recent: list[dict[str, Any]] = []
        for mid, fields in rows:
            raw = fields.get("data") if isinstance(fields, dict) else None
            item: dict[str, Any] = {}
            if raw:
                try:
                    d = json.loads(raw) if isinstance(raw, str) else raw
                    if isinstance(d, dict):
                        q = d.get("query")
                        if isinstance(q, str):
                            item["query"] = q[:160]
                            m = re.match(r"dl_id:([^:\s]+)", q)
                            if m:
                                item["video_id"] = m.group(1)
                except Exception:
                    pass
            if item:
                recent.append(item)
        section["recent_tasks"] = recent
    except Exception as e:
        section["recent_error"] = str(e)

    return section


async def _active_proc_locks(limit: int = 80) -> list[dict[str, Any]]:
    r = redis_client.redis
    out: list[dict[str, Any]] = []
    cursor = 0
    while True:
        cursor, keys = await r.scan(cursor=cursor, match="proc_lock:*", count=50)
        for k in keys:
            if len(out) >= limit:
                return out
            if not str(k).startswith("proc_lock:"):
                continue
            vid = str(k)[len("proc_lock:") :]
            try:
                holder = await r.get(k)
            except Exception:
                holder = None
            out.append({"video_id": vid, "lock_holder": holder})
        if cursor == 0:
            break
    return out


@router.get("/admin/dashboard")
async def admin_dashboard(
    verbose: bool = Query(False, description="Додати lowest_idle_sample для діагностики"),
    _: None = Depends(_require_admin),
) -> dict[str, Any]:
    now = datetime.now(timezone.utc).isoformat()
    checks = await _ready_bits()
    stats = await analytics.get_stats()

    queues: dict[str, Any] = {}
    for lk in LIST_KEYS:
        try:
            queues[lk] = int(await redis_client.redis.llen(lk))
        except Exception:
            queues[lk] = None

    cache_raw = None
    try:
        cache_raw = await redis_client.redis.get("cache:last_update_ts")
    except Exception:
        pass

    download_stream = await _stream_section_redis(STREAM_MAIN, verbose=verbose)
    if download_stream is None:
        download_stream = {
            "key": STREAM_MAIN,
            "absent": True,
            "messages": 0,
            "pending": 0,
            "workers": [],
            "recent_tasks": [],
        }

    geo_stream = await _stream_section_redis(STREAM_DE, verbose=verbose)
    if (
        geo_stream
        and not geo_stream.get("error")
        and int(geo_stream.get("messages") or 0) == 0
        and int(geo_stream.get("pending") or 0) == 0
    ):
        geo_stream = None

    locks = await _active_proc_locks()

    recent_downloads: list[dict[str, Any]] = []
    try:
        async with AsyncSessionLocal() as session:
            q = (
                select(
                    DownloadHistory.id,
                    DownloadHistory.user_id,
                    DownloadHistory.is_cached,
                    DownloadHistory.source_type,
                    DownloadHistory.created_at,
                    Track.source_id,
                    Track.title,
                    Track.artist,
                )
                .join(Track, DownloadHistory.track_id == Track.track_id)
                .order_by(DownloadHistory.id.desc())
                .limit(25)
            )
            res = await session.execute(q)
            for row in res.mappings():
                recent_downloads.append(
                    {
                        "id": row["id"],
                        "user_id": row["user_id"],
                        "is_cached": row["is_cached"],
                        "source_type": row["source_type"],
                        "created_at": row["created_at"].isoformat()
                        if row["created_at"]
                        else None,
                        "source_id": row["source_id"],
                        "title": row["title"],
                        "artist": row["artist"],
                    }
                )
    except Exception as e:
        logger.warning("admin recent_downloads: %s", e)
        recent_downloads = [{"error": str(e)}]

    google_rows: list[dict[str, Any]] = []
    try:
        async with AsyncSessionLocal() as session:
            q = (
                select(GoogleAccount)
                .options(
                    load_only(
                        GoogleAccount.id,
                        GoogleAccount.email,
                        GoogleAccount.assigned_worker_id,
                        GoogleAccount.is_active,
                        GoogleAccount.error_count,
                        GoogleAccount.last_used_at,
                        GoogleAccount.proxy_label,
                    )
                )
                .order_by(GoogleAccount.assigned_worker_id, GoogleAccount.id)
            )
            res = await session.execute(q)
            for g in res.scalars().all():
                google_rows.append(
                    {
                        "id": g.id,
                        "email": g.email,
                        "worker": g.assigned_worker_id,
                        "active": g.is_active,
                        "errors": g.error_count,
                        "last_used": g.last_used_at.isoformat() if g.last_used_at else None,
                        "proxy": g.proxy_label,
                    }
                )
    except Exception as e:
        logger.warning("admin google_accounts: %s", e)
        google_rows = [{"error": str(e)}]

    nodes: list[dict[str, Any]] = []
    try:
        async with AsyncSessionLocal() as session:
            q = select(NetworkNode).order_by(NetworkNode.worker_id)
            res = await session.execute(q)
            for n in res.scalars():
                nodes.append(
                    {
                        "worker": n.worker_id,
                        "name": n.name,
                        "type": n.connection_type,
                        "host": n.host,
                        "port": n.port,
                    }
                )
    except Exception as e:
        logger.warning("admin network_nodes: %s", e)
        nodes = [{"error": str(e)}]

    return {
        "ts": now,
        "health": checks,
        "stats": stats,
        "queues": queues,
        "charts_updated_at": _charts_updated_at_iso(cache_raw),
        "download_stream": download_stream,
        "geo_stream": geo_stream,
        "locks": locks,
        "recent_downloads": recent_downloads,
        "google_accounts": google_rows,
        "network_nodes": nodes,
    }


@router.post("/admin/redis/prune-ghost-consumers")
async def prune_ghost_consumers(
    min_idle_ms: int = Query(
        600_000,
        ge=60_000,
        le=86_400_000,
        description="Мінімальний idle (мс); лише consumer з pending=0",
    ),
    dry_run: bool = Query(False),
    _: None = Depends(_require_admin),
) -> dict[str, Any]:
    """Видаляє «привиди» XGROUP після рестартів: pending має бути 0 (без втрати задач)."""
    r = redis_client.redis
    try:
        cons = await r.xinfo_consumers(STREAM_MAIN, GROUP)
    except Exception as e:
        err = str(e).lower()
        if "no such key" in err or "nogroup" in err:
            raise HTTPException(status_code=404, detail="stream or group missing") from e
        raise HTTPException(status_code=500, detail=str(e)) from e

    candidates: list[str] = []
    for c in cons:
        if not isinstance(c, dict):
            continue
        name = c.get("name")
        if not name:
            continue
        idle = int(c.get("idle", 0) or 0)
        pending = int(c.get("pending", 0) or 0)
        if pending != 0:
            continue
        if idle < min_idle_ms:
            continue
        candidates.append(str(name))

    if dry_run:
        return {
            "dry_run": True,
            "stream": STREAM_MAIN,
            "group": GROUP,
            "min_idle_ms": min_idle_ms,
            "matched": len(candidates),
            "names_sample": candidates[:60],
        }

    removed_names: list[str] = []
    for name in candidates:
        try:
            await r.xgroup_delconsumer(STREAM_MAIN, GROUP, name)
            removed_names.append(name)
        except Exception as e:
            logger.warning("xgroup_delconsumer %s: %s", name, e)

    return {
        "dry_run": False,
        "stream": STREAM_MAIN,
        "group": GROUP,
        "min_idle_ms": min_idle_ms,
        "matched": len(candidates),
        "removed": len(removed_names),
        "names_sample": removed_names[:60],
    }


@router.get("/admin/ping")
async def admin_ping(_: None = Depends(_require_admin)):
    return {"ok": True}


@router.get("/admin/settings")
async def admin_settings(_: None = Depends(_require_admin)) -> dict[str, Any]:
    """Безпечний знімок runtime-налаштувань (без секретів)."""
    cors = [x.strip() for x in (settings.CORS_ORIGINS or "").split(",") if x.strip()]
    return {
        "runtime": {
            "auth_debug": bool(getattr(settings, "AUTH_DEBUG", False)),
            "admin_key_set": _secret_configured(getattr(settings, "ADMIN_API_KEY", None)),
            "search_api_secret_set": _secret_configured(
                getattr(settings, "SEARCH_API_SECRET", None)
            ),
            "bot_token_set": _secret_configured(getattr(settings, "BOT_TOKEN", None)),
            "telegram_webapp_url": getattr(settings, "TELEGRAM_WEBAPP_URL", "") or "",
            "r2_public_url": getattr(settings, "R2_PUBLIC_URL", "") or "",
            "api_url": getattr(settings, "API_URL", "") or "",
            "cors_origins": cors,
            "admin_id": int(getattr(settings, "ADMIN_ID", 0) or 0),
            "recognize_max_bytes": int(getattr(settings, "RECOGNIZE_MAX_BYTES", 0) or 0),
            "recognize_timeout_sec": float(getattr(settings, "RECOGNIZE_TIMEOUT_SEC", 0) or 0),
            "recognize_rate_limit_per_minute": int(
                getattr(settings, "RECOGNIZE_RATE_LIMIT_PER_MINUTE", 0) or 0
            ),
            "archive_channel_id": int(getattr(settings, "ARCHIVE_CHANNEL_ID", 0) or 0),
            "cf_worker_configured": bool(getattr(settings, "CF_WORKER_URL", None)),
        },
        "worker_env": {
            "hydra_skip_youtube_cookies": os.getenv("HYDRA_SKIP_YOUTUBE_COOKIES", "0"),
            "hydra_vpn_only": os.getenv("HYDRA_VPN_ONLY", ""),
            "ytdlp_socket_timeout": os.getenv("YTDLP_SOCKET_TIMEOUT", ""),
            "stream_key": os.getenv("STREAM_KEY", STREAM_MAIN),
        },
        "redis": {
            "stream_main": STREAM_MAIN,
            "stream_geo": STREAM_DE,
            "consumer_group": GROUP,
            "list_queues": list(LIST_KEYS),
        },
    }


@router.get("/admin/caches")
async def admin_caches(_: None = Depends(_require_admin)) -> dict[str, Any]:
    r = redis_client.redis
    items: list[dict[str, Any]] = []

    for key in CACHE_KEYS:
        entry: dict[str, Any] = {"key": key}
        try:
            exists = await r.exists(key)
            entry["exists"] = bool(exists)
            if exists:
                ttl = await r.ttl(key)
                entry["ttl_sec"] = ttl
                raw = await r.get(key)
                if raw is not None:
                    if key == "cache:last_update_ts":
                        try:
                            entry["value"] = datetime.fromtimestamp(
                                float(raw), tz=timezone.utc
                            ).isoformat()
                        except (TypeError, ValueError, OSError):
                            entry["value"] = str(raw)[:80]
                    elif key == "cache:updating_lock":
                        entry["value"] = str(raw)
                    else:
                        try:
                            parsed = json.loads(raw)
                            if isinstance(parsed, list):
                                entry["items"] = len(parsed)
                            elif isinstance(parsed, dict):
                                entry["items"] = len(parsed)
                        except Exception:
                            entry["bytes"] = len(str(raw))
        except Exception as e:
            entry["error"] = str(e)
        items.append(entry)

    for lang in EXPLORE_LANGS:
        key = f"explore_page_v8:{lang}"
        entry: dict[str, Any] = {"key": key, "lang": lang}
        try:
            exists = await r.exists(key)
            entry["exists"] = bool(exists)
            if exists:
                entry["ttl_sec"] = await r.ttl(key)
        except Exception as e:
            entry["error"] = str(e)
        items.append(entry)

    return {"caches": items, "ts": datetime.now(timezone.utc).isoformat()}


@router.patch("/admin/google-accounts/{account_id}")
async def patch_google_account(
    account_id: int,
    body: GoogleAccountPatch,
    _: None = Depends(_require_admin),
) -> dict[str, Any]:
    async with AsyncSessionLocal() as session:
        q = select(GoogleAccount).where(GoogleAccount.id == account_id)
        res = await session.execute(q)
        acc = res.scalar_one_or_none()
        if not acc:
            raise HTTPException(status_code=404, detail="Google account not found")

        if body.is_active is not None:
            acc.is_active = body.is_active
        if body.reset_errors:
            acc.error_count = 0
        if body.assigned_worker_id is not None:
            acc.assigned_worker_id = body.assigned_worker_id

        await session.commit()
        await session.refresh(acc)
        return {
            "status": "ok",
            "account": {
                "id": acc.id,
                "email": acc.email,
                "worker": acc.assigned_worker_id,
                "active": acc.is_active,
                "errors": acc.error_count,
            },
        }


@router.patch("/admin/network-nodes/{worker_id}")
async def patch_network_node(
    worker_id: int,
    body: NetworkNodePatch,
    _: None = Depends(_require_admin),
) -> dict[str, Any]:
    async with AsyncSessionLocal() as session:
        q = select(NetworkNode).where(NetworkNode.worker_id == worker_id)
        res = await session.execute(q)
        node = res.scalar_one_or_none()
        if not node:
            raise HTTPException(status_code=404, detail="Network node not found")

        if body.name is not None:
            node.name = body.name
        if body.connection_type is not None:
            node.connection_type = body.connection_type
        if body.host is not None:
            node.host = body.host
        if body.port is not None:
            node.port = body.port

        await session.commit()
        await session.refresh(node)
        return {
            "status": "ok",
            "node": {
                "worker": node.worker_id,
                "name": node.name,
                "type": node.connection_type,
                "host": node.host,
                "port": node.port,
            },
        }


@router.post("/admin/jobs/refresh-charts")
async def trigger_refresh_charts(_: None = Depends(_require_admin)) -> dict[str, Any]:
    """Примусово позначити charts/new releases як застарілі — воркер оновить при наступному циклі."""
    r = redis_client.redis
    removed_ts = await r.delete("cache:last_update_ts")
    removed_lock = await r.delete("cache:updating_lock")
    return {
        "status": "queued",
        "message": "cache:last_update_ts скинуто; background updater підхопить оновлення",
        "deleted_last_update_ts": bool(removed_ts),
        "deleted_updating_lock": bool(removed_lock),
    }


@router.post("/admin/jobs/refresh-explore")
async def trigger_refresh_explore(
    body: RefreshExploreBody,
    _: None = Depends(_require_admin),
) -> dict[str, Any]:
    langs = [lang.strip().lower() for lang in body.langs if lang.strip()]
    invalid = [lang for lang in langs if lang not in EXPLORE_LANGS]
    if invalid:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported langs: {invalid}. Allowed: {list(EXPLORE_LANGS)}",
        )
    if not langs:
        langs = list(EXPLORE_LANGS)

    r = redis_client.redis
    queued: list[str] = []
    for lang in langs:
        await r.lpush("explore_queue", json.dumps({"lang": lang}))
        queued.append(lang)

    return {"status": "queued", "langs": queued, "queue": "explore_queue"}


@router.post("/admin/jobs/invalidate-explore-cache")
async def invalidate_explore_cache(
    langs: list[str] = Query(default=[]),
    _: None = Depends(_require_admin),
) -> dict[str, Any]:
    target = langs or list(EXPLORE_LANGS)
    r = redis_client.redis
    deleted: list[str] = []
    for lang in target:
        if lang not in EXPLORE_LANGS:
            continue
        key = f"explore_page_v8:{lang}"
        if await r.delete(key):
            deleted.append(key)
    return {"status": "ok", "deleted": deleted}


@router.post("/admin/queues/clear")
async def clear_list_queue(
    body: ClearQueueBody,
    _: None = Depends(_require_admin),
) -> dict[str, Any]:
    if body.queue not in LIST_KEYS:
        raise HTTPException(
            status_code=400,
            detail=f"Queue must be one of: {list(LIST_KEYS)}",
        )
    r = redis_client.redis
    length = int(await r.llen(body.queue) or 0)
    if body.dry_run:
        return {"dry_run": True, "queue": body.queue, "length": length}
    if length:
        await r.delete(body.queue)
    return {"dry_run": False, "queue": body.queue, "cleared": length}
