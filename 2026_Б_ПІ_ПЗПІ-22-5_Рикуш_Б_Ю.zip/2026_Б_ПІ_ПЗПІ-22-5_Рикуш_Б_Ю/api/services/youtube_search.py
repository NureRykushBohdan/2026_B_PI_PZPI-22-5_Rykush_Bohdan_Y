import asyncio
import logging
import os
from typing import List

import yt_dlp

from common.proxy import pick_proxy_url

logger = logging.getLogger(__name__)


async def search_youtube(query: str, limit: int = 10, page: int = 1) -> List[dict]:
    if not query:
        return []
    start_index = (page - 1) * limit + 1
    end_index = start_index + limit - 1

    def _search_sync():
        ydl_opts = {
            "format": "bestaudio/best",
            "quiet": True,
            "extract_flat": True,
            "force_ipv4": True,
            "ignoreerrors": True,
            "skip_download": True,
            "playlist_items": f"{start_index}-{end_index}",
            "cookiefile": "yt-cookies.txt" if os.path.exists("yt-cookies.txt") else None,
        }
        proxy = pick_proxy_url()
        if proxy:
            ydl_opts["proxy"] = proxy
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            try:
                info = ydl.extract_info(f"ytsearch{end_index}:{query}", download=False)
                if not info:
                    return []
                if "entries" in info:
                    return list(info["entries"])
                return [info]
            except Exception as e:
                logger.error("yt-dlp search failed: %s", e)
                return []

    try:
        entries = await asyncio.get_event_loop().run_in_executor(None, _search_sync)
        results = []
        for entry in entries:
            if not entry:
                continue
            video_id = entry.get("id")
            title = entry.get("title")
            if not video_id or not title:
                continue
            results.append(
                {
                    "id": video_id,
                    "title": title,
                    "artist": entry.get("uploader") or "Unknown",
                    "duration": int(entry.get("duration") or 0),
                    "url": f"https://www.youtube.com/watch?v={video_id}",
                    "cover": f"https://img.youtube.com/vi/{video_id}/mqdefault.jpg",
                    "source": "youtube",
                }
            )
        return results
    except Exception as e:
        logger.error("Search error: %s", e)
        return []
