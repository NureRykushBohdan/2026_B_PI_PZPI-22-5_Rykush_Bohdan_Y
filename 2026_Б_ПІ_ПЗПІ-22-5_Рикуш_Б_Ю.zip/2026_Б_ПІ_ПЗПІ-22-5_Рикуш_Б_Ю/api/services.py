# api/services.py
from datetime import date
from sqlalchemy.ext.asyncio import AsyncSession
from common.models import User

# Налаштування лімітів
LIMITS = {
    "free": 0,
    "plus": 10,
    "premium": 50
}

async def check_and_update_limits(user: User, db: AsyncSession) -> bool:
    """
    Перевіряє, чи має користувач право на миттєве завантаження (Fast Stream).
    Автоматично скидає лічильник, якщо настав новий день.
    НЕ інкрементує лічильник (це робимо тільки після успішного старту).
    """
    today = date.today()

    # 1. Скидання лічильника, якщо новий день
    if user.last_activity_date != today:
        user.fast_downloads_today = 0
        user.last_activity_date = today
        await db.commit()
        await db.refresh(user)

    # 2. Перевірка прав
    user_limit = LIMITS.get(user.subscription_type, 0)
    
    # Якщо ліміт не вичерпано -> Дозволяємо (True)
    if user.fast_downloads_today < user_limit:
        return True
    
    return False

async def increment_fast_counter(user: User, db: AsyncSession):
    """Збільшує лічильник використаних завантажень"""
    user.fast_downloads_today += 1
    await db.commit()