"""Feature roadmap initial schema extensions

Revision ID: 001_feature_roadmap
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "001_feature_roadmap"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "users",
        sa.Column("music_preferences", postgresql.JSONB(), server_default=sa.text("'{}'::jsonb"), nullable=True),
    )
    op.add_column(
        "users",
        sa.Column("onboarding_completed", sa.Boolean(), server_default=sa.text("false"), nullable=True),
    )
    op.add_column(
        "users",
        sa.Column("filter_explicit", sa.Boolean(), server_default=sa.text("false"), nullable=True),
    )
    op.add_column(
        "listening_history",
        sa.Column("playback_position", sa.Float(), server_default=sa.text("0"), nullable=True),
    )
    op.create_table(
        "playlist_collaborators",
        sa.Column("playlist_id", sa.Integer(), sa.ForeignKey("playlists.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("user_id", sa.BigInteger(), sa.ForeignKey("users.user_id", ondelete="CASCADE"), primary_key=True),
        sa.Column("role", sa.String(20), server_default="editor"),
        sa.Column("invited_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("idx_playlist_collab_user", "playlist_collaborators", ["user_id"])
    op.create_table(
        "user_follows",
        sa.Column("follower_id", sa.BigInteger(), sa.ForeignKey("users.user_id", ondelete="CASCADE"), primary_key=True),
        sa.Column("following_id", sa.BigInteger(), sa.ForeignKey("users.user_id", ondelete="CASCADE"), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("idx_user_follows_following", "user_follows", ["following_id"])
    op.create_index("idx_listening_user_track", "listening_history", ["user_id", "track_source_id"])


def downgrade() -> None:
    op.drop_index("idx_listening_user_track", table_name="listening_history")
    op.drop_index("idx_user_follows_following", table_name="user_follows")
    op.drop_table("user_follows")
    op.drop_index("idx_playlist_collab_user", table_name="playlist_collaborators")
    op.drop_table("playlist_collaborators")
    op.drop_column("listening_history", "playback_position")
    op.drop_column("users", "filter_explicit")
    op.drop_column("users", "onboarding_completed")
    op.drop_column("users", "music_preferences")
