import json
import logging
import aiohttp 
import asyncio
import os
import yt_dlp 
import uuid
import time
import datetime
import redis.asyncio as redis
from aiogram import Bot, types
from typing import List, Optional, Union, Dict, Any
from sqlalchemy import select, update, desc, delete, or_, and_
from sqlalchemy.sql import func
from worker.cookie_sync import INTERNAL_COOKIE_PATH, load_worker_google_session
from worker.utils import (
    env_truthy,
    find_downloaded_m4a,
    merge_ytdlp_browser_identity,
    safe_remove,
    ydl_socket_timeout,
    ytdlp_extract_info,
    yt_watch_url,
)
from ytmusicapi import YTMusic
from aiogram.types import FSInputFile
import shutil
from common.texts import get_text
import random
from sqlalchemy.dialects.postgresql import insert as pg_insert
from common.models import Track, User, UserPlaylist, Playlist, PlaylistTrack, ListeningHistory, AccountTier, GoogleAccount,CachedContent
from common.redis_client import redis_client
from common.schemas import DownloadTask, TrackSearchResult, TrackDetails, CreatePlaylist, PlaylistSchema
from common.database import AsyncSessionLocal
from common.config import settings
from common.proxy import has_proxy_configured, pick_proxy_url
from common.explore import get_cached_explore, fetch_explore_data_sync, SECTION_TITLES, fetch_smart_genre_tracks_sync, fetch_new_releases_sync, fetch_album_details_sync, fetch_playlist_details_sync, fetch_artist_details_sync
from common.analytics import analytics

WORKER_ID = int(os.getenv("WORKER_ID", "1"))
CURRENT_WORKER_ID = WORKER_ID 
# Стабільне ім'я consumer (без випадкового суфікса) — інакше кожен рестарти = новий рядок у Redis,
# pending лишаються на «мертвих» іменах, blacklist у адмінці роздувається.
# Якщо потрібні два процеси з однаковим WORKER_ID на один Redis — задайте HYDRA_STREAM_CONSUMER_SUFFIX.
_consumer_suffix = os.getenv("HYDRA_STREAM_CONSUMER_SUFFIX", "").strip()
if _consumer_suffix:
    CONSUMER_NAME = f"worker_{WORKER_ID}_{_consumer_suffix}"
else:
    CONSUMER_NAME = f"worker_{WORKER_ID}"
INTERNAL_COOKIE_PATH = f"/app/cookies_worker_{WORKER_ID}.txt"
DOWNLOAD_DIR = "/app/downloads"
STREAM_KEY = os.getenv("STREAM_KEY", "hydra:stream")

# Після синхронізації куків з БД — той самий User-Agent, що під час збору сесії в браузері.
WORKER_YTDLP_USER_AGENT: Optional[str] = None


class LockBusyRetry(Exception):
    """Інший воркер тримає proc_lock; задачу треба повторно поставити в чергу."""


def _merge_ytdlp_browser_identity(opts: Dict[str, Any]) -> None:
    merge_ytdlp_browser_identity(opts, WORKER_YTDLP_USER_AGENT)


def _use_youtube_cookies_from_db() -> bool:
    """Якщо HYDRA_SKIP_YOUTUBE_COOKIES=1 — не читаємо куки з БД і не даємо їх yt-dlp (протухлі ламають завантаження)."""
    return not env_truthy("HYDRA_SKIP_YOUTUBE_COOKIES", False)


# ios InnerTube часто дає 400 «Precondition check failed» з VPN/датацентрів; застарілий yt-dlp
# ламає signature на mweb. Клієнти задаємо завжди (і з cookies, і без).
_YOUTUBE_EXTRACTOR_ARGS = {
    "extractor_args": {
        "youtube": {
            "player_client": ["android", "web", "mweb"],
        }
    }
}

# Повільні SOCKS/VPN: без цього extract_info лишається на дефолті ~20 с (timeout у логах).
_YDL_NET = {"socket_timeout": ydl_socket_timeout()}


async def _google_account_assigned_to_this_worker() -> bool:
    async with AsyncSessionLocal() as session:
        gid = await session.scalar(
            select(GoogleAccount.id)
            .where(
                GoogleAccount.assigned_worker_id == WORKER_ID,
                GoogleAccount.is_active.is_(True),
            )
            .limit(1)
        )
    return gid is not None


# Налаштування логування
logging.basicConfig(level=logging.INFO, format="%(asctime)s - [%(levelname)s] - %(message)s")
logger = logging.getLogger(__name__)


def _track_playable_r2_url(t: Track) -> Optional[str]:
    """Публічна URL для перевірки наявності об'єкта в R2 (як у API)."""
    u = (getattr(t, "r2_url", None) or "").strip()
    if u.startswith(("http://", "https://")):
        return u
    base = (settings.R2_PUBLIC_URL or "").strip().rstrip("/")
    key = (getattr(t, "r2_key", None) or "").strip().lstrip("/")
    if base and key:
        return f"{base}/{key}"
    return None


async def _r2_url_alive(url: str) -> bool:
    if not url:
        return False
    timeout = aiohttp.ClientTimeout(total=12)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.head(url, allow_redirects=True) as resp:
                if resp.status == 200:
                    return True
                if resp.status == 404:
                    return False
            async with session.get(
                url,
                headers={"Range": "bytes=0-0"},
                allow_redirects=True,
            ) as resp2:
                return resp2.status in (200, 206)
    except Exception as e:
        logger.debug("R2 reachability check failed %s: %s", url[:100], e)
        return False


# Підключаємо стрімінг (для перемотування)

MAX_RETRIES = 3
FILE_SIZE_LIMIT_MB = 49 

if not os.path.exists(DOWNLOAD_DIR):
    os.makedirs(DOWNLOAD_DIR)
 
bot = Bot(token=settings.BOT_TOKEN.get_secret_value())



async def get_track_kb(track_id, user_id, lang):
    return None

async def update_account_activity(account_id):
    async with AsyncSessionLocal() as session:
        await session.execute(
            update(GoogleAccount)
            .where(GoogleAccount.id == account_id)
            .values(last_used_at=func.now())
        )
        await session.commit()

async def get_account_context():
    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(GoogleAccount)
            .where(GoogleAccount.assigned_worker_id == CURRENT_WORKER_ID)
            .where(GoogleAccount.is_active == True)
            .order_by(func.random())
            .limit(1)
        )
        account = result.scalar_one_or_none()
    
    if not account:
        logging.warning(f"⚠️ Воркер {CURRENT_WORKER_ID}: Немає активних акаунтів!")
        return None, None

    temp_cookie_path = f"/tmp/cookie_w{CURRENT_WORKER_ID}_{uuid.uuid4()}.txt"
    with open(temp_cookie_path, "w") as f:
        f.write(account.cookie_content)
    
    logging.info(f"👤 Воркер {CURRENT_WORKER_ID} взяв акаунт: {account.email}")
    return account, temp_cookie_path

async def find_alternative_track(original_id: str, proxy_url: str = None) -> Optional[str]:
    logger.info(f"🕵️‍♂️ Searching alternative for: {original_id}")
    loop = asyncio.get_event_loop()
    try:
        # Спроба отримати назву через API
        def get_meta():
            try: return YTMusic(proxies={'http': proxy_url, 'https': proxy_url} if proxy_url else None).get_song(original_id)
            except: return None
        
        meta = await loop.run_in_executor(None, get_meta)
        search_query = ""
        if meta and 'videoDetails' in meta:
            title = meta['videoDetails'].get('title')
            artist = meta['videoDetails'].get('author')
            if title: search_query = f"{artist} - {title} audio" if artist else f"{title} audio"
        
        # Fallback через oembed
        if not search_query:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v={original_id}&format=json") as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        search_query = data.get("title", "")

        if not search_query: return None

        logger.info(f"🔍 Searching replacement for: '{search_query}'")
        ydl_opts = {
            'quiet': True,
            'default_search': 'ytsearch1',
            'noplaylist': True,
            **_YDL_NET,
            **_YOUTUBE_EXTRACTOR_ARGS,
        }
        if proxy_url:
            ydl_opts['proxy'] = proxy_url
        _merge_ytdlp_browser_identity(ydl_opts)

        search_results = await loop.run_in_executor(
            None,
            ytdlp_extract_info,
            search_query,
            ydl_opts,
        )
        if 'entries' in search_results and search_results['entries']:
            new_id = search_results['entries'][0]['id']
            if new_id != original_id:
                logger.info(f"✅ Found alternative: {new_id}")
                return new_id
    except Exception as e:
        logger.error(f"⚠️ Alternative search failed: {e}")
    return None
def fetch_charts_robust_sync(country='US'):
    """
    Надійна функція для отримання чартів.
    1. Пробує динамічні чарти.
    2. Якщо пусто -> бере офіційний плейлист Top 100.
    """
    logger.info(f"📊 [Charts] Requesting charts for country: {country}")
    proxy_url = pick_proxy_url()
    proxies = {'http': proxy_url, 'https': proxy_url} if proxy_url else None
    
    # Офіційні плейлисти чартів (Backup Plan)
    # Global Top 100: PL4fGSI1pDJn5kI81J1fYWK5eZrde1SbeB
    # UA Top 100: PL4fGSI1pDJn6O1LS0XSdF3RyO0Rq_LDeI
    # US Top 100: PL4fGSI1pDJn5BzxiM2ns_oAHmsHjN9zO0
    
    BACKUP_PLAYLISTS = {
        'ZZ': 'PL4fGSI1pDJn5kI81J1fYWK5eZRl1zJ5kM',
        'US': 'PL4fGSI1pDJn61unMfmrUSz68RT8IFFnks',
        'UA': 'PL4fGSI1pDJn6O1LS0XSdF3RyO0Rq_LDeI'
    }

    countries_to_try = [country]
    if country != 'ZZ': countries_to_try.append('ZZ')
    if country != 'US' and country != 'ZZ': countries_to_try.append('US')

    yt = None
    try:
        yt = YTMusic(language='en', proxies=proxies)
    except Exception as e:
        logger.error(f"❌ [Charts] Init failed: {e}")
        return []

    # Try dynamic charts per region
    for c_code in countries_to_try:
        try:
            logger.info(f"   ... trying region '{c_code}'")
            charts = yt.get_charts(country=c_code)
            source_items = []
            
            # Шукаємо songs/videos/trending
            for key in ['songs', 'videos', 'trending', 'weekly', 'daily']:
                if key in charts and isinstance(charts[key], dict) and charts[key].get('items'):
                    source_items = charts[key]['items']
                    logger.info(f"   -> Found direct items in '{key}' ({c_code})")
                    break

            if source_items:
                # Парсинг (спрощений)
                items = []
                for item in source_items:
                    try:
                        v_id = item.get('videoId')
                        if not v_id: continue
                        
                        artists = item.get('artists', [])
                        artist = artists[0]['name'] if artists else 'Unknown'
                        thumbnails = item.get('thumbnails', [])
                        cover = thumbnails[-1]['url'] if thumbnails else ""
                        
                        items.append({
                            "id": v_id,
                            "title": item.get('title', 'Unknown'),
                            "artist": artist,
                            "cover": cover,
                            "type": "song",
                            "source": "youtube"
                        })
                    except: continue
                
                if items:
                    logger.info(f"✅ [Charts] Fetched {len(items)} items from dynamic chart")
                    return items

        except Exception:
            continue

    logger.warning(f"⚠️ [Charts] All dynamic charts failed for {country}. Using BACKUP PLAYLIST.")
    
    backup_pl_id = BACKUP_PLAYLISTS.get(country, BACKUP_PLAYLISTS['ZZ'])
    try:
        logger.info(f"   -> Fetching Backup Playlist: {backup_pl_id}")
        pl_data = yt.get_playlist(backup_pl_id, limit=50)
        
        if pl_data and 'tracks' in pl_data:
            items = []
            for track in pl_data['tracks']:
                try:
                    v_id = track.get('videoId')
                    if not v_id: continue
                    
                    artists = track.get('artists', [])
                    artist = artists[0]['name'] if artists else 'Unknown'
                    thumbnails = track.get('thumbnails', [])
                    cover = thumbnails[-1]['url'] if thumbnails else ""

                    items.append({
                        "id": v_id,
                        "title": track.get('title', 'Unknown'),
                        "artist": artist,
                        "cover": cover,
                        "type": "song",
                        "source": "youtube"
                    })
                except: continue
            
            logger.info(f"✅ [Charts] Fetched {len(items)} items from Backup Playlist")
            return items

    except Exception as e:
        logger.error(f"❌ [Charts] Backup Playlist failed: {e}")

    return []
    
async def save_track_to_db_v2(
    track_data, file_id, r2_key, r2_public_url: Optional[str] = None
):
    async with AsyncSessionLocal() as session:
        try:
            r2_base = getattr(settings, "R2_PUBLIC_URL", "").strip().rstrip("/")
            full_r2_url = (r2_public_url or "").strip() or None
            if not full_r2_url and r2_key and r2_base:
                full_r2_url = f"{r2_base}/{str(r2_key).lstrip('/')}"
            
            # Зберігаємо і оригінал, і реальне джерело
            ids_to_save = {track_data['source_id']} 
            if track_data.get('real_source_id'):
                ids_to_save.add(track_data['real_source_id'])

            saved_primary_id = None

            for sid in ids_to_save:
                t = await session.scalar(select(Track).where(Track.source_id == sid))
                if t:
                    t.title = track_data['title']
                    t.artist = track_data['artist']
                    t.telegram_file_id = file_id
                    if r2_key:
                        t.r2_key = r2_key
                    if full_r2_url:
                        t.r2_url = full_r2_url
                else:
                    new_track = Track(
                        title=track_data['title'], artist=track_data['artist'], duration=track_data['duration'],
                        source_url=f"https://www.youtube.com/watch?v={sid}", source_id=sid,
                        telegram_file_id=file_id, r2_key=r2_key, r2_url=full_r2_url,
                        cover_big=track_data['cover_big'], cover_small=track_data['cover_big']
                    )
                    session.add(new_track)
                    if sid == track_data['source_id']:
                        await session.flush()
                        saved_primary_id = new_track.track_id
                
                if t and sid == track_data['source_id']: saved_primary_id = t.track_id

            await session.commit()
            return saved_primary_id
        except Exception as e:
            logging.error(f"DB Error: {e}")
            return None

def progress_hook(d):
    """Хук для виводу прогресу завантаження в логи."""
    if d['status'] == 'downloading':
        # Щоб не спамити логами, виводимо тільки коли завантажили шматочок
        # d['_percent_str'] показує відсоток, d['filename'] - куди пишемо
        try:
            percent = d.get('_percent_str', '0%').strip('%')
            # Логуємо старт (перші байти) та кожні ~20%
            if float(percent) < 0.5 or float(percent) % 20.0 < 0.5:
                logging.info(f"⏳ Loading... {d.get('_percent_str')} | Size: {d.get('_total_bytes_str', 'N/A')} | Speed: {d.get('_speed_str', 'N/A')} | File: {d.get('filename')}")
        except:
            pass # Ігноруємо помилки парсингу
    elif d['status'] == 'finished':
        logging.info("✅ Download phase finished. Starting conversion (if needed)...")

async def download_track_by_id(youtube_id: str) -> Dict[str, Any]:
    logger.info(f"📥 Starting download: {youtube_id}")
    
    orig_path = os.path.join(DOWNLOAD_DIR, f"{youtube_id}.m4a")
    proxy_url = pick_proxy_url()
    cookiefile = (
        INTERNAL_COOKIE_PATH
        if _use_youtube_cookies_from_db() and os.path.exists(INTERNAL_COOKIE_PATH)
        else None
    )
    ydl_opts_info: Dict[str, Any] = {'quiet': True, **_YDL_NET, **_YOUTUBE_EXTRACTOR_ARGS}
    if cookiefile:
        ydl_opts_info['cookiefile'] = cookiefile
    if proxy_url:
        ydl_opts_info['proxy'] = proxy_url
    _merge_ytdlp_browser_identity(ydl_opts_info)

    download_id = youtube_id
    real_source_id = youtube_id
    final_disk_path = os.path.join(DOWNLOAD_DIR, f"{download_id}.m4a")

    loop = asyncio.get_running_loop()
    info = None
    watch_url = yt_watch_url(youtube_id)

    def _extract_meta(url: str):
        return ytdlp_extract_info(url, ydl_opts_info)

    try:
        info = await loop.run_in_executor(None, _extract_meta, watch_url)
    except Exception as e:
        error_msg = str(e).lower()
        if "video unavailable" in error_msg or "not available" in error_msg:
            logger.warning(f"⛔ Track {youtube_id} unavailable. Initiating Self-Healing...")
            alternative_id = await find_alternative_track(youtube_id, proxy_url)
            
            if alternative_id:
                logger.info(f"🔄 Swapping {youtube_id} -> {alternative_id}")
                real_source_id = alternative_id
                
                async with AsyncSessionLocal() as session:
                    existing = await session.scalar(select(Track).where(Track.source_id == alternative_id))
                    if existing and (existing.r2_url or existing.r2_key):
                        logger.info(f"💎 Alternative found in DB!")
                        return {
                            'status': 'db_hit', 'source_id': youtube_id, 'real_source_id': alternative_id,
                            'track_obj': existing, 'title': existing.title, 'artist': existing.artist,
                            'duration': existing.duration, 'cover_big': existing.cover_big
                        }

                download_id = alternative_id
                final_disk_path = os.path.join(DOWNLOAD_DIR, f"{download_id}.m4a")
                
                if os.path.exists(final_disk_path) and os.path.getsize(final_disk_path) > 1024:
                    logger.info("⚡ Using existing local alternative file.")
                try:
                    info = await loop.run_in_executor(
                        None, _extract_meta, yt_watch_url(download_id)
                    )
                except Exception as ex:
                    raise ex
            else:
                raise e
        else:
            raise e

    if not info:
        raise RuntimeError("No track info")

    artist = info.get('artist') or info.get('uploader') or 'Unknown'
    track_data = {
        'status': 'downloaded',
        'path': orig_path,
        'title': info.get('title', 'Unknown'),
        'artist': artist,
        'duration': info.get('duration', 0),
        'source_id': youtube_id,
        'real_source_id': real_source_id,
        'source_url': watch_url,
        'cover_big': info.get('thumbnail', '')
    }

    if os.path.exists(orig_path) and os.path.getsize(orig_path) > 1024:
        return track_data
    if (
        final_disk_path != orig_path
        and os.path.exists(final_disk_path)
        and os.path.getsize(final_disk_path) > 1024
    ):
        shutil.copy2(final_disk_path, orig_path)
        return track_data

    try:
        # outtmpl ЗАВЖДИ за download_id (ід потоку, який реально качається) — інакше self-healing писав не туди
        ydl_opts_dl: Dict[str, Any] = {
            'format': 'bestaudio[ext=m4a]/bestaudio/best',
            'outtmpl': os.path.join(DOWNLOAD_DIR, f"{download_id}.%(ext)s"),
            'force_ipv4': True,
            'socket_timeout': ydl_socket_timeout(),
            'retries': 10,
            'fragment_retries': 10,
            'file_access_retries': 3,
            'max_filesize': 50 * 1024 * 1024,
            'playlist_items': '1',
            'noplaylist': True,
            'quiet': True,
            'nopart': True,
            'nocheckcertificate': True,
            'progress_hooks': [progress_hook],
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'm4a',
            }],
        }
        if cookiefile:
            ydl_opts_dl['cookiefile'] = cookiefile
        if proxy_url:
            ydl_opts_dl['proxy'] = proxy_url
        ydl_opts_dl = {**_YOUTUBE_EXTRACTOR_ARGS, **ydl_opts_dl}
        _merge_ytdlp_browser_identity(ydl_opts_dl)

        def _run_download():
            with yt_dlp.YoutubeDL(ydl_opts_dl) as ydl_dl:
                ydl_dl.download([yt_watch_url(download_id)])

        await loop.run_in_executor(None, _run_download)

        produced = find_downloaded_m4a(download_id, DOWNLOAD_DIR)
        if not produced:
            raise RuntimeError(f"No audio file on disk after download (id={download_id})")

        if produced != orig_path:
            shutil.copy2(produced, orig_path)

        track_data['path'] = orig_path
        if os.path.exists(orig_path) and os.path.getsize(orig_path) > 1024:
            logger.info("✅ Download complete → %s", orig_path)
            return track_data
        raise RuntimeError("Copy to orig_path failed or file too small")

    except Exception as e:
        logger.error(f"❌ Download error: {e}")
        safe_remove(final_disk_path)
        if download_id != youtube_id:
            safe_remove(os.path.join(DOWNLOAD_DIR, f"{youtube_id}.m4a"))
        safe_remove(orig_path)
        raise


async def background_updater():
    """
    Фоновий процес: оновлює Чарти (UA + Global) та Новинки.
    Використовує Redis Lock, щоб працював ТІЛЬКИ ОДИН воркер.
    """
    logger.info("🕰️ Background Updater initialized (Waiting for slot...)")
    
    # Випадкова затримка на старті
    await asyncio.sleep(random.randint(10, 60))
    
    UPDATE_INTERVAL = 6 * 3600 # 6 годин

    while True:
        try:
            # 1. Перевіряємо актуальність даних
            last_update_ts = await redis_client.redis.get("cache:last_update_ts")
            
            is_stale = True
            if last_update_ts:
                elapsed = time.time() - float(last_update_ts)
                if elapsed < UPDATE_INTERVAL:
                    is_stale = False
            
            if not is_stale:
                await asyncio.sleep(600) 
                continue

            # 2. Пробуємо захопити лідерство
            acquired_lock = await redis_client.redis.set("cache:updating_lock", "locked", ex=300, nx=True)
            
            if not acquired_lock:
                logger.info("🔒 Update in progress by another worker. I'll wait.")
                await asyncio.sleep(60)
                continue

            # Leader election
            logger.info("👑 I am the Leader! Updating Charts & New Releases...")
            start_time = time.time()

            # 3. Чарти UA (Україна)
            charts_ua = await asyncio.to_thread(fetch_charts_robust_sync, 'UA')
            if charts_ua:
                await redis_client.redis.set("cache:charts_ua", json.dumps(charts_ua))
                logger.info(f"✅ UA Charts updated ({len(charts_ua)} items)")
            else:
                logger.warning("⚠️ UA Charts returned empty!")

            charts_global = await asyncio.to_thread(fetch_charts_robust_sync, 'US')
            if charts_global:
                await redis_client.redis.set("cache:charts_global", json.dumps(charts_global))
                logger.info(f"✅ Global Charts updated ({len(charts_global)} items)")
            else:
                logger.warning("⚠️ Global Charts returned empty!")
            
            # 4. Новинки
            new_releases = await asyncio.to_thread(fetch_new_releases_sync)
            if new_releases:
                await redis_client.redis.set("cache:new_releases", json.dumps(new_releases))
                logger.info(f"✅ New Releases updated ({len(new_releases)} items)")
            
            # 5. Оновлюємо час
            await redis_client.redis.set("cache:last_update_ts", time.time())
            await redis_client.redis.delete("cache:updating_lock")
            
            duration = time.time() - start_time
            logger.info(f"🏁 Update finished in {duration:.2f}s. Sleeping for 6 hours...")
            
            await asyncio.sleep(UPDATE_INTERVAL)
            
        except Exception as e:
            logger.error(f"❌ Background Update Error: {e}")
            await redis_client.redis.delete("cache:updating_lock")
            await asyncio.sleep(60)

async def search_tracks(query: str, chat_id: int, message_id: int, lang: str = 'en'):
    # 1. Шукаємо 20 результатів замість 4
    search_identifier = f"ytsearch20:{query}"
    proxy_url = pick_proxy_url()

    ydl_opts = {
        'extract_flat': 'in_playlist',
        'dump_single_json': True,
        'quiet': True,
        'simulate': True,
        'skip_download': True,
        **_YDL_NET,
        **_YOUTUBE_EXTRACTOR_ARGS,
    }
    if proxy_url:
        ydl_opts['proxy'] = proxy_url
    _merge_ytdlp_browser_identity(ydl_opts)

    loop = asyncio.get_event_loop()
    try:
        logging.info(f"🔍 Internet Search: {query}")
        info = await loop.run_in_executor(
            None,
            ytdlp_extract_info,
            search_identifier,
            ydl_opts,
        )

        if not info or 'entries' not in info or not info['entries']:
            try:
                if message_id:
                    await bot.delete_message(chat_id, message_id)
            except Exception:
                pass
            await bot.send_message(chat_id, get_text(lang, 'nothing_found'))
            return

        # 2. Формуємо список результатів
        raw_results = []
        ids_to_check = []

        for entry in info['entries']:
            if not entry.get('id'):
                continue

            # Додаємо в список ID для перевірки в базі
            ids_to_check.append(entry['id'])

            raw_results.append({
                'id': entry['id'],
                'title': entry.get('title', 'Unknown'),
                'duration': entry.get('duration', 0),
                'uploader': entry.get('uploader', 'Unknown'),
                'cached': False  # За замовчуванням
            })

        # Batch cache lookup in DB
        if ids_to_check:
            async with AsyncSessionLocal() as session:
                # Шукаємо які з цих ID вже є в таблиці tracks
                stmt = select(Track.source_id).where(Track.source_id.in_(ids_to_check))
                result = await session.execute(stmt)
                existing_ids = set(row[0] for row in result.all())

            # Оновлюємо статус cached
            for item in raw_results:
                if item['id'] in existing_ids:
                    item['cached'] = True

        # 3. Зберігаємо в Redis (вже з прапорцем cached)
        redis_key = f"web_search:{chat_id}"
        await redis_client.redis.set(redis_key, json.dumps(raw_results), ex=3600)

        if message_id:
            try:
                await bot.delete_message(chat_id, message_id)
            except Exception:
                pass

        # 4. Будуємо першу сторінку
        keyboard_buttons = []
        page_0 = raw_results[:10]

        for item in page_0:
            icon = "⚡" if item['cached'] else "🎵"
            label = item['title']
            if len(label) > 50:
                label = label[:47] + "..."

            keyboard_buttons.append([
                types.InlineKeyboardButton(text=f"{icon} {label}", callback_data=f"dl_id:{item['id']}")
            ])

        if len(raw_results) > 10:
            nav_row = []
            # Кнопка сторінки з ignore
            nav_row.append(types.InlineKeyboardButton(text=f"📄 1", callback_data="ignore"))
            nav_row.append(types.InlineKeyboardButton(text="Вперед ➡️", callback_data="web_page:1"))
            keyboard_buttons.append(nav_row)

        keyboard = types.InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)

        await bot.send_message(
            chat_id,
            f"🌍 **Результати з інтернету:** `{query}`\nОберіть трек:",
            reply_markup=keyboard,
            parse_mode="Markdown"
        )

    except Exception as e:
        logging.error(f"Search Error: {e}", exc_info=True)
        try:
            if message_id:
                await bot.delete_message(chat_id, message_id)
        except Exception:
            pass
        try:
            await bot.send_message(
                chat_id,
                get_text(lang, "search_failed"),
            )
        except Exception:
            pass

async def save_track_to_db(track_info, file_id, r2_key):
    async with AsyncSessionLocal() as session:
        try:
            # Отримуємо URL безпечно (якщо налаштування немає - буде None)
            r2_base = getattr(settings, "R2_PUBLIC_URL", "") 
            full_r2_url = f"{r2_base}/{r2_key}" if r2_key and r2_base else None

            t = await session.scalar(select(Track).where(Track.source_id == track_info['source_id']))

            if t:
                t.title = track_info['title']
                t.artist = track_info['artist']
                t.duration = track_info['duration']
                t.telegram_file_id = file_id
                if r2_key: 
                    t.r2_key = r2_key
                    t.r2_url = full_r2_url
            else:
                new_track = Track(
                    title=track_info['title'],
                    artist=track_info['artist'],
                    duration=track_info['duration'],
                    source_url=track_info['source_url'],
                    source_id=track_info['source_id'],
                    telegram_file_id=file_id,
                    r2_key=r2_key,
                    r2_url=full_r2_url,
                    cover_big=track_info['cover_big'],
                    cover_small=track_info['cover_big']
                )
                session.add(new_track)
            await session.commit()
            # Повертаємо ID для логування
            return t.track_id if t else new_track.track_id
        except Exception as e:
            logging.error(f"DB Error (save_track_to_db): {e}")
            return None

async def fetch_recommendations(youtube_id: str):
    import re
    proxy_url = pick_proxy_url()
    proxies = {'http': proxy_url, 'https': proxy_url} if proxy_url else None
    
    logging.info(f"📻 {WORKER_ID}: Fetching recommendations for {youtube_id}")
    loop = asyncio.get_event_loop()
    
    def _get_sync():
        ytm = YTMusic(proxies=proxies)
        return ytm.get_watch_playlist(videoId=youtube_id, limit=10)

    try:
        watch_list = await loop.run_in_executor(None, _get_sync)
        if not watch_list or 'tracks' not in watch_list: return []

        recommendations = []
        for item in watch_list['tracks']:
            if not item.get('videoId') or item.get('videoId') == youtube_id: continue
            
            thumbnails = item.get('thumbnails', [])
            if thumbnails:
                cover_url = thumbnails[-1]['url']
                if "googleusercontent" in cover_url or "ggpht" in cover_url:
                    cover_url = re.sub(r'=w\d+-h\d+', '=w1200-h1200', cover_url)
            else:
                cover_url = f"https://img.youtube.com/vi/{item['videoId']}/hqdefault.jpg"

            recommendations.append({
                "id": item['videoId'],
                "title": item['title'],
                "artist": item['artists'][0]['name'] if item.get('artists') else "Unknown",
                "duration": item.get('duration_seconds', 0),
                "cover": cover_url,
                "url": f"https://www.youtube.com/watch?v={item['videoId']}",
                "source": "youtube"
            })
        return recommendations
    except Exception as e:
        logging.error(f"❌ {WORKER_ID} Recommendations Error: {e}")
        return []
    
async def trigger_r2_cloud_upload(
    telegram_path: str, filename_key: str,
) -> Optional[Dict[str, Any]]:
    """
    Завантажує файл з Telegram-шляху в R2 через CF worker.
    Повертає {"r2_key", "r2_url"} щоб записати в БД публічну URL (важливо, коли R2_PUBLIC_URL порожній).
    """
    if not settings.CF_WORKER_URL or not settings.CF_WORKER_SECRET:
        return None

    params = {
        "secret": settings.CF_WORKER_SECRET.get_secret_value(),
        "path": telegram_path,
        "name": filename_key,
    }

    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(settings.CF_WORKER_URL, params=params) as response:
                text = await response.text()
                if response.status == 200:
                    try:
                        data = json.loads(text)
                    except json.JSONDecodeError:
                        logging.error("❌ R2: not JSON: %s", text[:500])
                        return None
                    if data.get("status") == "SUCCESS":
                        pub = (
                            data.get("r2Url")
                            or data.get("r2_url")
                            or data.get("url")
                        )
                        logging.info("✅ R2 (Cloud): Success! %s", pub)
                        return {"r2_key": filename_key, "r2_url": pub}
                logging.error("❌ R2 Error %s: %s", response.status, text[:800])
                return None
        except Exception as e:
            logging.error(f"❌ R2 Connection Error: {e}")
            return None

async def process_task(task_data: str):
    local_file_path = None
    lock_key = None
    is_lock_owner = False
    task = None

    try:
        task = DownloadTask.model_validate_json(task_data)
        logger.info(f"📨 Received task: {task.query} (User: {task.user_id})")

        async with AsyncSessionLocal() as session:
            user = await session.scalar(select(User).where(User.user_id == task.user_id))

        lang = user.language if user else 'en'
        is_premium = user.tier == AccountTier.PREMIUM if user else False

        if task.query.startswith('dl_id:'):
            youtube_id = task.query.split(':', 1)[1]
            send_to_user = not task.is_interface
            has_pre_downloaded = task.pre_downloaded_path and os.path.exists(task.pre_downloaded_path)
            
            track_info = None
            real_source_id = youtube_id

            if not has_pre_downloaded:
                # 1. Кеш
                async with AsyncSessionLocal() as session:
                    t = await session.scalar(select(Track).where(Track.source_id == youtube_id))
                
                if t and (t.r2_key or t.r2_url):
                    if not task.is_interface:
                        logger.info(f"📦 Cache HIT {youtube_id}.")
                        if send_to_user and t.telegram_file_id:
                            try:
                                await bot.send_audio(
                                    task.chat_id,
                                    t.telegram_file_id,
                                    caption=get_text("track_ready", lang).format(title=t.title),
                                )
                            except Exception:
                                pass
                        return
                    play_url = _track_playable_r2_url(t)
                    if play_url and await _r2_url_alive(play_url):
                        logger.info(f"📦 Cache HIT {youtube_id} (R2 OK).")
                        return
                    logger.warning(
                        "📦 %s: у БД є r2_key/r2_url, але R2 недоступний — качаємо з YouTube знову",
                        youtube_id,
                    )

                # 2. Lock (значення "1" ставить API-плейсхолдер; інший WORKER_ID — чужий лок.)
                lock_key = f"proc_lock:{youtube_id}"
                current_lock = await redis_client.redis.get(lock_key)
                if (
                    current_lock
                    and str(current_lock) != "1"
                    and str(current_lock) != str(WORKER_ID)
                ):
                    logger.info(
                        "⏳ proc_lock for %s held by %s — re-queue",
                        youtube_id,
                        current_lock,
                    )
                    raise LockBusyRetry()
                await redis_client.redis.set(lock_key, str(WORKER_ID), ex=300)
                is_lock_owner = True

                # 3. Smart Download
                track_info = await download_track_by_id(youtube_id)
                
                # A: DB Hit
                if track_info.get('status') == 'db_hit':
                    track_obj = track_info['track_obj']
                    logger.info(f"🔗 Linking {youtube_id} -> {track_info['real_source_id']}")
                    await save_track_to_db_v2(
                        track_info,
                        track_obj.telegram_file_id,
                        track_obj.r2_key,
                        r2_public_url=track_obj.r2_url
                        if getattr(track_obj, "r2_url", None)
                        else None,
                    )
                    if send_to_user and track_obj.telegram_file_id:
                        try: await bot.send_audio(task.chat_id, track_obj.telegram_file_id, caption=get_text("track_ready", lang).format(title=track_obj.title))
                        except: pass
                    return

                # B: New Download
                local_file_path = track_info['path']
                real_source_id = track_info.get('real_source_id', youtube_id)

            else:
                # C: Pre-downloaded
                logger.info(f"⚡ Using pre-downloaded file.")
                local_file_path = task.pre_downloaded_path
                loop = asyncio.get_running_loop()
                _po = pick_proxy_url()
                _meta_opts: Dict[str, Any] = {
                    'quiet': True,
                    **_YDL_NET,
                    **_YOUTUBE_EXTRACTOR_ARGS,
                }
                if _po:
                    _meta_opts['proxy'] = _po
                _merge_ytdlp_browser_identity(_meta_opts)
                info = await loop.run_in_executor(
                    None,
                    ytdlp_extract_info,
                    yt_watch_url(youtube_id),
                    _meta_opts,
                )
                track_info = {
                    'title': info.get('title'), 'artist': info.get('uploader'), 'duration': info.get('duration'),
                    'source_id': youtube_id, 'real_source_id': youtube_id, 'cover_big': info.get('thumbnail')
                }

            # 4. Telegram Upload
            if track_info:
                logger.info("📤 Sending to Telegram...")
                target_chat_id = settings.ARCHIVE_CHANNEL_ID if task.is_interface else task.chat_id
                caption = f"@hydra_music_dev_bot "
                
                if task.status_message_id: 
                    try: await bot.delete_message(task.chat_id, task.status_message_id)
                    except: pass

                sent_msg = await bot.send_audio(
                    target_chat_id, FSInputFile(local_file_path),
                    title=track_info['title'], performer=track_info['artist'], duration=track_info['duration'],
                    caption=caption, request_timeout=60
                )
                
                file_id = sent_msg.audio.file_id
                r2_key = None
                r2_public = None

                if not has_pre_downloaded and not is_premium:
                    try:
                        f_info = await bot.get_file(file_id)
                        r2_name = f"{real_source_id}.m4a"
                        up = await trigger_r2_cloud_upload(
                            f_info.file_path, r2_name
                        )
                        if up:
                            r2_key = up.get("r2_key")
                            r2_public = up.get("r2_url")
                    except Exception as e:
                        logger.error(f"R2 Error: {e}")
                elif is_premium:
                    logger.info("💎 Premium User: Skipping R2 upload to save space.")

                # 6. DB Save
                saved_id = await save_track_to_db_v2(
                    track_info, file_id, r2_key, r2_public_url=r2_public
                )
                
                if saved_id:
                    await analytics.log_download(task.user_id, saved_id, False, 'worker_download')
                    logger.info(f"🏁 Task Finished.")
                    if send_to_user and not has_pre_downloaded:
                         try:
                            # kb = await get_track_kb(saved_id, task.user_id, lang)
                            # await bot.edit_message_reply_markup(...)
                            pass
                         except: pass

        elif task.query.startswith('rec:'):
            youtube_id = task.query.split(':', 1)[1]
            recommendations = await fetch_recommendations(youtube_id)
            
            redis_key = f"rec:{youtube_id}"
            if recommendations:
                await redis_client.redis.set(redis_key, json.dumps(recommendations), ex=86400)
                logger.info(f"✅ Recommendations saved for {youtube_id}")
            else:
                # Кешуємо пустий список ненадовго, щоб не спамити API
                await redis_client.redis.set(redis_key, json.dumps([]), ex=3600)
            
            return
        else:
             await search_tracks(task.query, task.chat_id, task.status_message_id, lang)

    except Exception as e:
        # Важливо прокинути помилку далі, щоб wrapper її зловив
        raise e
    finally:
        if is_lock_owner and lock_key:
            await redis_client.redis.delete(lock_key)
        if local_file_path and os.path.exists(local_file_path):
            if task and (task.is_interface or task.pre_downloaded_path):
                pass
            else:
                try:
                    os.remove(local_file_path)
                except OSError:
                    pass

async def process_task_wrapper(message_id: str, task_dict: dict):
    try:
        task_json = json.dumps(task_dict)
        await process_task(task_json)
        await redis_client.ack_task(message_id)
    except LockBusyRetry:
        try:
            task = DownloadTask(**task_dict)
            if task.retry_count < MAX_RETRIES:
                task.retry_count += 1
                await redis_client.redis.xadd(
                    STREAM_KEY, {"data": task.model_dump_json()}
                )
                logger.warning(
                    "🔁 Re-queued %s (lock busy), attempt %s/%s",
                    task.query,
                    task.retry_count,
                    MAX_RETRIES,
                )
            else:
                logger.error(
                    "❌ Dropping %s: max retries while waiting for proc_lock",
                    task_dict.get("query"),
                )
        except Exception as ex:
            logger.error("LockBusyRetry handler failed: %s", ex)
        await redis_client.ack_task(message_id)
    except Exception as e:
        error_msg = str(e).lower()
        
        # 1. GEO-BLOCK: Якщо відео недоступне - пробуємо змінити регіон
        if "video unavailable" in error_msg or "not available" in error_msg:
             if not has_proxy_configured():
                logging.warning(f"🌍 Track unavailable. Redirecting to DE...")
                try:
                    await redis_client.redis.xadd("hydra:stream:de", {"data": json.dumps(task_dict)})
                    await redis_client.ack_task(message_id) 
                    return 
                except: pass
             else:
                 # Якщо вже в DE і не працює - видаляємо
                 await redis_client.ack_task(message_id)
                 return

        # YouTube «sign in / bot» — з куками з БД це часто протухлі куки.
        # Без куків (HYDRA_SKIP_YOUTUBE_COOKIES) це зазвичай IP/проксі.
        if (
            "sign in" in error_msg
            or "not a bot" in error_msg
            or "login required" in error_msg
        ):
            try:
                task = DownloadTask(**task_dict)
                if task.retry_count < MAX_RETRIES:
                    task.retry_count += 1
                    await redis_client.redis.xadd(
                        STREAM_KEY, {"data": task.model_dump_json()}
                    )
            except Exception:
                pass
            await redis_client.ack_task(message_id)

            if _use_youtube_cookies_from_db():
                logging.error(
                    "🤖 YouTube вимагає вхід / bot-check (ймовірно протухлі cookies). "
                    "Worker %s: re-queue + пауза 60 с.",
                    WORKER_ID,
                )
                logging.warning(
                    "💤 Worker %s pausing 60s so another worker can try.",
                    WORKER_ID,
                )
                await asyncio.sleep(60)
            else:
                logging.warning(
                    "⚠️ YouTube anti-bot без cookies (IP/VPN). Worker %s: re-queue без паузи "
                    "(потрібні свіжі куки, інший проксі або YTDLP_SOCKET_TIMEOUT).",
                    WORKER_ID,
                )
            return

        # 3. Інші помилки (Network, Timeout і т.д.)
        logging.error(f"❌ Failed task {message_id}: {e}")
        try:
            task = DownloadTask(**task_dict)
            if task.retry_count < MAX_RETRIES:
                task.retry_count += 1
                logging.warning(f"🔄 Re-queueing task attempt {task.retry_count}")
                await redis_client.redis.xadd(STREAM_KEY, {"data": task.model_dump_json()})
        except: pass
        
        await redis_client.ack_task(message_id)

async def explore_worker():
    print("🌍 Explore Worker started! Listening on 'explore_queue'...")
    while True:
        try:
            result = await redis_client.redis.brpop("explore_queue", timeout=5)
            if result:
                _, data_raw = result
                task = json.loads(data_raw)
                lang = task.get("lang", "en")
                print(f"🔄 [Explore] Updating data for: {lang}")
                loop = asyncio.get_event_loop()
                data = await loop.run_in_executor(None, lambda: fetch_explore_data_sync(lang))
                final_response = {
                    "sections": [
                        {"id": "new", "title": SECTION_TITLES['new_releases'].get(lang, "New Releases"), "items": data["new_releases"]},
                        {"id": "charts", "title": SECTION_TITLES['charts'].get(lang, "Charts"), "items": data["charts"]},
                        {"id": "moods", "title": SECTION_TITLES['moods'].get(lang, "Moods"), "items": data["moods"]}
                    ],
                    "status": "ok"
                }
                redis_key = f"explore_page_v8:{lang}"
                if any(data.values()):
                    await redis_client.redis.set(redis_key, json.dumps(final_response), ex=28800)
                    print(f"✅ [Explore] Saved to Redis: {redis_key}")
                else:
                    print(f"⚠️ [Explore] Empty data for {lang}, skipping cache.")
        except Exception as e:
            logging.error(f"Explore Worker Error: {e}")
            await asyncio.sleep(5)


async def metadata_processor():
    logger.info("🔎 Metadata Worker started")
    
    while True:
        try:
            task = await redis_client.redis.brpop('metadata_queue', timeout=2)
            if not task: continue
            
            _, raw_data = task
            data = json.loads(raw_data)
            action = data.get('action')
            payload = data.get('payload')
            request_id = data.get('request_id')
            
            logger.info(f"⚡ Task: {action}")
            result = None
            
            fetched_data = None
            content_type = 'album'

            # Genre track list
            if action == 'fetch_genre':
                # Отримуємо просто список треків
                genre_tracks = await asyncio.to_thread(fetch_smart_genre_tracks_sync, payload)
                
                if genre_tracks:
                    async with AsyncSessionLocal() as session:
                        items_for_cache = []
                        for item in genre_tracks:
                            items_for_cache.append({
                                "id": item.get('id'),
                                "title": item.get('title'),
                                "artist": item.get('artist'),
                                "duration": item.get('duration'),
                                "cover": item.get('cover')
                            })

                        # Зберігаємо жанр як CachedContent
                        stmt = pg_insert(CachedContent).values(
                            source_id=payload, # напр. cat_pop
                            type='genre',
                            title=payload,
                            items_data=items_for_cache, # Зберігаємо список треків
                            updated_at=func.now()
                        ).on_conflict_do_update(
                            index_elements=['source_id'],
                            set_={
                                "items_data": items_for_cache,
                                "updated_at": func.now()
                            }
                        )
                        await session.execute(stmt)
                        await session.commit()
                        logger.info(f"💾 Saved genre {payload} to DB Cache")
                    
                    result = genre_tracks

            # Albums and playlists
            elif action == 'fetch_album':
                fetched_data = await asyncio.to_thread(fetch_album_details_sync, payload)
                content_type = 'album'
            
            elif action == 'fetch_playlist':
                fetched_data = await asyncio.to_thread(fetch_playlist_details_sync, payload)
                content_type = 'playlist'

            elif action == 'fetch_artist':
                fetched_data = await asyncio.to_thread(fetch_artist_details_sync, payload)
                content_type = 'artist'
            
            # Якщо це альбом, плейлист або артист -> зберігаємо в базу
            if fetched_data:
                async with AsyncSessionLocal() as session:
                    items_for_cache = []
                    for item in fetched_data.get('items', []):
                        items_for_cache.append({
                            "id": item.get('id'),
                            "title": item.get('title'),
                            "artist": item.get('artist'),
                            "duration": item.get('duration'),
                            "cover": item.get('cover')
                        })

                    extra_meta = {}
                    if content_type == 'artist':
                        extra_meta = {
                            "albums": fetched_data.get('albums', []),
                            "similar_artists": fetched_data.get('similar_artists', []),
                        }

                    stmt = pg_insert(CachedContent).values(
                        source_id=fetched_data['id'],
                        type=content_type,
                        title=fetched_data['title'],
                        artist=fetched_data.get('artist', fetched_data.get('title', 'Unknown')),
                        description=fetched_data.get('description', ''),
                        cover=fetched_data['cover'],
                        items_data={**{"tracks": items_for_cache}, **extra_meta} if content_type == 'artist' else items_for_cache
                    ).on_conflict_do_update(
                        index_elements=['source_id'],
                        set_={
                            "title": fetched_data['title'],
                            "items_data": items_for_cache,
                            "updated_at": func.now()
                        }
                    )
                    
                    await session.execute(stmt)
                    await session.commit()
                    logger.info(f"💾 Saved {content_type} {fetched_data['id']} to DB Cache")
                
                result = fetched_data

            # Restore file from Telegram to R2
            elif action == 'restore_file':
                track_id = payload.get('track_id')
                file_id = payload.get('file_id')
                r2_key = payload.get('r2_key')

                if not track_id or not file_id:
                    logger.warning("restore_file: missing track_id or file_id")
                    result = {"status": "error", "details": "missing fields"}
                else:
                    dedup_key = f"meta_restore_exec:{track_id}"
                    lock_ok = await redis_client.redis.set(
                        dedup_key, str(WORKER_ID), nx=True, ex=300
                    )
                    if not lock_ok:
                        logger.info(
                            "♻️ Пропуск дублікату restore для %s (інший воркер вже виконує)",
                            track_id,
                        )
                        result = {"status": "skipped_duplicate"}
                    else:
                        logger.info(f"♻️ Restoring track {track_id} from Telegram...")
                        try:
                            tg_file = await bot.get_file(file_id)
                            tg_path = tg_file.file_path
                            up = await trigger_r2_cloud_upload(tg_path, r2_key)

                            if up:
                                result = {"status": "restored"}
                                async with AsyncSessionLocal() as session:
                                    t = await session.scalar(
                                        select(Track).where(Track.source_id == track_id)
                                    )
                                    if t:
                                        if up.get("r2_url"):
                                            t.r2_url = up["r2_url"]
                                        if up.get("r2_key"):
                                            t.r2_key = up["r2_key"]
                                        await session.commit()
                                        logger.info(
                                            "♻️ DB updated for %s (r2_url set)",
                                            track_id,
                                        )
                            else:
                                result = {"status": "error"}
                        except Exception as e:
                            logger.error(f"❌ Restoration Exception: {e}")
                            result = {"status": "error", "details": str(e)}
            
            # Save result to Redis
            if request_id and result:
                result_key = f"meta_res:{request_id}"
                ttl = 600 if action.startswith('fetch') else 60
                await redis_client.redis.set(result_key, json.dumps(result), ex=ttl)
            
        except Exception as e:
            logger.error(f"❌ Metadata Worker Error: {e}")
            await asyncio.sleep(1)

async def main():
    global WORKER_YTDLP_USER_AGENT
    WORKER_YTDLP_USER_AGENT = None
    # 1. Синхронізація куків з БД (можна вимкнути HYDRA_SKIP_YOUTUBE_COOKIES=1)
    if _use_youtube_cookies_from_db():
        logging.info(f"🔄 [Init] Synchronizing cookies for Worker {WORKER_ID}...")
        try:
            cookie_content, db_ua = await load_worker_google_session(WORKER_ID)
            if cookie_content:
                with open(INTERNAL_COOKIE_PATH, "w", encoding="utf-8") as f:
                    f.write(cookie_content)
                logging.info(f"✅ Cookies successfully loaded to {INTERNAL_COOKIE_PATH}")
                ua = (db_ua or "").strip()
                if ua:
                    WORKER_YTDLP_USER_AGENT = ua
                    logging.info("✅ User-Agent з google_accounts застосовано для yt-dlp")
            else:
                logging.warning(f"⚠️ Worker {WORKER_ID} started WITHOUT cookies!")
        except Exception as e:
            logging.error(f"❌ Cookie sync error: {e}")
    else:
        logging.info(
            "⏭️ HYDRA_SKIP_YOUTUBE_COOKIES: пропуск синхронізації куків; yt-dlp без --cookies"
        )
        safe_remove(INTERNAL_COOKIE_PATH)

    # HYDRA_VPN_ONLY + google у БД: не ганяємо explore/charts (зайве навантаження з «особистих» акаунтів),
    # але чергу завантажень hydra:stream ЗАВЖДИ обробляємо — інакше API вічно віддає 202 processing.
    skip_explore_charts = False
    if env_truthy("HYDRA_VPN_ONLY", False):
        try:
            if await _google_account_assigned_to_this_worker():
                skip_explore_charts = True
                logging.warning(
                    "HYDRA_VPN_ONLY=1: WORKER_ID=%s має google_accounts — "
                    "explore/charts вимкнені; stream + metadata активні.",
                    WORKER_ID,
                )
        except Exception as e:
            logging.error("HYDRA_VPN_ONLY check failed: %s (продовжуємо як звичайно)", e)

    asyncio.create_task(metadata_processor())

    logging.info(f"🚀 Stream Worker {CONSUMER_NAME} started on queue: {STREAM_KEY}")

    redis_client.stream_key = STREAM_KEY

    await redis_client.init_consumer_group()

    if not skip_explore_charts:
        asyncio.create_task(explore_worker())
        asyncio.create_task(background_updater())

    try:
        _autoclaim_min_idle = int(os.getenv("HYDRA_STREAM_AUTOCLAIM_MIN_IDLE_MS", "60000"))
    except ValueError:
        _autoclaim_min_idle = 60_000
    _autoclaim_min_idle = max(1_000, _autoclaim_min_idle)
    try:
        _autoclaim_count = int(os.getenv("HYDRA_STREAM_AUTOCLAIM_COUNT", "8"))
    except ValueError:
        _autoclaim_count = 8
    _autoclaim_count = max(1, min(50, _autoclaim_count))

    async def stream_processor():
        logging.info("🎧 Stream Processor started!")
        while True:
            try:
                # Забираємо pending, що «висять» на старих іменах consumer після попередніх деплоїв.
                try:
                    ac = await redis_client.autoclaim_pending(
                        CONSUMER_NAME,
                        min_idle_ms=_autoclaim_min_idle,
                        count=_autoclaim_count,
                    )
                except Exception:
                    ac = None
                if ac and len(ac) >= 2 and ac[1]:
                    for message_id, data in ac[1]:
                        if isinstance(data, dict) and "data" in data:
                            try:
                                task_payload = json.loads(data["data"])
                                await process_task_wrapper(message_id, task_payload)
                            except Exception as exc:
                                logging.error("Stream autoclaim task error: %s", exc)
                        await asyncio.sleep(0.02)
                    continue

                response = await redis_client.read_task_group(CONSUMER_NAME)
                if response:
                    for stream, messages in response:
                        for message_id, data in messages:
                            if "data" in data:
                                task_payload = json.loads(data["data"])
                                await process_task_wrapper(message_id, task_payload)

                await asyncio.sleep(0.1)
            except Exception as e:
                logging.error(f"Stream Processor error: {e}")
                await asyncio.sleep(2)

    await stream_processor()

if __name__ == "__main__":
    asyncio.run(main())