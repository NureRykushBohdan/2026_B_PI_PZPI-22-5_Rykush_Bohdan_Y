-- Persistent lyrics storage (safe to run multiple times)

CREATE TABLE IF NOT EXISTS track_lyrics (
    source_id VARCHAR(255) PRIMARY KEY,
    title VARCHAR(255),
    artist VARCHAR(255),
    lyrics TEXT NOT NULL,
    synced BOOLEAN DEFAULT false,
    source VARCHAR(64),
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_track_lyrics_title_trgm ON track_lyrics USING gin (title gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_track_lyrics_artist_trgm ON track_lyrics USING gin (artist gin_trgm_ops);
