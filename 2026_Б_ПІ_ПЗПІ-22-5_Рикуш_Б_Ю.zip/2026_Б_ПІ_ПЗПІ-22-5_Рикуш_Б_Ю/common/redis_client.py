import os
import json
import logging
from redis import asyncio as aioredis
from common.config import settings

class RedisClient:
    def __init__(self):
        self.redis_url = settings.REDIS_URL
        self.redis = aioredis.from_url(self.redis_url, decode_responses=True)
        
        # Головний потік для XADD (бот / API) — не змінювати на воркері.
        self.STREAM_KEY = "hydra:stream"
        self.GROUP_NAME = "hydra_group"
        # Потік для XREADGROUP/XACK воркера (можна перевизначити: hydra:stream:de тощо).
        self.stream_key = self.STREAM_KEY

    async def close(self):
        await self.redis.close()

    async def get_queues(self):
        return [self.STREAM_KEY]

    async def push_task(self, task_data, is_background=False):
        """
        Універсальний метод. 
        Раніше писав у LPUSH (список), тепер пише в XADD (потік).
        Це полагодить пошук, бо бот використовує саме цей метод.
        """
        # Pydantic v2: model_dump(); v1: dict()
        if hasattr(task_data, "model_dump"):
            data_dict = task_data.model_dump()
        elif hasattr(task_data, "dict"):
            data_dict = task_data.dict()
        elif isinstance(task_data, str):
            # Якщо це вже JSON-рядок (буває при retry), розпарсимо і запакуємо знову
            # щоб структура була однакова {"data": ...}
            try:
                data_dict = json.loads(task_data)
            except:
                # Критичний фолбек, якщо прийшло щось дивне
                logging.error(f"Invalid task data format: {task_data}")
                return
        else:
            data_dict = task_data

        # Додаємо в потік. maxlen обмежує розмір історії, щоб пам'ять не текла
        await self.redis.xadd(self.STREAM_KEY, {"data": json.dumps(data_dict)}, maxlen=10000, approximate=True)

    async def init_consumer_group(self):
        """Створює групу, якщо немає"""
        try:
            # $ означає читати тільки нові. 0 означає читати всі з початку.
            # Для черги задач краще '0', щоб не пропустити старі задачі при старті.
            await self.redis.xgroup_create(self.stream_key, self.GROUP_NAME, id="0", mkstream=True)
        except Exception as e:
            if "BUSYGROUP" not in str(e):
                logging.error(f"Redis Group Error: {e}")

    async def read_task_group(self, consumer_name: str):
        """Читає задачі для воркера з авто-відновленням групи"""
        try:
            return await self.redis.xreadgroup(
                self.GROUP_NAME,
                consumer_name,
                {self.stream_key: ">"},
                count=1,
                block=5000,
            )
        except Exception as e:
            if "NOGROUP" in str(e):
                logging.warning(f"⚠️ Consumer Group missing. Re-creating...")
                await self.init_consumer_group()
                return None

            logging.error(f"Stream Read Error: {e}")
            return None

    async def ack_task(self, message_id: str):
        """Підтверджує виконання"""
        await self.redis.xack(self.stream_key, self.GROUP_NAME, message_id)
        await self.redis.xdel(self.stream_key, message_id)

    async def autoclaim_pending(
        self,
        consumer_name: str,
        *,
        min_idle_ms: int = 60_000,
        count: int = 10,
        start_id: str = "0-0",
    ):
        """
        Переносить «завислі» pending на цей consumer (Redis ≥ 6.2).
        Потрібно після зміни імен consumer / рестартів, щоб задачі не лишались на мертвих іменах.
        """
        if not hasattr(self.redis, "xautoclaim"):
            return None
        try:
            return await self.redis.xautoclaim(
                self.stream_key,
                self.GROUP_NAME,
                consumer_name,
                min_idle_ms,
                start_id=start_id,
                count=count,
            )
        except Exception as e:
            logging.warning("xautoclaim failed: %s", e)
            return None


redis_client = RedisClient()