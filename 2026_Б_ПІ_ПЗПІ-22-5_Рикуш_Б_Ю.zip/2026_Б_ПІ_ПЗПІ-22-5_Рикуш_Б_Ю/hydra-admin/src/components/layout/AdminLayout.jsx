import { NavLink, Outlet } from 'react-router-dom'
import { formatDate } from '../../utils/format.js'
import StatusDot from '../ui/StatusDot.jsx'

export default function AdminLayout({
  ready,
  timestamp,
  loading,
  onRefresh,
  onLogout,
  actionMsg,
  err,
}) {
  return (
    <div className="app-shell">
      <header className="status-bar">
        <div className="status-bar__left">
          <div className="status-bar__brand">Hydra</div>
          <nav className="top-nav" aria-label="Розділи">
            <NavLink to="/" end className={({ isActive }) => (isActive ? 'active' : '')}>
              Моніторинг
            </NavLink>
            <NavLink to="/control" className={({ isActive }) => (isActive ? 'active' : '')}>
              Керування
            </NavLink>
          </nav>
        </div>
        <div className="status-bar__right">
          <div className="status-bar__meta" aria-live="polite">
            <StatusDot
              status={ready ? 'ok' : 'bad'}
              label={ready ? 'Система готова' : 'Збій залежностей'}
            />
            {timestamp && (
              <time className="mono muted" dateTime={timestamp}>
                {formatDate(timestamp)}
              </time>
            )}
          </div>
          <div className="status-bar__actions">
            <button
              type="button"
              className={`btn btn--ghost${loading ? ' btn--loading' : ''}`}
              onClick={onRefresh}
            >
              Оновити
            </button>
            <button type="button" className="link-btn" onClick={onLogout}>
              Вийти
            </button>
          </div>
        </div>
      </header>

      {err && <div className="banner banner--error layout-banner">{err}</div>}
      {actionMsg && <div className="banner banner--info layout-banner">{actionMsg}</div>}

      <Outlet />
    </div>
  )
}
