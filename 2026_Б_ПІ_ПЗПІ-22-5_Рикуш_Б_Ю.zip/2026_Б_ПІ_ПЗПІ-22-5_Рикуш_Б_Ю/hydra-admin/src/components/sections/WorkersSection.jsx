import SectionHeader from '../ui/SectionHeader.jsx'
import KpiBlock from '../ui/KpiBlock.jsx'
import DataTable from '../ui/DataTable.jsx'
import { formatIdle } from '../../utils/format.js'

export default function WorkersSection({ data, verbose }) {
  const stream = data?.download_stream
  if (stream == null) return null

  const workerRows = (stream.workers || []).map((w) => ({
    _key: w.id,
    id: w.id,
    names: w.names,
    pending: w.pending,
    idle_ms: w.idle_ms,
    ghosts: w.ghosts,
    live: w.live,
  }))

  const taskRows = (stream.recent_tasks || []).map((t, i) => ({
    _key: i,
    video_id: t.video_id,
    query: t.query,
  }))

  const idleSampleRows = (stream.lowest_idle_sample || []).map((c) => ({
    _key: c.name,
    name: c.name,
    pending: c.pending,
    idle_ms: c.idle_ms,
  }))

  return (
    <section id="workers" className="section">
      <SectionHeader
        num="03"
        title="Воркери та завантаження"
        description="Consumer group hydra:stream — завантаження з YouTube через yt-dlp."
      />

      {stream.absent && (
        <div className="banner banner--error">
          Ключ <span className="mono">hydra:stream</span> у Redis відсутній.
        </div>
      )}
      {stream.error && <div className="banner banner--error">{stream.error}</div>}

      {!stream.absent && !stream.error && (
        <>
          <div className="kpi-grid">
            <KpiBlock value={stream.messages} label="Повідомлень у стрімі" />
            <KpiBlock value={stream.pending} label="Pending (група)" accent />
            <KpiBlock value={stream.registered_consumers} label="Consumer у Redis" />
          </div>

          {(stream.unknown_consumers || 0) > 0 && (
            <p className="muted" style={{ marginBottom: '1rem' }}>
              Consumer без префікса worker_N_: {stream.unknown_consumers}
            </p>
          )}

          <p className="muted" style={{ marginBottom: '1.5rem', maxWidth: '60ch' }}>
            Воркери використовують стале ім&apos;я <span className="mono">worker_&#123;ID&#125;</span> та{' '}
            <span className="mono">XAUTOCLAIM</span>, щоб pending не зависали після деплою. «Очистити
            привидів» прибирає consumer без pending (idle ≥ 10 хв).
          </p>

          <div className="panel">
            <h3>Воркери</h3>
            <DataTable
              maxHeight={280}
              emptyMessage="Немає активних воркерів"
              columns={[
                {
                  key: 'id',
                  label: 'Воркер',
                  render: (r) => <span className="tag tag--accent">worker {r.id}</span>,
                },
                { key: 'names', label: 'Імен у Redis' },
                { key: 'pending', label: 'Pending' },
                {
                  key: 'idle_ms',
                  label: 'Найкоротший idle',
                  render: (r) => formatIdle(r.idle_ms),
                },
                {
                  key: 'ghosts',
                  label: 'Привиди / живі',
                  render: (r) => (
                    <>
                      <span className="tag tag--warn">{r.ghosts}</span>
                      <span style={{ margin: '0 4px', color: 'var(--text-muted)' }}>/</span>
                      <span className="tag tag--ok">{r.live}</span>
                    </>
                  ),
                },
              ]}
              rows={workerRows}
            />
          </div>

          {taskRows.length > 0 && (
            <div className="panel">
              <h3>Останні задачі зі стріму</h3>
              <DataTable
                maxHeight={200}
                columns={[
                  {
                    key: 'video_id',
                    label: 'Відео',
                    render: (r) =>
                      r.video_id ? <span className="tag">{r.video_id}</span> : '—',
                  },
                  {
                    key: 'query',
                    label: 'Запит',
                    mono: true,
                    render: (r) => r.query || '—',
                  },
                ]}
                rows={taskRows}
              />
            </div>
          )}

          {verbose && idleSampleRows.length > 0 && (
            <details className="panel collapsible" open>
              <summary>Діагностика — найменший idle</summary>
              <DataTable
                maxHeight={180}
                columns={[
                  { key: 'name', label: 'Consumer', mono: true },
                  { key: 'pending', label: 'Pending' },
                  {
                    key: 'idle_ms',
                    label: 'Idle',
                    render: (r) => formatIdle(r.idle_ms),
                  },
                ]}
                rows={idleSampleRows}
              />
            </details>
          )}
        </>
      )}
    </section>
  )
}
