import SectionHeader from '../ui/SectionHeader.jsx'
import DataTable from '../ui/DataTable.jsx'

export default function InfrastructureSection({ data }) {
  const accountRows = (data?.google_accounts || [])
    .filter((g) => !g.error)
    .map((g) => ({
      _key: g.id,
      worker: g.worker,
      email: g.email,
      active: g.active,
      errors: g.errors,
    }))

  const accountError = data?.google_accounts?.find((g) => g.error)?.error

  const nodeRows = (data?.network_nodes || [])
    .filter((n) => !n.error)
    .map((n) => ({
      _key: n.worker,
      worker: n.worker,
      name: n.name,
      type: n.type,
    }))

  const nodeError = data?.network_nodes?.find((n) => n.error)?.error

  return (
    <section id="infra" className="section">
      <SectionHeader
        num="05"
        title="Інфраструктура"
        description="Google-акаунти для cookies та мережеві вузли воркерів."
      />

      <div className="panel-grid">
        <div className="panel">
          <h3>Google accounts → workers</h3>
          {accountError && <div className="banner banner--error">{accountError}</div>}
          <DataTable
            maxHeight={280}
            columns={[
              { key: 'worker', label: 'Worker' },
              {
                key: 'email',
                label: 'Email',
                mono: true,
                render: (r) => (
                  <span style={{ maxWidth: 180, display: 'inline-block', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {r.email}
                  </span>
                ),
              },
              {
                key: 'active',
                label: 'Статус',
                render: (r) => (
                  <>
                    {r.active ? (
                      <span className="tag tag--ok">on</span>
                    ) : (
                      <span className="tag tag--warn">off</span>
                    )}
                    {r.errors > 0 && (
                      <span className="tag tag--warn" style={{ marginLeft: 4 }}>
                        err {r.errors}
                      </span>
                    )}
                  </>
                ),
              },
            ]}
            rows={accountRows}
          />
        </div>

        <div className="panel">
          <h3>Network nodes</h3>
          {nodeError && <div className="banner banner--error">{nodeError}</div>}
          <DataTable
            maxHeight={280}
            columns={[
              { key: 'worker', label: 'W' },
              { key: 'name', label: 'Назва', render: (r) => r.name || '—' },
              { key: 'type', label: 'Тип', mono: true },
            ]}
            rows={nodeRows}
          />
        </div>
      </div>
    </section>
  )
}
