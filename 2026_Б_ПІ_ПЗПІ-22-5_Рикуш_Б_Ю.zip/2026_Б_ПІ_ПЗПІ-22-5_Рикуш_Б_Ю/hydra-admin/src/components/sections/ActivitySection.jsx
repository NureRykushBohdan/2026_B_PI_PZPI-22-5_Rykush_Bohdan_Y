import SectionHeader from '../ui/SectionHeader.jsx'
import DataTable from '../ui/DataTable.jsx'
import { formatDate } from '../../utils/format.js'

export default function ActivitySection({ data }) {
  const lockRows = (data?.locks || []).map((row) => ({
    _key: row.video_id,
    video_id: row.video_id,
    lock_holder: row.lock_holder,
  }))

  const downloadRows = (data?.recent_downloads || [])
    .filter((r) => !r.error)
    .map((r) => ({
      _key: r.id,
      created_at: r.created_at,
      title: r.title,
      artist: r.artist,
      source_id: r.source_id,
      is_cached: r.is_cached,
    }))

  const downloadError = data?.recent_downloads?.find((r) => r.error)?.error

  return (
    <section id="activity" className="section">
      <SectionHeader
        num="04"
        title="Активність"
        description="Поточні блокування завантажень та останні видачі треків."
      />

      <div className="panel">
        <h3>
          Активні завантаження{' '}
          <span className="mono muted" style={{ fontWeight: 400, fontSize: '0.875rem' }}>
            proc_lock
          </span>
        </h3>
        <DataTable
          emptyMessage="Немає відкритих блокувань — воркери зараз нічого не тримають під lock."
          columns={[
            { key: 'video_id', label: 'Відео / джерело', mono: true },
            { key: 'lock_holder', label: 'Воркер (lock)' },
          ]}
          rows={lockRows}
        />
      </div>

      <div className="panel">
        <h3>Останні видачі треків</h3>
        {downloadError && <div className="banner banner--error">{downloadError}</div>}
        <DataTable
          columns={[
            {
              key: 'created_at',
              label: 'Час',
              mono: true,
              render: (r) => formatDate(r.created_at),
            },
            {
              key: 'title',
              label: 'Трек',
              render: (r) => (
                <>
                  <div>{r.title || r.source_id}</div>
                  <div className="mono muted" style={{ fontSize: '0.75rem', marginTop: 2 }}>
                    {r.artist} · {r.source_id}
                  </div>
                </>
              ),
            },
            {
              key: 'is_cached',
              label: 'Джерело',
              render: (r) =>
                r.is_cached ? (
                  <span className="tag tag--ok">кеш</span>
                ) : (
                  <span className="tag tag--warn">yt</span>
                ),
            },
          ]}
          rows={downloadRows}
        />
      </div>
    </section>
  )
}
