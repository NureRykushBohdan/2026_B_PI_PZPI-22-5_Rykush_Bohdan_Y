import SectionHeader from '../ui/SectionHeader.jsx'
import StatusDot from '../ui/StatusDot.jsx'
import KpiBlock from '../ui/KpiBlock.jsx'
import CacheRing from '../ui/CacheRing.jsx'
import { formatDate } from '../../utils/format.js'

export default function OverviewSection({ data }) {
  const stats = data?.stats || {}
  const health = data?.health || {}

  return (
    <section id="overview" className="section">
      <SectionHeader
        num="01"
        title="Огляд системи"
        description="Здоровʼя залежностей та ключові показники продукту."
      />

      <div className="status-strip">
        <div className="status-strip__item">
          <span className="status-strip__label">PostgreSQL</span>
          <StatusDot
            status={health.database === 'ok' ? 'ok' : 'bad'}
            label={health.database === 'ok' ? 'Підключено' : String(health.database || '—')}
          />
        </div>
        <div className="status-strip__item">
          <span className="status-strip__label">Redis</span>
          <StatusDot
            status={health.redis === 'ok' ? 'ok' : 'bad'}
            label={health.redis === 'ok' ? 'Підключено' : String(health.redis || '—')}
          />
        </div>
        <div className="status-strip__item">
          <span className="status-strip__label">Загальний стан</span>
          <StatusDot
            status={health.ready ? 'ok' : 'bad'}
            label={health.ready ? 'API + Redis + DB' : 'Збій залежностей'}
          />
        </div>
      </div>

      <div className="kpi-grid">
        <KpiBlock value={stats.users} label="Користувачі" />
        <KpiBlock value={stats.tracks} label="Треки в БД" />
        <KpiBlock value={stats.downloads} label="Завантаження (історія)" />
        <KpiBlock value={stats.active_playlists} label="Черга плейлистів" accent />
      </div>

      <CacheRing rate={stats.cache_rate} hits={stats.cache_hits} />

      {data?.charts_updated_at && (
        <p className="footnote">
          Charts оновлено:{' '}
          <span className="mono">
            {formatDate(data.charts_updated_at, { timeZone: 'UTC' })} UTC
          </span>
        </p>
      )}
    </section>
  )
}
