import { formatNumber } from '../../utils/format.js'

export default function CacheRing({ rate, hits }) {
  const pct = Math.min(100, Math.max(0, Number(rate) || 0))

  return (
    <div className="cache-stat">
      <div className="cache-stat__value">{pct}%</div>
      <div className="cache-stat__body">
        <div className="cache-stat__label">Кеш</div>
        <div className="cache-stat__sub muted">
          {formatNumber(hits)} хітів · {formatNumber(rate)}% від історії
        </div>
        <div className="cache-stat__bar" aria-hidden="true">
          <div className="cache-stat__fill" style={{ width: `${pct}%` }} />
        </div>
      </div>
    </div>
  )
}
