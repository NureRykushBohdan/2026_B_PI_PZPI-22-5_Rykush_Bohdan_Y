import { formatNumber } from '../../utils/format.js'

export default function KpiBlock({ value, label, sub, accent = false }) {
  return (
    <div className="kpi-block">
      <div className={`kpi-block__value${accent ? ' kpi-block__value--accent' : ''}`}>
        {formatNumber(value)}
      </div>
      <div className="kpi-block__label">{label}</div>
      {sub != null && <div className="kpi-block__sub">{sub}</div>}
    </div>
  )
}
