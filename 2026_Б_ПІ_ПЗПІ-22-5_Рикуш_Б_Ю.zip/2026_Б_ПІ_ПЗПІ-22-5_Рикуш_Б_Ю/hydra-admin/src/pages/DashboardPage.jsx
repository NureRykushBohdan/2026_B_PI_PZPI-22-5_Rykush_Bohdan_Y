import { useEffect, useState } from 'react'
import OverviewSection from '../components/sections/OverviewSection.jsx'
import QueuesSection from '../components/sections/QueuesSection.jsx'
import WorkersSection from '../components/sections/WorkersSection.jsx'
import ActivitySection from '../components/sections/ActivitySection.jsx'
import InfrastructureSection from '../components/sections/InfrastructureSection.jsx'

const NAV = [
  { id: 'overview', label: 'Огляд' },
  { id: 'queues', label: 'Черги' },
  { id: 'workers', label: 'Воркери' },
  { id: 'activity', label: 'Активність' },
  { id: 'infra', label: 'Інфра' },
]

export default function DashboardPage({ data, verbose, onToggleVerbose }) {
  const [activeSection, setActiveSection] = useState('overview')

  useEffect(() => {
    const ids = NAV.map((n) => n.id)
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)
        if (visible[0]?.target?.id) {
          setActiveSection(visible[0].target.id)
        }
      },
      { rootMargin: '-20% 0px -60% 0px', threshold: [0, 0.25, 0.5] },
    )
    ids.forEach((id) => {
      const el = document.getElementById(id)
      if (el) observer.observe(el)
    })
    return () => observer.disconnect()
  }, [])

  return (
    <div className="shell-body">
      <aside className="sidebar">
        <nav aria-label="Секції моніторингу">
          {NAV.map((item) => (
            <a
              key={item.id}
              href={`#${item.id}`}
              className={activeSection === item.id ? 'active' : ''}
            >
              {item.label}
            </a>
          ))}
        </nav>
        <div className="sidebar__footer">
          <label className="sidebar__toggle">
            <input
              type="checkbox"
              checked={verbose}
              onChange={(e) => onToggleVerbose(e.target.checked)}
            />
            Діагностика Redis
          </label>
        </div>
      </aside>

      <main className="main-content">
        <OverviewSection data={data} />
        <QueuesSection data={data} />
        <WorkersSection data={data} verbose={verbose} />
        <ActivitySection data={data} />
        <InfrastructureSection data={data} />
      </main>
    </div>
  )
}
