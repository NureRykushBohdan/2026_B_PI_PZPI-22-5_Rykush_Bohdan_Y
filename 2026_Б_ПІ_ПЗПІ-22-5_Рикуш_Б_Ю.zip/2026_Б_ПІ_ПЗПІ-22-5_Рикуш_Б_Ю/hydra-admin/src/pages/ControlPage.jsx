import { useState } from 'react'
import SectionHeader from '../components/ui/SectionHeader.jsx'
import StatusDot from '../components/ui/StatusDot.jsx'
import { useControlPanel } from '../hooks/useControlPanel.js'
import { formatNumber } from '../utils/format.js'

const EXPLORE_LANGS = ['uk', 'en', 'de', 'ru']
const QUEUES = ['metadata_queue', 'explore_queue', 'tg_send_queue']

function SettingRow({ label, value, mono = false }) {
  return (
    <div className="setting-row">
      <span className="setting-row__label">{label}</span>
      <span className={`setting-row__value${mono ? ' mono' : ''}`}>{value}</span>
    </div>
  )
}

function BoolBadge({ on, labelOn = 'так', labelOff = 'ні' }) {
  return (
    <span className={`tag${on ? ' tag--ok' : ' tag--warn'}`}>{on ? labelOn : labelOff}</span>
  )
}

export default function ControlPage({ adminKey }) {
  const cp = useControlPanel(adminKey)
  const [ghostIdleMs, setGhostIdleMs] = useState(600000)
  const [selectedLangs, setSelectedLangs] = useState(['uk', 'en'])
  const [clearQueue, setClearQueue] = useState('metadata_queue')

  const runtime = cp.settings?.runtime || {}
  const workerEnv = cp.settings?.worker_env || {}
  const redisMeta = cp.settings?.redis || {}

  const toggleLang = (lang) => {
    setSelectedLangs((prev) =>
      prev.includes(lang) ? prev.filter((l) => l !== lang) : [...prev, lang],
    )
  }

  if (cp.loading && !cp.settings) {
    return <div className="control-page"><p className="muted">Завантаження…</p></div>
  }

  return (
    <div className="control-page">
      {cp.err && <div className="banner banner--error">{cp.err}</div>}
      {cp.msg && <div className="banner banner--info">{cp.msg}</div>}

      <section className="section">
        <SectionHeader
          num="01"
          title="Системні налаштування"
          description="Runtime-конфіг API (без секретів). Зміни в .env — перезапуск api/bot/workers."
        />
        <div className="panel-grid">
          <div className="panel">
            <h3>Безпека та доступ</h3>
            <div className="setting-list">
              <SettingRow label="AUTH_DEBUG" value={<BoolBadge on={runtime.auth_debug} />} />
              <SettingRow label="ADMIN_API_KEY задано" value={<BoolBadge on={runtime.admin_key_set} />} />
              <SettingRow label="SEARCH_API_SECRET" value={<BoolBadge on={runtime.search_api_secret_set} />} />
              <SettingRow label="BOT_TOKEN задано" value={<BoolBadge on={runtime.bot_token_set} />} />
              <SettingRow label="ADMIN_ID" value={runtime.admin_id ?? '—'} mono />
            </div>
          </div>
          <div className="panel">
            <h3>Продукт та інтеграції</h3>
            <div className="setting-list">
              <SettingRow label="TELEGRAM_WEBAPP_URL" value={runtime.telegram_webapp_url || '—'} mono />
              <SettingRow label="R2_PUBLIC_URL" value={runtime.r2_public_url || '—'} mono />
              <SettingRow label="CF Worker" value={<BoolBadge on={runtime.cf_worker_configured} labelOn="on" labelOff="off" />} />
              <SettingRow label="ARCHIVE_CHANNEL_ID" value={runtime.archive_channel_id ?? '—'} mono />
            </div>
          </div>
          <div className="panel">
            <h3>Shazam / recognize</h3>
            <div className="setting-list">
              <SettingRow label="RECOGNIZE_MAX_BYTES" value={formatNumber(runtime.recognize_max_bytes)} />
              <SettingRow label="RECOGNIZE_TIMEOUT_SEC" value={runtime.recognize_timeout_sec} />
              <SettingRow label="Rate limit / хв" value={runtime.recognize_rate_limit_per_minute} />
            </div>
          </div>
          <div className="panel">
            <h3>Воркери (env)</h3>
            <div className="setting-list">
              <SettingRow label="HYDRA_SKIP_YOUTUBE_COOKIES" value={workerEnv.hydra_skip_youtube_cookies} mono />
              <SettingRow label="HYDRA_VPN_ONLY" value={workerEnv.hydra_vpn_only || '—'} mono />
              <SettingRow label="YTDLP_SOCKET_TIMEOUT" value={workerEnv.ytdlp_socket_timeout || '—'} mono />
              <SettingRow label="STREAM_KEY" value={workerEnv.stream_key || redisMeta.stream_main} mono />
            </div>
          </div>
        </div>
        {runtime.cors_origins?.length > 0 && (
          <details className="panel collapsible" style={{ marginTop: '1rem' }}>
            <summary>CORS origins ({runtime.cors_origins.length})</summary>
            <ul className="mono-list">
              {runtime.cors_origins.map((o) => (
                <li key={o}>{o}</li>
              ))}
            </ul>
          </details>
        )}
      </section>

      <section className="section">
        <SectionHeader
          num="02"
          title="Кеші та оновлення контенту"
          description="Charts, explore-сторінки та фонові задачі."
        />
        <div className="panel">
          <div className="action-row">
            <button type="button" className="btn btn--primary" onClick={() => cp.triggerCharts()}>
              Оновити charts / new releases
            </button>
            <button
              type="button"
              className="btn"
              onClick={() => cp.invalidateExplore([])}
            >
              Скинути кеш explore (усі мови)
            </button>
          </div>
          <p className="muted action-hint">
            Charts: скидає <span className="mono">cache:last_update_ts</span> — background updater воркера підхопить задачу.
          </p>
        </div>

        <div className="panel">
          <h3>Explore queue</h3>
          <div className="lang-chips">
            {EXPLORE_LANGS.map((lang) => (
              <label key={lang} className="lang-chip">
                <input
                  type="checkbox"
                  checked={selectedLangs.includes(lang)}
                  onChange={() => toggleLang(lang)}
                />
                {lang}
              </label>
            ))}
          </div>
          <div className="action-row">
            <button
              type="button"
              className="btn btn--primary"
              disabled={selectedLangs.length === 0}
              onClick={() => cp.triggerExplore(selectedLangs)}
            >
              Поставити в explore_queue
            </button>
            <button
              type="button"
              className="btn"
              disabled={selectedLangs.length === 0}
              onClick={() => cp.invalidateExplore(selectedLangs)}
            >
              Інвалідувати кеш обраних
            </button>
          </div>
        </div>

        <div className="panel">
          <h3>Стан Redis-кешів</h3>
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Ключ</th>
                  <th>Є</th>
                  <th>TTL</th>
                  <th>Деталі</th>
                </tr>
              </thead>
              <tbody>
                {(cp.caches?.caches || []).map((c) => (
                  <tr key={c.key}>
                    <td className="mono">{c.key}</td>
                    <td>{c.exists ? <StatusDot status="ok" label="так" /> : <span className="muted">—</span>}</td>
                    <td>{c.ttl_sec != null && c.ttl_sec >= 0 ? `${c.ttl_sec} с` : '—'}</td>
                    <td className="mono muted">
                      {c.items != null && `${c.items} items`}
                      {c.value && c.value}
                      {c.bytes != null && `${c.bytes} B`}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="section">
        <SectionHeader
          num="03"
          title="Google акаунти"
          description="Увімкнення, скидання помилок, призначення воркера."
        />
        <div className="panel">
          {(cp.accounts || []).filter((a) => !a.error).length === 0 ? (
            <div className="empty-state">Немає акаунтів у БД</div>
          ) : (
            <div className="account-cards">
              {(cp.accounts || [])
                .filter((a) => !a.error)
                .map((acc) => (
                  <AccountCard key={acc.id} account={acc} onUpdate={cp.updateAccount} />
                ))}
            </div>
          )}
        </div>
      </section>

      <section className="section">
        <SectionHeader
          num="04"
          title="Мережеві вузли"
          description="Proxy / VPN mapping для воркерів."
        />
        <div className="panel">
          {(cp.nodes || []).filter((n) => !n.error).length === 0 ? (
            <div className="empty-state">Немає network_nodes</div>
          ) : (
            <div className="node-cards">
              {(cp.nodes || [])
                .filter((n) => !n.error)
                .map((node) => (
                  <NodeCard key={node.worker} node={node} onUpdate={cp.updateNode} />
                ))}
            </div>
          )}
        </div>
      </section>

      <section className="section">
        <SectionHeader
          num="05"
          title="Redis та черги"
          description="Обслуговування stream consumers і list-черг."
        />
        <div className="panel">
          <h3>Prune ghost consumers</h3>
          <div className="form-inline">
            <label>
              Min idle (мс)
              <input
                type="number"
                min={60000}
                step={60000}
                value={ghostIdleMs}
                onChange={(e) => setGhostIdleMs(Number(e.target.value))}
              />
            </label>
            <button type="button" className="btn btn--primary" onClick={() => cp.pruneGhosts(ghostIdleMs)}>
              Очистити привидів
            </button>
          </div>
          <p className="muted action-hint">
            Stream: <span className="mono">{redisMeta.stream_main}</span>, group:{' '}
            <span className="mono">{redisMeta.consumer_group}</span>
          </p>
        </div>

        <div className="panel">
          <h3>Очищення list-черг</h3>
          <div className="form-inline">
            <label>
              Черга
              <select value={clearQueue} onChange={(e) => setClearQueue(e.target.value)}>
                {QUEUES.map((q) => (
                  <option key={q} value={q}>
                    {q} ({cp.queues[q] ?? '—'})
                  </option>
                ))}
              </select>
            </label>
            <button
              type="button"
              className="btn"
              onClick={() => cp.clearListQueue(clearQueue, true)}
            >
              Dry run
            </button>
            <button
              type="button"
              className="btn btn--danger"
              onClick={() => {
                if (
                  window.confirm(
                    `Видалити ВСІ повідомлення з ${clearQueue}? Це незворотно.`,
                  )
                ) {
                  cp.clearListQueue(clearQueue, false)
                }
              }}
            >
              Очистити
            </button>
          </div>
        </div>
      </section>
    </div>
  )
}

function AccountCard({ account, onUpdate }) {
  const [worker, setWorker] = useState(String(account.worker ?? 1))

  return (
    <div className="entity-card">
      <div className="entity-card__head">
        <span className="mono">{account.email}</span>
        {account.active ? (
          <span className="tag tag--ok">active</span>
        ) : (
          <span className="tag tag--warn">off</span>
        )}
      </div>
      <div className="entity-card__meta muted">
        Worker {account.worker} · помилок: {account.errors ?? 0}
        {account.proxy && ` · ${account.proxy}`}
      </div>
      <div className="entity-card__actions">
        <button
          type="button"
          className="btn"
          onClick={() => onUpdate(account.id, { is_active: !account.active })}
        >
          {account.active ? 'Вимкнути' : 'Увімкнути'}
        </button>
        <button
          type="button"
          className="btn"
          onClick={() => onUpdate(account.id, { reset_errors: true })}
        >
          Скинути errors
        </button>
        <label className="inline-field">
          Worker
          <input
            type="number"
            min={1}
            max={99}
            value={worker}
            onChange={(e) => setWorker(e.target.value)}
          />
        </label>
        <button
          type="button"
          className="btn"
          onClick={() =>
            onUpdate(account.id, { assigned_worker_id: parseInt(worker, 10) })
          }
        >
          Зберегти worker
        </button>
      </div>
    </div>
  )
}

function NodeCard({ node, onUpdate }) {
  const [name, setName] = useState(node.name || '')
  const [host, setHost] = useState(node.host || '')
  const [port, setPort] = useState(node.port ?? '')
  const [type, setType] = useState(node.type || '')

  return (
    <div className="entity-card">
      <div className="entity-card__head">
        <span>Worker {node.worker}</span>
        <span className="tag tag--accent">{type || '—'}</span>
      </div>
      <div className="entity-card__form">
        <label>
          Назва
          <input value={name} onChange={(e) => setName(e.target.value)} />
        </label>
        <label>
          Host
          <input value={host} onChange={(e) => setHost(e.target.value)} className="mono" />
        </label>
        <label>
          Port
          <input
            type="number"
            value={port}
            onChange={(e) => setPort(e.target.value)}
            className="mono"
          />
        </label>
        <label>
          Тип
          <input value={type} onChange={(e) => setType(e.target.value)} />
        </label>
      </div>
      <button
        type="button"
        className="btn btn--primary"
        onClick={() =>
          onUpdate(node.worker, {
            name: name || undefined,
            host: host || undefined,
            port: port === '' ? undefined : parseInt(port, 10),
            connection_type: type || undefined,
          })
        }
      >
        Зберегти
      </button>
    </div>
  )
}
