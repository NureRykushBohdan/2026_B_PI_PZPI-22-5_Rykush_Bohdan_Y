import { Play, ImageOff } from 'lucide-react'; // ImageOff - іконка заглушка

export default function HorizontalSection({ title, items, onItemClick }) {
  return (
    <div className="mb-6">
      <h3 className="px-6 text-xl font-bold mb-3 flex items-center gap-2 text-white">
        {title}
      </h3>
      
      <div className="flex gap-3 overflow-x-auto snap-x snap-mandatory no-scrollbar">
        <div className="w-3 flex-shrink-0 snap-start" />

        {items.map((item, idx) => (
          <div 
            key={item.id || idx} 
            onClick={() => onItemClick && onItemClick(idx)}
            className="flex-shrink-0 w-36 snap-start group cursor-pointer"
          >
            <div className="w-36 h-36 mb-2 relative overflow-hidden rounded-xl bg-gray-800">
               {item.cover ? (
                   <img 
                     src={item.cover} 
                     className="w-full h-full object-cover group-hover:scale-110 transition duration-500" 
                     alt={item.title} 
                     loading="lazy"
                   />
               ) : (
                   <div className="w-full h-full flex items-center justify-center text-gray-600">
                       <ImageOff size={32} />
                   </div>
               )}
               
               <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center">
                 <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center pl-1 shadow-lg transform group-hover:scale-110 transition">
                    <Play size={20} fill="black" className="text-black" />
                 </div>
               </div>
            </div>
            
            <p className="font-semibold text-sm truncate text-white">{item.title}</p>
            <p className="text-xs text-gray-400 truncate">{item.artist || item.desc}</p>
          </div>
        ))}

        <div className="w-3 flex-shrink-0 snap-start" />
      </div>
    </div>
  );
}