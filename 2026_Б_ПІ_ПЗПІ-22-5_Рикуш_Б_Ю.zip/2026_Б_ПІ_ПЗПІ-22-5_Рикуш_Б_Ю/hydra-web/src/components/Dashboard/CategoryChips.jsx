export default function CategoryChips({ categories }) {
  return (
    <div className="flex gap-3 overflow-x-auto px-6  pt-2 no-scrollbar mask-gradient">
      {categories.map((cat) => (
        <button 
          key={cat}
          className="whitespace-nowrap px-5 py-2 rounded-lg bg-white/10 border border-white/5 text-sm font-medium hover:bg-white/20 transition active:scale-95 first:ml-0 last:mr-6"
        >
          {cat}
        </button>
      ))}
    </div>
  );
}