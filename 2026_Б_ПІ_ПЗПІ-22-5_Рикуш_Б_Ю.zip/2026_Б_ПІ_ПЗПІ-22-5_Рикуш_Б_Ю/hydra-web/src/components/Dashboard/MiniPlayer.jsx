import { Play, Pause } from 'lucide-react';
import { motion } from 'framer-motion';

// Додали props: progress, duration, onSeek
export default function MiniPlayer({ track, isPlaying, onPlayPause, onExpand, progress, duration, onSeek }) {
  if (!track) return null;

  // Розрахунок відсотка для зафарбовування лінії
  const percentage = duration > 0 ? (progress / duration) * 100 : 0;

  return (
    <motion.div 
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      onClick={onExpand}
      className="fixed bottom-[80px] left-0 right-0 h-14 bg-[#212121] border-t border-white/10 flex items-center px-4 z-30 cursor-pointer"
    >
      {/* --- ІНТЕРАКТИВНИЙ ПРОГРЕС-БАР (Зверху) --- */}
      <div 
        className="absolute top-[-2px] left-0 right-0 h-[4px] w-full flex items-end group"
        onClick={(e) => e.stopPropagation()} // Щоб клік по бару не відкривав фулскрін
      >
        <input 
            type="range" 
            min="0" 
            max={duration || 0} 
            value={progress || 0} 
            onChange={(e) => onSeek(Number(e.target.value))}
            className="w-full h-[2px] appearance-none cursor-pointer bg-white/20 hover:h-[4px] transition-all"
            style={{ 
                background: `linear-gradient(to right, #a855f7 ${percentage}%, rgba(255,255,255,0.2) ${percentage}%)` 
            }}
        />
      </div>

      {/* Обкладинка */}
      <img 
        src={track.cover || "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=100&h=100&fit=crop"} 
        className="w-10 h-10 rounded object-cover" 
        alt="cover" 
      />
      
      {/* Інфо */}
      <div className="flex-1 ml-3 overflow-hidden">
        <p className="text-sm font-medium text-white truncate">{track.title}</p>
        <p className="text-xs text-gray-400 truncate">{track.artist}</p>
      </div>

      {/* Кнопка Play/Pause */}
      <button 
        onClick={(e) => { e.stopPropagation(); onPlayPause(); }}
        className="p-2 text-white hover:scale-110 transition active:scale-95 bg-transparent"
      >
        {isPlaying ? <Pause size={24} fill="white"/> : <Play size={24} fill="white"/>}
      </button>
    </motion.div>
  );
}