import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Play, Loader2, User } from 'lucide-react';
import { fetchWithAsyncContract } from '../utils/asyncApi';
import { useLanguage } from '../context/LanguageContext';

export default function ArtistPage({ onTrackSelect }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [artist, setArtist] = useState(null);
  const [tracks, setTracks] = useState([]);
  const [albums, setAlbums] = useState([]);
  const [similar, setSimilar] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const data = await fetchWithAsyncContract(`/api/artist/${decodeURIComponent(id)}`);
        if (data) {
          setArtist(data);
          setTracks(data.items || []);
          setAlbums(data.albums || []);
          setSimilar(data.similar_artists || []);
        }
      } catch (e) {
        console.error('Artist load error:', e);
      } finally {
        setLoading(false);
      }
    };
    if (id) load();
  }, [id]);

  const handlePlayAll = () => {
    if (tracks.length > 0) onTrackSelect(tracks[0], tracks, 0);
  };

  return (
    <div className="w-full min-h-screen bg-[#09090b] pb-40 animate-fade-in">
      <div className="relative pt-20 pb-8 px-6 bg-gradient-to-b from-pink-900/40 to-[#09090b]">
        <button
          onClick={() => navigate(-1)}
          className="absolute top-6 left-6 p-2 bg-white/10 rounded-full hover:bg-white/20 transition backdrop-blur-md z-10"
        >
          <ArrowLeft size={24} className="text-white" />
        </button>

        <div className="flex flex-col items-center mt-4 text-center">
          {artist?.cover ? (
            <img src={artist.cover} alt="" className="w-36 h-36 rounded-full object-cover shadow-2xl mb-4" />
          ) : (
            <div className="w-36 h-36 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center mb-4">
              <User size={64} className="text-white/80" />
            </div>
          )}
          <span className="text-xs font-bold uppercase tracking-widest text-white/60">{t('page_artist')}</span>
          <h1 className="text-3xl font-extrabold text-white mt-1">{artist?.title || decodeURIComponent(id)}</h1>
          {!loading && tracks.length > 0 && (
            <button
              onClick={handlePlayAll}
              className="mt-4 flex items-center gap-2 bg-green-500 hover:bg-green-400 text-black font-bold py-3 px-8 rounded-full transition"
            >
              <Play size={20} fill="black" />
              <span>{t('play_all')}</span>
            </button>
          )}
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="animate-spin text-purple-500" size={40} />
        </div>
      ) : (
        <>
          {tracks.length > 0 && (
            <section className="px-6 mt-4">
              <h2 className="text-lg font-bold text-white mb-3">{t('top_tracks')}</h2>
              {tracks.slice(0, 10).map((track, idx) => (
                <div
                  key={track.id + idx}
                  onClick={() => onTrackSelect(track, tracks, idx)}
                  className="flex items-center gap-4 py-3 border-b border-white/5 cursor-pointer hover:bg-white/5 px-2 rounded-lg"
                >
                  <span className="text-white/40 w-6">{idx + 1}</span>
                  <img src={track.cover} alt="" className="w-12 h-12 rounded object-cover" />
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-medium truncate">{track.title}</p>
                  </div>
                </div>
              ))}
            </section>
          )}

          {albums.length > 0 && (
            <section className="px-6 mt-8">
              <h2 className="text-lg font-bold text-white mb-3">{t('section_albums')}</h2>
              <div className="flex gap-4 overflow-x-auto pb-4">
                {albums.map((a) => (
                  <div
                    key={a.id}
                    onClick={() => navigate(`/album/${a.id}`)}
                    className="min-w-[140px] cursor-pointer group"
                  >
                    <img src={a.cover} alt="" className="w-[140px] h-[140px] rounded-lg object-cover group-hover:scale-105 transition" />
                    <p className="text-white text-sm font-medium mt-2 truncate">{a.title}</p>
                  </div>
                ))}
              </div>
            </section>
          )}

          {similar.length > 0 && (
            <section className="px-6 mt-8 mb-8">
              <h2 className="text-lg font-bold text-white mb-3">{t('similar_artists')}</h2>
              <div className="flex gap-4 overflow-x-auto pb-4">
                {similar.map((s) => (
                  <div
                    key={s.id}
                    onClick={() => navigate(`/artist/${encodeURIComponent(s.id)}`)}
                    className="min-w-[100px] cursor-pointer text-center"
                  >
                    {s.cover ? (
                      <img src={s.cover} alt="" className="w-20 h-20 rounded-full object-cover mx-auto" />
                    ) : (
                      <div className="w-20 h-20 rounded-full bg-white/10 mx-auto flex items-center justify-center">
                        <User size={32} className="text-white/60" />
                      </div>
                    )}
                    <p className="text-white text-xs mt-2 truncate">{s.title}</p>
                  </div>
                ))}
              </div>
            </section>
          )}
        </>
      )}
    </div>
  );
}
