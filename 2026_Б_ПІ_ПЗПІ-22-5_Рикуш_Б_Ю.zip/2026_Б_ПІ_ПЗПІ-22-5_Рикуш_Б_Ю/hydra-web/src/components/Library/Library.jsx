import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    Search, Heart, ChevronLeft, ChevronRight, X, ListMusic, Plus, 
    Loader2, Send, SlidersHorizontal, ArrowUp, ArrowDown, AlertCircle, Check,
    Edit3, Trash2, Copy, Share2, Save, CheckCircle2, Circle, CheckSquare,Globe, Lock
} from 'lucide-react';
import { useSearch } from '../../context/SearchContext';
import { useFavorites } from '../../context/FavoritesContext';
import { useLanguage } from '../../context/LanguageContext';
import SearchResults from '../Search/SearchResults';
import SettingsPage from './SettingsPage';
import LibraryHeader from './LibraryHeader'; 
import { apiClient } from '../../config';
import { useLocation } from 'react-router-dom';

export default function Library({ onTrackSelect }) {
  const { isSearchOpen, setIsSearchOpen, searchQuery, setSearchQuery, closeSearch } = useSearch();
  const { likedTracks } = useFavorites();
  const { t } = useLanguage();
  const [isPublic, setIsPublic] = useState(true);
  // Views
  const [currentView, setCurrentView] = useState('home'); 
  const [activePlaylist, setActivePlaylist] = useState(null); 
  const [playlistTracks, setPlaylistTracks] = useState([]); 
  const [myPlaylists, setMyPlaylists] = useState([]);
  const [loadingPlaylists, setLoadingPlaylists] = useState(false);
  const location = useLocation();
  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importUrl, setImportUrl] = useState('');
  const [importLoading, setImportLoading] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  
  // Selection Mode
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedTrackIds, setSelectedTrackIds] = useState(new Set());

  // Forms & Confirmations
  const [newPlaylistTitle, setNewPlaylistTitle] = useState('');
  const [editTitle, setEditTitle] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [isConfirmingDelete, setIsConfirmingDelete] = useState(false);

  // Sorting
  const [sortOrder, setSortOrder] = useState('date');
  const [sortDirection, setSortDirection] = useState('desc');
  
  // Action States
  const [isConfirmingSend, setIsConfirmingSend] = useState(false);
  const [isSent, setIsSent] = useState(false);
  const [isCopied, setIsCopied] = useState(false); 

  const fetchPlaylists = async () => {
      setLoadingPlaylists(true);
      try {
          const res = await apiClient.get('/api/library/playlists');
          setMyPlaylists(res.data);
      } catch (e) { console.error(e); } finally { setLoadingPlaylists(false); }
  };

  useEffect(() => { if (currentView === 'home') fetchPlaylists(); }, [currentView]);

  useEffect(() => {
      if (currentView !== 'playlist') {
          setIsSelectionMode(false);
          setSelectedTrackIds(new Set());
          setIsConfirmingDelete(false);
      }
  }, [currentView]);

  useEffect(() => {
      if (location.state?.view) {
          setCurrentView(location.state.view);
          // Очищаємо state, щоб не застрягло при оновленні (опціонально)
          window.history.replaceState({}, document.title);
      }
  }, [location.state]);
  
  const handleCreatePlaylist = async () => {
    if (!newPlaylistTitle.trim()) return;
    setIsCreating(true);
    try {
        await apiClient.post('/api/library/playlists', null, {
            params: { 
                title: newPlaylistTitle,
                is_public: isPublic 
            } 
        });
        setNewPlaylistTitle(''); 
        setIsPublic(true); // Скидаємо на дефолт
        setIsCreateModalOpen(false); 
        fetchPlaylists(); 
    } catch (e) { 
        console.error(e); 
    } finally { 
        setIsCreating(false); 
    }
};

  const openPlaylist = async (playlistItem) => {
      setActivePlaylist(playlistItem); 
      setPlaylistTracks([]); 
      setCurrentView('playlist');
      try {
          const detailsRes = await apiClient.get(`/api/library/playlists/${playlistItem.id}`);
          setActivePlaylist(detailsRes.data); 
          const tracksRes = await apiClient.get(`/api/library/playlists/${playlistItem.id}/tracks`);
          setPlaylistTracks(tracksRes.data);
      } catch (e) { console.error(e); }
  };

  const toggleSelectionMode = () => {
      setIsSelectionMode(!isSelectionMode);
      setSelectedTrackIds(new Set());
      setIsSettingsOpen(false);
      setIsConfirmingDelete(false);
  };

  const toggleTrackSelection = (trackId) => {
      const newSelected = new Set(selectedTrackIds);
      if (newSelected.has(trackId)) newSelected.delete(trackId);
      else newSelected.add(trackId);
      setSelectedTrackIds(newSelected);
  };

  const handleDeleteSelectedTracks = async () => {
      if (!isConfirmingDelete) {
          setIsConfirmingDelete(true);
          setTimeout(() => setIsConfirmingDelete(false), 3000);
          return;
      }
      if (selectedTrackIds.size === 0) return;
      try {
          await apiClient.post(`/api/library/playlists/${activePlaylist.id}/remove-tracks`, {
              track_ids: Array.from(selectedTrackIds)
          });
          setPlaylistTracks(prev => prev.filter(t => !selectedTrackIds.has(t.id || t.source_id)));
          setIsSelectionMode(false);
          setSelectedTrackIds(new Set());
          setIsConfirmingDelete(false);
      } catch (e) { console.error(e); setIsConfirmingDelete(false); }
  };

  const handleUpdatePlaylist = async () => {
      if (!editTitle.trim() || !activePlaylist) return;
      setIsCreating(true);
      try {
          await apiClient.put(`/api/library/playlists/${activePlaylist.id}`, null, {
              params: { title: editTitle, description: editDesc }
          });
          setActivePlaylist(prev => ({ ...prev, title: editTitle, description: editDesc }));
          setIsEditModalOpen(false);
          fetchPlaylists(); 
      } catch (e) { console.error(e); } finally { setIsCreating(false); }
  };

  const [isConfirmingPlaylistDelete, setIsConfirmingPlaylistDelete] = useState(false);

  const handleDeletePlaylist = async () => {
      if (!activePlaylist) return;
      
      if (!isConfirmingPlaylistDelete) {
          setIsConfirmingPlaylistDelete(true);
          // Скидаємо через 3 секунди, якщо передумав
          setTimeout(() => setIsConfirmingPlaylistDelete(false), 3000);
          return;
      }

      try {
          await apiClient.delete(`/api/library/playlists/${activePlaylist.id}`);
          setIsSettingsOpen(false);
          setIsConfirmingPlaylistDelete(false); // Скидаємо стан
          setCurrentView('home');
          fetchPlaylists();
      } catch (e) { 
          console.error(e); 
          setIsConfirmingPlaylistDelete(false);
      }
  };

  const handleDuplicatePlaylist = async () => {
      if (!activePlaylist) return;
      if (!confirm(t('confirm_duplicate_playlist'))) return;
      try {
          await apiClient.post(`/api/library/playlists/${activePlaylist.id}/duplicate`);
          setIsSettingsOpen(false);
          fetchPlaylists(); 
      } catch (e) { console.error(e); }
  };

  const handleShare = () => {
      if (!activePlaylist) return;
      const url = `${window.location.origin}/playlist/${activePlaylist.id}`; 
      navigator.clipboard.writeText(url).then(() => {
          setIsCopied(true);
          setTimeout(() => setIsCopied(false), 2000);
      });
  };

  const handleSortClick = (type) => {
      if (sortOrder === type) {
          setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
      } else {
          setSortOrder(type);
          setSortDirection(type === 'date' ? 'desc' : 'asc');
      }
  };

  const getDisplayedTracks = () => {
      const source = currentView === 'liked' ? likedTracks : playlistTracks;
      let tracks = [...source];
      if (sortOrder === 'title') tracks.sort((a, b) => a.title.localeCompare(b.title));
      else if (sortOrder === 'artist') tracks.sort((a, b) => (a.artist || "").localeCompare(b.artist || ""));
      if (sortDirection === 'desc' && sortOrder !== 'date') tracks.reverse(); 
      if (sortDirection === 'asc' && sortOrder === 'date') tracks.reverse(); 
      return tracks;
  };

  const displayedTracks = getDisplayedTracks();

  const handleTrackClick = (track) => {
      if (isSelectionMode) toggleTrackSelection(track.id || track.source_id);
      else {
          const index = displayedTracks.findIndex(t => (t.id || t.source_id) === (track.id || track.source_id));
          onTrackSelect(track, displayedTracks, index !== -1 ? index : 0);
      }
  };

  const handleSendClick = () => {
      if (isSent) return;
      if (isConfirmingSend) executeSendToChat();
      else {
          setIsConfirmingSend(true);
          setTimeout(() => setIsConfirmingSend(false), 3000);
      }
  };

  const executeSendToChat = async () => {
      const isLikedList = currentView === 'liked';
      try {
          if (isLikedList) await apiClient.post('/api/favorites/send-to-chat');
          else if (activePlaylist) await apiClient.post(`/api/library/playlists/${activePlaylist.id}/send-to-chat`);
          else return;
          setIsSent(true);
          setIsConfirmingSend(false);
          setTimeout(() => { setIsSettingsOpen(false); setTimeout(() => setIsSent(false), 300); }, 1500);
      } catch (e) { console.error(e); setIsConfirmingSend(false); }
  };

  // --- RENDER ---
  return (
    <div className="w-full pb-1 animate-fade-in ">
      
      {/* 1. SETTINGS VIEW */}
      {currentView === 'settings' && (
          <SettingsPage onBack={() => setCurrentView('home')} />
      )}

      {/* 2. SEARCH BAR */}
      {isSearchOpen && currentView === 'home' && (
        <div className="px-6 pt-12 pb-4 sticky top-0 bg-[#09090b]/95 backdrop-blur-xl z-30 min-h-[80px] flex items-center border-b border-white/5 shadow-lg shadow-black/20">
                <div className="w-full flex items-center gap-3">
                    <div className="flex-1 relative">
                        <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input autoFocus type="text" placeholder={t('search_placeholder')} value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full bg-[#1A1A1A] border border-white/10 rounded-full py-2 pl-10 pr-4 text-sm text-white focus:outline-none focus:border-purple-500" />
                    </div>
                    <button onClick={closeSearch} className="text-sm text-gray-400 hover:text-white">{t('cancel')}</button>
                </div>
           </div>
      )}

      <div className="animate-fade-in">
          {isSearchOpen && searchQuery && currentView === 'home' ? (
             <SearchResults onResultClick={(track) => onTrackSelect(track)} />
          ) : (currentView === 'liked' || currentView === 'playlist') ? (
             
             // --- PLAYLIST / LIKED VIEW ---
             <div className="fixed inset-0 z-50 bg-[#09090b] flex flex-col animate-slide-in">
                {/* HEADER */}
                <div className="px-6 pt-12 pb-4 sticky top-0 z-40 bg-[#09090b]/90 backdrop-blur-xl border-b border-white/5 flex items-center justify-between gap-4 shadow-sm">
                    <button onClick={() => isSelectionMode ? toggleSelectionMode() : setCurrentView('home')} className="p-2 -ml-2 rounded-full hover:bg-white/10 transition text-white">
                        {isSelectionMode ? <X size={24} /> : <ChevronLeft size={28} />}
                    </button>
                    <div className="flex-1 flex flex-col items-center justify-center min-w-0 px-2">
                        {isSelectionMode ? (
                            <h2 className="text-lg font-bold text-white">{t('selected')}: {selectedTrackIds.size}</h2>
                        ) : (
                            <>
                                <h2 className="text-lg font-bold text-white truncate max-w-full">
                                    {currentView === 'liked' ? t('liked_songs') : activePlaylist?.title}
                                </h2>
                                {activePlaylist?.description && currentView !== 'liked' && (
                                    <p className="text-[10px] text-gray-500 truncate max-w-[200px]">{activePlaylist.description}</p>
                                )}
                                <p className="text-xs text-gray-400">
                                    {currentView === 'liked' ? likedTracks.length : playlistTracks.length} {t('tracks_count')}
                                </p>
                            </>
                        )}
                    </div>
                    {!isSelectionMode && (
                        <button onClick={() => setIsSettingsOpen(true)} className={`p-2 -mr-2 rounded-full hover:bg-white/10 transition ${isSettingsOpen ? 'text-purple-500' : 'text-white'}`}>
                            <SlidersHorizontal size={22} />
                        </button>
                    )}
                    {isSelectionMode && <div className="w-10"></div>}
                </div>

                {/* TRACKS LIST */}
                <div className="flex-1 overflow-y-auto custom-scrollbar px-2 pt-2 pb-24">
                    <div className="flex flex-col gap-0.5">
                        {displayedTracks.map((track, index) => {
                            const isSelected = selectedTrackIds.has(track.id || track.source_id);
                            return (
                                <div key={track.id || index} onClick={() => handleTrackClick(track)} className={`group flex items-center gap-3 p-2 rounded-xl transition cursor-pointer active:bg-white/20 ${isSelected ? 'bg-white/10' : 'hover:bg-white/5'}`}>
                                    {isSelectionMode && (
                                        <div className={`transition-colors flex-shrink-0 ${isSelected ? 'text-purple-500' : 'text-gray-600'}`}>
                                            {isSelected ? <CheckCircle2 size={22} fill="currentColor" className="text-purple-500" stroke="black" /> : <Circle size={22} />}
                                        </div>
                                    )}
                                    <img src={track.cover || "https://picsum.photos/200"} alt={track.title} className="w-12 h-12 rounded bg-gray-800 object-cover shadow-sm" />
                                    <div className="flex-1 min-w-0">
                                        <div className={`font-medium truncate text-base ${isSelected ? 'text-purple-300' : 'text-white'}`}>{track.title}</div>
                                        <div className="text-gray-400 text-sm truncate">{track.artist}</div>
                                    </div>
                                    <div className="text-sm text-gray-500 font-mono">
                                        {track.duration ? `${Math.floor(track.duration / 60)}:${String(track.duration % 60).padStart(2, '0')}` : ''}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>

                {/* DELETE BUTTON (Confirm) */}
                <AnimatePresence>
                    {isSelectionMode && selectedTrackIds.size > 0 && (
                        <motion.div initial={{ y: 100, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 100, opacity: 0 }} className="fixed bottom-40 left-0 right-0 flex justify-center z-[60] px-6 pointer-events-none">
                            <button onClick={handleDeleteSelectedTracks} className={`pointer-events-auto w-full max-w-sm font-bold py-4 rounded-2xl shadow-2xl flex items-center justify-center gap-2 active:scale-95 transition border backdrop-blur-md ${isConfirmingDelete ? 'bg-orange-600 border-orange-400/30 text-white' : 'bg-red-600 border-red-400/30 text-white'}`}>
                                {isConfirmingDelete ? <><AlertCircle size={20} /> {t('confirm_action')}</> : <><Trash2 size={20} /> {t('remove_tracks')} ({selectedTrackIds.size})</>}
                            </button>
                        </motion.div>
                    )}
                </AnimatePresence>
             </div>
          ) : (
             /* 3. HOME VIEW (MAIN LIBRARY LIST) */
             <>
                {!isSearchOpen && (
                    <LibraryHeader 
                        onSearchClick={() => setIsSearchOpen(true)}
                        onSettingsClick={() => setCurrentView('settings')}
                        title={t('library_title')}
                    />
                )}

                <div className="px-6 mt-2 mb-6">
                    <div onClick={() => setCurrentView('liked')} className="w-full p-4 rounded-2xl bg-gradient-to-br from-purple-700 to-blue-800 flex items-center gap-4 shadow-lg cursor-pointer active:scale-98 transition">
                        <div className="w-16 h-16 bg-white/20 rounded-lg flex items-center justify-center"><Heart className="w-8 h-8 text-white fill-white" /></div>
                        <div className="flex-1">
                            <h3 className="text-lg font-bold text-white">{t('liked_songs')}</h3>
                            <p className="text-sm text-white/70">{likedTracks.length} {t('tracks_count')}</p>
                        </div>
                        <ChevronRight className="text-white/50" />
                    </div>
                </div>
                
                <div className="px-6 pb-2 flex items-center justify-between">
                    <h3 className="text-white font-bold text-lg">{t('your_playlists')}</h3>
                    <div className="flex gap-2">
                    <button onClick={() => setIsImportModalOpen(true)} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition text-white text-xs px-3">{t('import_playlist')}</button>
                    <button onClick={() => setIsCreateModalOpen(true)} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition text-white active:scale-90"><Plus size={20} /></button>
                    </div>
                </div>
                
                <div className="px-6 space-y-2 pb-0">
                    {loadingPlaylists ? <div className="text-center py-4 text-gray-500"><Loader2 className="animate-spin inline"/></div> : myPlaylists.length === 0 ? <div className="text-gray-500 text-sm text-center py-8 border border-dashed border-white/10 rounded-xl">{t('no_playlists')}</div> : (
                        myPlaylists.map((item) => (
                            <div key={item.id} onClick={() => openPlaylist(item)} className="group flex items-center gap-4 p-2 rounded-xl hover:bg-white/5 transition cursor-pointer active:scale-98">
                                <div className="relative w-16 h-16 flex-shrink-0 overflow-hidden rounded-lg bg-[#222] flex items-center justify-center">
                                    {item.cover ? <img src={item.cover} className="w-full h-full object-cover" /> : <ListMusic className="text-gray-500" />}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <h4 className="text-base font-semibold text-white truncate">{item.title}</h4>
                                    <p className="text-sm text-gray-400">{t('playlists_title')}</p>
                                </div>
                            </div>
                        ))
                    )}
                </div>
             </>
          )}
      </div>

      {/* CREATE MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-sm flex items-center justify-center px-6">
            <div className="bg-[#1A1A1A] w-full max-w-sm rounded-2xl p-6 border border-white/10 shadow-2xl">
                <h3 className="text-xl font-bold text-white mb-4">{t('new_playlist')}</h3>
                
                {/* Input */}
                <input autoFocus type="text" placeholder={t('playlist_name_placeholder')} value={newPlaylistTitle} onChange={(e) => setNewPlaylistTitle(e.target.value)} className="w-full bg-[#2A2A2A] text-white px-4 py-3 rounded-xl outline-none focus:ring-2 focus:ring-purple-500 mb-4" />
                
                <div className="flex items-center justify-between mb-6 bg-white/5 p-3 rounded-xl">
                    <div className="flex flex-col">
                        <span className="text-sm font-bold text-white flex items-center gap-2">
                            {isPublic ? <Globe size={16} className="text-blue-400"/> : <Lock size={16} className="text-gray-400"/>}
                            {isPublic ? t('public_playlist') : t('private_playlist')}
                        </span>
                        <span className="text-[10px] text-gray-400">
                            {isPublic ? t('public_desc') : t('private_desc')}
                        </span>
                    </div>
                    
                    <button 
                        onClick={() => setIsPublic(!isPublic)}
                        className={`w-12 h-6 rounded-full p-1 transition-colors duration-300 relative ${isPublic ? 'bg-purple-600' : 'bg-gray-600'}`}
                    >
                        <motion.div 
                            layout 
                            className="w-4 h-4 bg-white rounded-full shadow-md"
                            animate={{ x: isPublic ? 24 : 0 }}
                        />
                    </button>
                </div>

                {/* Buttons */}
                <div className="flex gap-3">
                    <button onClick={() => setIsCreateModalOpen(false)} className="flex-1 py-3 rounded-xl bg-white/5 text-white hover:bg-white/10">{t('cancel')}</button>
                    <button disabled={!newPlaylistTitle.trim() || isCreating} onClick={handleCreatePlaylist} className="flex-1 py-3 rounded-xl bg-purple-600 text-white font-bold hover:bg-purple-500 disabled:opacity-50">{isCreating ? <Loader2 className="animate-spin"/> : t('create_playlist')}</button>
                </div>
            </div>
        </div>
      )}

      {/* EDIT MODAL */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-[80] bg-black/80 backdrop-blur-sm flex items-center justify-center px-6 animate-fade-in">
            <div className="bg-[#1A1A1A] w-full max-w-sm rounded-2xl p-6 border border-white/10 shadow-2xl">
                <h3 className="text-xl font-bold text-white mb-4">{t('edit_playlist')}</h3>
                <input type="text" value={editTitle} onChange={(e) => setEditTitle(e.target.value)} className="w-full bg-[#2A2A2A] text-white px-4 py-3 rounded-xl outline-none focus:ring-2 focus:ring-purple-500 mb-4" />
                <textarea rows={3} placeholder={t('playlist_desc_placeholder')} value={editDesc} onChange={(e) => setEditDesc(e.target.value)} className="w-full bg-[#2A2A2A] text-white px-4 py-3 rounded-xl outline-none focus:ring-2 focus:ring-purple-500 mb-6 resize-none" />
                <div className="flex gap-3">
                    <button onClick={() => setIsEditModalOpen(false)} className="flex-1 py-3 rounded-xl bg-white/5 text-white hover:bg-white/10">{t('cancel')}</button>
                    <button onClick={handleUpdatePlaylist} className="flex-1 py-3 rounded-xl bg-purple-600 text-white font-bold hover:bg-purple-500 flex justify-center items-center gap-2">
                        {isCreating ? <Loader2 className="animate-spin"/> : <Save size={18} />} {t('save_changes')}
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* SETTINGS SHEET */}
      <AnimatePresence>
         {isSettingsOpen && (
            <>
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsSettingsOpen(false)} className="fixed inset-0 bg-black/60 z-[60] backdrop-blur-sm" />
                <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }} transition={{ type: "spring", damping: 25, stiffness: 200 }} className="fixed bottom-0 left-0 right-0 z-[70] bg-[#121214] rounded-t-[2.5rem] border-t border-white/10 shadow-2xl pb-36 overflow-hidden">
                    <div className="w-full flex justify-center pt-4 pb-2" onClick={() => setIsSettingsOpen(false)}><div className="w-12 h-1.5 bg-gray-600 rounded-full" /></div>
                    <div className="px-6 pt-4 overflow-y-auto max-h-[70vh]">
                        <div className="flex items-center justify-between mb-6">
                            <h3 className="text-xl font-bold text-white">{t('manage')}</h3>
                            <button onClick={() => setIsSettingsOpen(false)} className="p-2 bg-white/5 rounded-full text-white hover:bg-white/10"><X size={20}/></button>
                        </div>
                        {activePlaylist?.is_owner && currentView !== 'liked' && (
                            <div className="mb-6 bg-white/5 rounded-2xl overflow-hidden">
                                <MenuRow icon={Edit3} label={t('edit_details')} onClick={() => { setEditTitle(activePlaylist.title); setEditDesc(activePlaylist.description || ''); setIsEditModalOpen(true); }} />
                                <div className="h-px bg-white/5 mx-4"/>
                                <MenuRow icon={CheckSquare} label={t('remove_tracks')} onClick={toggleSelectionMode} />
                            </div>
                        )}
                        {currentView !== 'liked' && (
                            <div className="mb-6 bg-white/5 rounded-2xl overflow-hidden">
                                <MenuRow icon={Share2} label={t('share_link')} onClick={handleShare} isSuccess={isCopied} successLabel={t('copied')} />
                                <div className="h-px bg-white/5 mx-4"/>
                                <MenuRow icon={Copy} label={t('duplicate')} onClick={handleDuplicatePlaylist} />
                            </div>
                        )}
                        
                        <div className="mb-6">
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 block ml-1">{t('sort_label')}</label>
                            <div className="grid grid-cols-3 gap-2">
                                <SortButton label={t('sort_date')} active={sortOrder === 'date'} direction={sortDirection} onClick={() => handleSortClick('date')} />
                                <SortButton label={t('sort_title')} active={sortOrder === 'title'} direction={sortDirection} onClick={() => handleSortClick('title')} />
                                <SortButton label={t('sort_artist')} active={sortOrder === 'artist'} direction={sortDirection} onClick={() => handleSortClick('artist')} />
                            </div>
                        </div>

                        <div className="mb-8">
                            <button onClick={handleSendClick} disabled={isSent} className={`w-full flex items-center justify-center gap-2 py-4 rounded-xl text-sm font-bold transition-all duration-300 active:scale-98 shadow-lg ${isSent ? 'bg-green-600 text-white' : isConfirmingSend ? 'bg-orange-600 hover:bg-orange-500 text-white' : 'bg-purple-600 hover:bg-purple-500 text-white'}`}>
                                {isSent ? <><Check size={18} /> {t('sent')}</> : isConfirmingSend ? <><AlertCircle size={18} /> {t('confirm_action')}</> : <><Send size={18} /> {t('send_to_telegram')}</>}
                            </button>
                            <p className="text-xs text-gray-500 text-center mt-3">{t('music_bot_hint')}</p>
                        </div>

                        {activePlaylist?.is_owner && currentView !== 'liked' && (
                            <div className="flex justify-center pb-4">
                                <button 
                                    onClick={handleDeletePlaylist} 
                                    className={`
                                        text-sm font-medium flex items-center gap-2 transition py-2 px-4 rounded-lg 
                                        ${isConfirmingPlaylistDelete 
                                            ? 'bg-red-600 text-white hover:bg-red-700' // Стиль при підтвердженні
                                            : 'text-red-500/80 hover:text-red-400 hover:bg-red-500/10' // Звичайний стиль
                                        }
                                    `}
                                >
                                    {isConfirmingPlaylistDelete ? (
                                        <>
                                            <AlertCircle size={16} /> {t('confirm_delete') || "Натисніть ще раз для видалення"}
                                        </>
                                    ) : (
                                        <>
                                            <Trash2 size={16} /> {t('delete_playlist')}
                                        </>
                                    )}
                                </button>
                            </div>
                        )}
                    </div>
                </motion.div>
            </>
         )}
      </AnimatePresence>

      {isImportModalOpen && (
        <div className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-sm flex items-center justify-center px-6">
            <div className="bg-[#1A1A1A] w-full max-w-sm rounded-2xl p-6 border border-white/10">
                <h3 className="text-xl font-bold text-white mb-4">{t('import_playlist')}</h3>
                <input
                    type="url"
                    placeholder="https://youtube.com/playlist?list=..."
                    value={importUrl}
                    onChange={(e) => setImportUrl(e.target.value)}
                    className="w-full bg-[#2A2A2A] text-white px-4 py-3 rounded-xl outline-none mb-4"
                />
                <div className="flex gap-3">
                    <button onClick={() => setIsImportModalOpen(false)} className="flex-1 py-3 bg-white/10 text-white rounded-xl">{t('cancel')}</button>
                    <button
                        disabled={!importUrl.trim() || importLoading}
                        onClick={async () => {
                            setImportLoading(true);
                            try {
                                const res = await apiClient.post('/api/library/playlists/import', { url: importUrl.trim() });
                                if (res.data?.playlist) {
                                    setMyPlaylists((prev) => [res.data.playlist, ...prev]);
                                    setIsImportModalOpen(false);
                                    setImportUrl('');
                                }
                            } catch (e) {
                                console.error('Import failed:', e);
                            } finally {
                                setImportLoading(false);
                            }
                        }}
                        className="flex-1 py-3 bg-purple-600 text-white rounded-xl font-bold disabled:opacity-50"
                    >
                        {importLoading ? t('loading') : t('import_playlist')}
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
}

// Допоміжні компоненти
const MenuRow = ({ icon: Icon, label, onClick, isSuccess, successLabel }) => (
    <button onClick={onClick} className="w-full flex items-center gap-4 p-4 hover:bg-white/5 transition active:bg-white/10 text-left">
        {isSuccess ? <Check size={20} className="text-green-500" /> : <Icon size={20} className="text-gray-400" />}
        <span className={`font-medium flex-1 ${isSuccess ? 'text-green-500' : 'text-white'}`}>
            {isSuccess ? successLabel : label}
        </span>
    </button>
);

const SortButton = ({ label, active, direction, onClick }) => (
    <button onClick={onClick} className={`flex items-center justify-center gap-1.5 py-3 rounded-xl text-xs sm:text-sm font-medium transition active:scale-95 ${active ? 'bg-white text-black' : 'bg-white/5 text-gray-400 hover:bg-white/10'}`}>
        {label}
        {active && (direction === 'asc' ? <ArrowUp size={14} strokeWidth={3}/> : <ArrowDown size={14} strokeWidth={3}/>)}
    </button>
);