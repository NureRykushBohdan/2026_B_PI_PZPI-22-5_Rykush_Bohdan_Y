import React from 'react';
import { Search, Settings } from 'lucide-react';

export default function LibraryHeader({ onSearchClick, onSettingsClick, title }) {
  return (
    <div className="sticky top-0 z-30 bg-[#09090b]/95 backdrop-blur-xl px-6 pt-12 pb-4 border-b border-white/5 flex items-center justify-between shadow-lg shadow-black/10">
      <h1 className="text-2xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-500 tracking-wide">
        {title}
      </h1>
      
      <div className="flex gap-2">
        <button 
          onClick={onSearchClick} 
          className="p-2.5 bg-white/5 rounded-full text-white hover:bg-white/10 transition active:scale-95 border border-white/5"
        >
          <Search size={20} />
        </button>
        <button 
          onClick={onSettingsClick} 
          className="p-2.5 bg-white/5 rounded-full text-white hover:bg-white/10 transition active:scale-95 border border-white/5"
        >
          <Settings size={20} />
        </button>
      </div>
    </div>
  );
}