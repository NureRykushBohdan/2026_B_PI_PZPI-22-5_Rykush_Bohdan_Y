import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, User, UserPlus, UserMinus, Loader2 } from 'lucide-react';
import { apiClient } from '../config';
import { useLanguage } from '../context/LanguageContext';

export default function UserProfilePage({ onPlaylistSelect }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const res = await apiClient.get(`/api/users/${id}/profile`);
      setProfile(res.data);
    } catch (e) {
      console.error('Profile load error:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (id) load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const toggleFollow = async () => {
    try {
      const res = await apiClient.post(`/api/users/${id}/follow`);
      setProfile((p) => ({
        ...p,
        is_following: res.data.status === 'followed',
        followers_count: (p.followers_count || 0) + (res.data.status === 'followed' ? 1 : -1),
      }));
    } catch (e) {
      console.error('Follow error:', e);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="animate-spin text-purple-500" size={40} />
      </div>
    );
  }

  if (!profile) return null;

  return (
    <div className="w-full min-h-screen bg-[#09090b] pb-40 px-6 pt-20">
      <button onClick={() => navigate(-1)} className="absolute top-6 left-6 p-2 bg-white/10 rounded-full">
        <ArrowLeft size={24} className="text-white" />
      </button>

      <div className="flex flex-col items-center text-center mt-4">
        <div className="w-24 h-24 rounded-full bg-purple-600 flex items-center justify-center mb-4">
          <User size={48} className="text-white" />
        </div>
        <h1 className="text-2xl font-bold text-white">{profile.full_name || profile.username || `User ${profile.id}`}</h1>
        <p className="text-gray-400 text-sm">@{profile.username || profile.id}</p>
        <p className="text-gray-500 text-xs mt-2">
          {profile.followers_count} {t('followers')} · {profile.following_count} {t('following')}
        </p>
        <button
          onClick={toggleFollow}
          className={`mt-4 flex items-center gap-2 px-6 py-2 rounded-full font-bold ${
            profile.is_following ? 'bg-white/10 text-white' : 'bg-purple-600 text-white'
          }`}
        >
          {profile.is_following ? <UserMinus size={18} /> : <UserPlus size={18} />}
          {profile.is_following ? t('unfollow') : t('follow')}
        </button>
      </div>

      <section className="mt-8">
        <h2 className="text-lg font-bold text-white mb-4">{t('public_playlists')}</h2>
        {profile.playlists?.length ? (
          profile.playlists.map((p) => (
            <div
              key={p.id}
              onClick={() => onPlaylistSelect?.({ id: p.id, title: p.title, cover: p.cover })}
              className="flex items-center gap-4 py-3 cursor-pointer hover:bg-white/5 rounded-lg px-2"
            >
              {p.cover ? (
                <img src={p.cover} alt="" className="w-14 h-14 rounded object-cover" />
              ) : (
                <div className="w-14 h-14 rounded bg-white/10" />
              )}
              <div>
                <p className="text-white font-medium">{p.title}</p>
                <p className="text-gray-400 text-xs">{p.track_count} {t('tracks_count')}</p>
              </div>
            </div>
          ))
        ) : (
          <p className="text-gray-500 text-sm">{t('no_playlists')}</p>
        )}
      </section>
    </div>
  );
}
