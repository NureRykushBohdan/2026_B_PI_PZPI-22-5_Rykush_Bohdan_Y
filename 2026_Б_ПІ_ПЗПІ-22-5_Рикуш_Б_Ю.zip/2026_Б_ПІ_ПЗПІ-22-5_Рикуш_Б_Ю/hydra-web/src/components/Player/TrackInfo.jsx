import React from 'react';
import { Heart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useFavorites } from '../../context/FavoritesContext';

export default function TrackInfo({ track, onArtistClick }) {
  const { isFavorite, toggleFavorite } = useFavorites();
  const navigate = useNavigate();
  
  if (!track) return <div className="mt-8 mb-6 h-14"></div>;

  const trackId = track.id || track.source_id;
  const liked = isFavorite(trackId);

  const handleLike = (e) => {
      e.stopPropagation();
      toggleFavorite(track);
  };

  const handleArtist = (e) => {
      e.stopPropagation();
      if (onArtistClick) {
          onArtistClick(track);
          return;
      }
      const artist = track.artist;
      if (artist && artist !== 'Unknown') {
          navigate(`/artist/${encodeURIComponent(artist)}`);
      }
  };

  return (
    <div className="flex items-center justify-between mt-8 mb-6 w-full">
      <div className="flex-1 min-w-0 pr-4">
        <h2 className="text-2xl font-bold text-white truncate leading-tight">
          {track.title || "Unknown Title"}
        </h2>
        <button
          type="button"
          onClick={handleArtist}
          className="text-lg text-gray-400 truncate mt-1 hover:text-purple-400 hover:underline text-left w-full"
        >
          {track.artist || "Unknown Artist"}
        </button>
      </div>

      <button 
        onClick={handleLike}
        className="p-3 rounded-full hover:bg-white/10 transition active:scale-90 flex-shrink-0 touch-manipulation"
      >
        <Heart 
            size={28} 
            className={`transition-colors duration-300 ${liked ? "fill-purple-500 text-purple-500" : "text-white"}`} 
        />
      </button>
    </div>
  );
}