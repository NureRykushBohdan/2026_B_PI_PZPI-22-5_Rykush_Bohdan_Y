import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, MoreVertical, Mic2 } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { apiClient } from '../../config';

import Background from '../UI/Background';
import CoverArt from './CoverArt';
import TrackInfo from './TrackInfo';
import ProgressBar from './ProgressBar';
import Controls from './Controls';
import PlaylistSheet from '../PlaylistSheet';
import SimilarSheet from '../SimilarSheet';
import SyncedLyrics from './SyncedLyrics';

export default function FullScreenPlayer({
    player,
    selectedPlaylist,
    onClose,
    onOpenOptions,
    sleepRemaining = null,
}) {
    const { t } = useLanguage();
    const [activePanel, setActivePanel] = useState(null);
    const [lyrics, setLyrics] = useState(null);
    const [lyricsSynced, setLyricsSynced] = useState(false);
    const [lyricsLoading, setLyricsLoading] = useState(false);

    const track = player.track;

    useEffect(() => {
        if (activePanel !== 'lyrics' || !track) return;
        const loadLyrics = async () => {
            setLyricsLoading(true);
            setLyrics(null);
            setLyricsSynced(false);
            try {
                const tid = track.id || track.source_id;
                const res = await apiClient.get(`/api/lyrics/${tid}`, {
                    params: {
                        title: track.title,
                        artist: track.artist,
                        duration: track.duration,
                    },
                });
                setLyrics(res.data?.lyrics || null);
                setLyricsSynced(!!res.data?.synced);
            } catch {
                setLyrics(null);
                setLyricsSynced(false);
            } finally {
                setLyricsLoading(false);
            }
        };
        loadLyrics();
    }, [activePanel, track]);

    if (!track) return null;

    const getSourceLabel = () => {
        if (selectedPlaylist) return selectedPlaylist.title;
        if (track.source === 'r2') return t('search_result');
        return t('quick_start');
    };

    const formatSleep = (sec) => {
        const m = Math.floor(sec / 60);
        const s = sec % 60;
        return `${m}:${s < 10 ? '0' : ''}${s}`;
    };

    return (
        <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed top-0 left-0 right-0 z-[60] bg-[#09090b] flex flex-col overflow-hidden overscroll-contain"
            style={{ height: "var(--tg-viewport-stable-height, 100dvh)" }}
        >
            <Background cover={track.cover} />

            <div className="relative w-full z-10 flex justify-between items-center px-6 pt-[max(1.5rem,env(safe-area-inset-top))] pb-2 min-h-[60px] shrink-0">
                <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition">
                    <ChevronDown size={28} className="text-white" />
                </button>
                <div className="flex flex-col items-center">
                    <span className="text-[10px] font-bold tracking-[0.2em] uppercase text-white/60">
                        {t('now_playing')}
                    </span>
                    <span className="text-xs font-bold text-center px-4 truncate max-w-[200px] text-white">
                        {getSourceLabel()}
                    </span>
                    {sleepRemaining != null && (
                        <span className="text-[10px] text-purple-400 mt-0.5">
                            {t('sleep_timer')}: {formatSleep(sleepRemaining)}
                        </span>
                    )}
                </div>
                <button onClick={onOpenOptions} className="p-2 hover:bg-white/10 rounded-full transition active:scale-95">
                    <MoreVertical size={24} className="text-white" />
                </button>
            </div>

            <div className="relative flex-1 min-h-0 w-full max-w-md mx-auto z-10 flex flex-col px-8 py-2 justify-center overflow-y-auto">
                {activePanel !== 'lyrics' ? (
                    <>
                        <CoverArt cover={track.cover} isPlaying={player.isPlaying} />
                        <TrackInfo track={track} />
                        <ProgressBar progress={player.progress} duration={player.duration} onSeek={player.seek} />
                        <Controls
                            isPlaying={player.isPlaying}
                            onPlayPause={player.togglePlay}
                            onNext={player.nextTrack}
                            onPrev={player.prevTrack}
                            isShuffle={player.isShuffle}
                            repeatMode={player.repeatMode}
                            onToggleShuffle={player.toggleShuffle}
                            onToggleRepeat={player.toggleRepeat}
                            isCrossfade={player.crossfadeEnabled}
                            onToggleCrossfade={player.toggleCrossfade}
                        />
                    </>
                ) : (
                    <div className="flex flex-col flex-1 min-h-0 w-full -mx-2">
                        <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-white/40 text-center mb-2 shrink-0">
                            {t('lyrics_title')}
                        </p>
                        {lyricsLoading ? (
                            <p className="text-gray-400 text-center py-12">{t('loading')}</p>
                        ) : lyrics ? (
                            <SyncedLyrics
                                lyricsText={lyrics}
                                synced={lyricsSynced}
                                progress={player.progress}
                                duration={player.duration}
                                isPlaying={player.isPlaying}
                                onSeek={player.seek}
                            />
                        ) : (
                            <p className="text-gray-500 text-center py-12">{t('lyrics_not_found')}</p>
                        )}
                    </div>
                )}
            </div>

            <div className="relative w-full max-w-md mx-auto z-20 px-4 sm:px-6 pt-1 pb-[max(1.25rem,calc(env(safe-area-inset-bottom)+1.25rem))] flex flex-wrap justify-center gap-2 shrink-0">
                <button
                    onClick={() => setActivePanel(activePanel === 'similar' ? null : 'similar')}
                    className={`px-4 py-2.5 rounded-2xl border text-xs font-semibold ${activePanel === 'similar' ? 'bg-white text-black' : 'bg-white/5 border-white/10 text-white'}`}
                >
                    {t('btn_similar')}
                </button>
                <button
                    onClick={() => setActivePanel(activePanel === 'queue' ? null : 'queue')}
                    className={`px-4 py-2.5 rounded-2xl border text-xs font-semibold ${activePanel === 'queue' ? 'bg-white text-black' : 'bg-white/5 border-white/10 text-white'}`}
                >
                    {t('btn_queue')}
                </button>
                <button
                    onClick={() => setActivePanel(activePanel === 'lyrics' ? null : 'lyrics')}
                    className={`px-4 py-2.5 rounded-2xl border text-xs font-semibold flex items-center gap-1 ${activePanel === 'lyrics' ? 'bg-white text-black' : 'bg-white/5 border-white/10 text-white'}`}
                >
                    <Mic2 size={14} /> {t('lyrics_title')}
                </button>
            </div>

            <AnimatePresence>
                {activePanel === 'queue' && (
                    <PlaylistSheet
                        key="queue-panel"
                        isOpen={true}
                        onClose={() => setActivePanel(null)}
                        currentPlaylist={player.currentPlaylist}
                        currentIndex={player.currentIndex}
                        onSelect={(index) => player.selectTrack(index)}
                        onReorder={player.reorderPlaylist}
                        onRemove={player.removeFromQueue}
                    />
                )}

                {activePanel === 'similar' && (
                    <SimilarSheet
                        key="similar-panel"
                        isOpen={true}
                        onClose={() => setActivePanel(null)}
                        currentTrack={track}
                        onPlayTrack={(tr, list, index) => {
                            player.playNewContext(list, index);
                            setActivePanel(null);
                        }}
                    />
                )}
            </AnimatePresence>
        </motion.div>
    );
}
