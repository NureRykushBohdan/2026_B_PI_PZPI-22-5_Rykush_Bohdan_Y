import React, { useEffect, useMemo, useRef } from 'react';
import { motion } from 'framer-motion';
import {
  parseLrc,
  plainToSyncedLines,
  findActiveLineIndex,
  hasLrcTimestamps,
} from '../../utils/parseLrc';

import { useLanguage } from '../../context/LanguageContext';

export default function SyncedLyrics({
  lyricsText,
  synced,
  progress = 0,
  duration = 0,
  onSeek,
  isPlaying,
}) {
  const { t } = useLanguage();
  const containerRef = useRef(null);
  const lineRefs = useRef([]);

  const lines = useMemo(() => {
    if (!lyricsText) return [];
    if (synced || hasLrcTimestamps(lyricsText)) {
      const parsed = parseLrc(lyricsText);
      if (parsed.length > 0) return parsed;
    }
    return plainToSyncedLines(lyricsText, duration);
  }, [lyricsText, synced, duration]);

  const activeIndex = findActiveLineIndex(lines, progress);

  useEffect(() => {
    if (activeIndex < 0) return;
    const el = lineRefs.current[activeIndex];
    const container = containerRef.current;
    if (!el || !container) return;

    const elTop = el.offsetTop;
    const elHeight = el.offsetHeight;
    const containerHeight = container.clientHeight;
    const targetScroll = elTop - containerHeight / 2 + elHeight / 2;

    container.scrollTo({
      top: Math.max(0, targetScroll),
      behavior: 'smooth',
    });
  }, [activeIndex]);

  if (lines.length === 0) return null;

  return (
    <div
      ref={containerRef}
      className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden px-2 py-8 scroll-smooth [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
    >
      <div className="flex flex-col items-center gap-5 min-h-full justify-center py-[30vh]">
        {lines.map((line, i) => {
          const isActive = i === activeIndex;
          const distance = Math.abs(i - activeIndex);

          return (
            <motion.button
              key={`${line.time}-${i}-${line.text.slice(0, 20)}`}
              type="button"
              ref={(node) => { lineRefs.current[i] = node; }}
              onClick={() => onSeek?.(line.time)}
              animate={{
                opacity: isActive ? 1 : distance === 1 ? 0.55 : distance === 2 ? 0.35 : 0.22,
                scale: isActive ? 1.05 : 1,
              }}
              transition={{ duration: 0.25, ease: 'easeOut' }}
              className={`w-full text-center px-4 transition-colors duration-300 cursor-pointer select-none ${
                isActive
                  ? 'text-white text-xl sm:text-2xl font-bold leading-snug'
                  : 'text-white/80 text-base sm:text-lg font-medium leading-relaxed'
              }`}
            >
              {line.text}
            </motion.button>
          );
        })}
      </div>

      {!isPlaying && activeIndex >= 0 && (
        <p className="text-center text-[10px] text-white/30 pb-2 uppercase tracking-widest">
          {t('lyrics_tap_hint')}
        </p>
      )}
    </div>
  );
}
