import { motion } from 'framer-motion';

export default function CoverArt({ cover, isPlaying }) {
  return (
    <div className="flex-1 flex items-center justify-center py-4 min-h-0">
      <motion.div 
        className="relative w-auto h-auto max-h-full max-w-full aspect-square rounded-[2rem] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5)] ring-1 ring-white/10"
        animate={{ scale: isPlaying ? 1 : 0.92 }}
        transition={{ type: "spring", stiffness: 200, damping: 20 }}
      >
        <img src={cover} alt="Cover" className="w-full h-full object-cover" />
      </motion.div>
    </div>
  );
}