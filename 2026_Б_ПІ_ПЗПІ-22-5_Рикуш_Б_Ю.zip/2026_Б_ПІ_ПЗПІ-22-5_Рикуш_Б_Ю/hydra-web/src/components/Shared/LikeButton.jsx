import { Heart } from 'lucide-react';
import { useFavorites } from '../../context/FavoritesContext';
import { motion } from 'framer-motion';

export default function LikeButton({ track, size = 24, className = "" }) {
    const { isFavorite, toggleFavorite } = useFavorites();
    const liked = isFavorite(track.id);

    const handleClick = (e) => {
        e.stopPropagation(); // Щоб клік не запускав програвання треку
        toggleFavorite(track);
    };

    return (
        <motion.button
            whileTap={{ scale: 0.8 }}
            onClick={handleClick}
            className={`flex items-center justify-center transition-colors ${className}`}
        >
            <Heart 
                size={size} 
                className={`${liked ? "fill-purple-500 text-purple-500" : "text-gray-400 hover:text-white"}`}
            />
        </motion.button>
    );
}