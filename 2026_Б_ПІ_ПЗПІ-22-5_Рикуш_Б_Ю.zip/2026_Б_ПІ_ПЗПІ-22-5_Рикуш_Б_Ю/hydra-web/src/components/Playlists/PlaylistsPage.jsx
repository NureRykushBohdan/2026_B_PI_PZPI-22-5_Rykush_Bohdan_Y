import { Plus, Play, MoreVertical } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '../../context/LanguageContext';

export default function PlaylistsPage({ onPlaylistClick }) {
  const { t } = useLanguage();

  // Ці дані будуть статичними поки не підключимо API для всіх плейлистів
  const myPlaylists = [
    { id: 1, title: "Пісні для коду", tracks: 42, cover: "" },
    // ...
  ];

  return (
    <div className="w-full h-full pb-40 overflow-y-auto custom-scrollbar">
      {/* Header */}
      <div className="px-6 pt-8 pb-6 sticky top-0 bg-[#09090b]/90 backdrop-blur-xl z-20 flex justify-between items-end border-b border-white/5">
        <div>
          <h2 className="text-sm font-medium text-gray-400 uppercase tracking-widest mb-1">{t('my_media')}</h2>
          <h1 className="text-3xl font-bold text-white">{t('playlists_title')}</h1>
        </div>
        <button className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition active:scale-95">
           <Plus size={24} className="text-white" />
        </button>
      </div>

      {/* Grid */}
      <div className="p-6 grid grid-cols-2 gap-4">
        {/* Create New */}
        <motion.div 
          whileTap={{ scale: 0.98 }}
          className="aspect-square rounded-2xl bg-gradient-to-br from-purple-900/50 to-blue-900/50 border-2 border-dashed border-white/20 flex flex-col items-center justify-center cursor-pointer hover:border-white/40 transition group"
        >
            <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center mb-2 group-hover:scale-110 transition">
                <Plus size={24} className="text-white" />
            </div>
            <span className="text-sm font-semibold text-white/70">{t('create_new')}</span>
        </motion.div>

        {/* List (поки без перекладу назв плейлистів, бо це контент користувача) */}
        {myPlaylists.map((pl) => (
          <motion.div 
            key={pl.id}
            onClick={() => onPlaylistClick(pl)}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="flex flex-col gap-2 group cursor-pointer"
          >
            {/* ... той самий рендер картинки ... */}
            <div className="relative aspect-square rounded-2xl overflow-hidden bg-white/5">
              <img src={pl.cover} alt={pl.title} className="w-full h-full object-cover transition duration-500 group-hover:scale-110" />
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition" />
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition duration-300">
                  <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center hover:scale-110 transition">
                      <Play size={20} fill="white" className="ml-1 text-white" />
                  </div>
              </div>
            </div>
            <div>
               <h3 className="font-bold text-white text-base truncate pr-2">{pl.title}</h3>
               <p className="text-xs text-gray-400 font-medium">{pl.tracks} {t('tracks_count')}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}