import React, { useState, useEffect, useMemo } from 'react';
import { Search, Flame, Music2, User, Play, Heart, Loader2, Layers, Copy, Check, ListFilter, Clock, Calendar, ChevronDown, X } from 'lucide-react';
import { apiClient } from '../../config';
import { useLanguage } from '../../context/LanguageContext';

export default function CompilationsView({ onPlaylistClick }) {
  const { t } = useLanguage();

  const [playlists, setPlaylists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  
  const defaultCategory = t('category_all') || 'Всі';
  const [activeCategory, setActiveCategory] = useState(defaultCategory);
  
  const [sortOrder, setSortOrder] = useState('newest'); 
  const [showSortMenu, setShowSortMenu] = useState(false);
  
  const ITEMS_PER_PAGE = 18;
  const [visibleCount, setVisibleCount] = useState(ITEMS_PER_PAGE);

  const [clonedStatus, setClonedStatus] = useState({});

  useEffect(() => {
    fetchPlaylists();
  }, []);

  useEffect(() => {
      if (activeCategory === 'Всі' || activeCategory === 'All') {
          setActiveCategory(defaultCategory);
      }
  }, [t, defaultCategory, activeCategory]);

  useEffect(() => {
      setVisibleCount(ITEMS_PER_PAGE);
  }, [searchQuery, activeCategory, sortOrder]);

  const fetchPlaylists = async () => {
    setLoading(true);
    try {
      const res = await apiClient.get('/api/playlists/explore');
      setPlaylists(Array.isArray(res.data) ? res.data : []);
    } catch (error) {
      console.error("Failed to load compilations:", error);
      setPlaylists([]);
    } finally {
      setLoading(false);
    }
  };

  const handleLike = async (e, playlist) => {
      e.stopPropagation();
      const isLiked = playlist.is_liked;
      const newCount = isLiked ? playlist.likes_count - 1 : playlist.likes_count + 1;

      setPlaylists(prev => prev.map(p => 
          p.id === playlist.id ? { ...p, is_liked: !isLiked, likes_count: newCount } : p
      ));

      try {
          await apiClient.post(`/api/playlists/${playlist.id}/like`);
      } catch (error) {
          console.error("Like failed", error);
          setPlaylists(prev => prev.map(p => p.id === playlist.id ? playlist : p));
      }
  };

  const handleClone = async (e, playlist) => {
      e.stopPropagation();
      if (clonedStatus[playlist.id]) return;

      try {
          await apiClient.post(`/api/playlists/${playlist.id}/clone`);
          setClonedStatus(prev => ({ ...prev, [playlist.id]: true }));
          setTimeout(() => {
              setClonedStatus(prev => ({ ...prev, [playlist.id]: false }));
          }, 3000);
      } catch (error) {
          console.error("Clone failed", error);
          alert(t('error_clone_failed') || "Не вдалося скопіювати плейлист");
      }
  };

  const categories = useMemo(() => {
      const allTags = new Set([defaultCategory]);
      playlists.forEach(pl => {
          if (Array.isArray(pl.tags)) {
              pl.tags.forEach(tag => allTags.add(tag));
          }
      });
      return Array.from(allTags);
  }, [playlists, defaultCategory]);

  const filteredPlaylists = useMemo(() => {
    let result = playlists.filter(pl => {
      const matchesSearch = pl.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            (pl.author || '').toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = activeCategory === defaultCategory || (pl.tags && pl.tags.includes(activeCategory));
      return matchesSearch && matchesCategory;
    });

    if (sortOrder === 'popular') {
        result.sort((a, b) => b.likes_count - a.likes_count);
    } else if (sortOrder === 'oldest') {
        result.sort((a, b) => (a.created_at ? new Date(a.created_at) : a.id) - (b.created_at ? new Date(b.created_at) : b.id));
    } else {
        result.sort((a, b) => (b.created_at ? new Date(b.created_at) : b.id) - (a.created_at ? new Date(a.created_at) : a.id));
    }

    return result;
  }, [playlists, searchQuery, activeCategory, defaultCategory, sortOrder]);

  const trendingPlaylists = useMemo(() => {
      return [...playlists]
        .filter(pl => pl.likes_count > 0)
        .sort((a, b) => b.likes_count - a.likes_count)
        .slice(0, 6);
  }, [playlists]);

  const displayedPlaylists = filteredPlaylists.slice(0, visibleCount);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full min-h-[80vh] bg-[#09090b]">
        <Loader2 className="animate-spin text-purple-500" size={40} />
      </div>
    );
  }

  // --- UI КОМПОНЕНТИ ---

  const TrendingCard = ({ pl }) => (
      <div 
          onClick={() => onPlaylistClick(pl)}
          className="relative group w-full aspect-[3/4] rounded-2xl overflow-hidden bg-gray-900 shadow-xl border border-white/5"
      >
          {pl.cover ? (
              <img src={pl.cover} className="w-full h-full object-cover transition duration-700 group-hover:scale-105 opacity-80 group-hover:opacity-60" />
          ) : (
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-purple-900/40 to-blue-900/40">
                  <Music2 size={48} className="text-white/20" />
              </div>
          )}
          
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent p-4 flex flex-col justify-end">
              <h4 className="font-bold text-white text-lg leading-tight line-clamp-2 mb-1">{pl.title}</h4>
              <div className="flex items-center gap-2 mb-3">
                  <span className="text-[10px] text-gray-300 bg-white/10 px-2 py-0.5 rounded-full backdrop-blur-md flex items-center gap-1">
                      <User size={10} /> {pl.author || t('unknown_user') || 'User'}
                  </span>
                  <span className="text-[10px] text-orange-400 font-bold flex items-center gap-1">
                      <Heart size={10} className="fill-orange-400" /> {pl.likes_count}
                  </span>
              </div>

              <div className="flex items-center gap-2">
                  <button 
                      onClick={(e) => handleLike(e, pl)}
                      className={`flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 backdrop-blur-md transition ${pl.is_liked ? 'bg-pink-600 text-white' : 'bg-white/10 text-white hover:bg-white/20'}`}
                  >
                      <Heart size={14} className={pl.is_liked ? 'fill-white' : ''} />
                      {pl.is_liked ? t('liked') : t('like')}
                  </button>
                  {!pl.is_mine && (
                      <button 
                          onClick={(e) => handleClone(e, pl)}
                          className={`w-9 h-9 rounded-lg flex items-center justify-center backdrop-blur-md transition ${clonedStatus[pl.id] ? 'bg-green-500 text-white' : 'bg-white/10 text-white hover:bg-white/20'}`}
                      >
                          {clonedStatus[pl.id] ? <Check size={16} /> : <Copy size={16} />}
                      </button>
                  )}
              </div>
          </div>
      </div>
  );

  const StandardCard = ({ pl }) => (
      <div 
          onClick={() => onPlaylistClick(pl)}
          className="flex flex-col gap-2 group cursor-pointer"
      >
          <div className="relative aspect-square rounded-xl overflow-hidden bg-gray-800 shadow-sm border border-white/5">
              {pl.cover ? (
                  <img src={pl.cover} className="w-full h-full object-cover transition duration-300 group-hover:opacity-80" />
              ) : (
                  <div className="w-full h-full flex items-center justify-center bg-[#1A1A1A]">
                      <Music2 size={24} className="text-gray-600" />
                  </div>
              )}
              <div className="absolute bottom-1.5 right-1.5 bg-black/60 backdrop-blur-md px-1.5 py-0.5 rounded text-[9px] text-white font-bold flex items-center gap-1">
                  <Music2 size={9} /> {pl.track_count || 0}
              </div>
              
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition duration-200">
                  <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                      <Play size={18} className="fill-white text-white ml-0.5" />
                  </div>
              </div>
          </div>

          <div className="min-w-0">
              <h4 className="text-xs font-bold text-gray-100 truncate mb-0.5">{pl.title}</h4>
              <div className="flex items-center justify-between text-[10px] text-gray-500">
                  <span className="truncate max-w-[70%]">{pl.author || t('unknown_user') || 'User'}</span>
                  <button 
                      onClick={(e) => handleLike(e, pl)}
                      className="flex items-center gap-0.5 hover:text-white transition p-1 -mr-1"
                  >
                      <Heart 
                          size={20} 
                          className={pl.is_liked ? "fill-pink-500 text-pink-500" : "text-gray-500"} 
                      />
                      {pl.likes_count > 0 && <span>{pl.likes_count}</span>}
                  </button>
              </div>
          </div>
      </div>
  );

  return (
    <div className="w-full pb-0 animate-fade-in  " onClick={() => setShowSortMenu(false)}>
      
      {/* HEADER */}
      <div className="sticky top-0 z-20 bg-[#09090b]/90 backdrop-blur-xl px-6 pt-8 pb-4 flex flex-col gap-4 border-b border-white/5">
        
        {/* Title Row */}
        <div className="flex items-center justify-between">
            <h1 className="text-xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-500 tracking-wide">
                {t('page_compilations') || "Підбірки"}
            </h1>
        </div>

        {/* Search & Sort Row */}
        <div className="flex gap-2">
            <div className="relative group flex-1">
                <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
                    <Search size={16} className="text-gray-500 group-focus-within:text-purple-400 transition" />
                </div>
                <input 
                    type="text" 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={t('search_playlist_placeholder') || "Пошук..."}
                    className="w-full bg-white/5 border border-white/10 rounded-full py-2 pl-9 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:bg-white/10 focus:border-purple-500/50 transition"
                />
            </div>

            <div className="relative">
                <button 
                    onClick={(e) => { e.stopPropagation(); setShowSortMenu(!showSortMenu); }}
                    className={`h-full aspect-square flex items-center justify-center rounded-full border transition ${showSortMenu ? 'bg-purple-500/20 border-purple-500 text-purple-400' : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10 hover:text-white'}`}
                >
                    {showSortMenu ? <X size={18} /> : <ListFilter size={18} />}
                </button>

                {showSortMenu && (
                    <div className="absolute right-0 top-full mt-2 w-48 bg-[#18181b] border border-white/10 rounded-xl shadow-xl z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                        <div className="p-1 flex flex-col gap-0.5">
                            <button 
                                onClick={() => { setSortOrder('newest'); setShowSortMenu(false); }}
                                className={`flex items-center gap-2 px-3 py-2 text-xs font-medium rounded-lg transition ${sortOrder === 'newest' ? 'bg-purple-500/20 text-purple-400' : 'text-gray-300 hover:bg-white/5'}`}
                            >
                                <Clock size={14} /> {t('sort_newest') || "Новинки"}
                            </button>
                            <button 
                                onClick={() => { setSortOrder('popular'); setShowSortMenu(false); }}
                                className={`flex items-center gap-2 px-3 py-2 text-xs font-medium rounded-lg transition ${sortOrder === 'popular' ? 'bg-orange-500/20 text-orange-400' : 'text-gray-300 hover:bg-white/5'}`}
                            >
                                <Flame size={14} /> {t('sort_popular') || "Популярні"}
                            </button>
                            <button 
                                onClick={() => { setSortOrder('oldest'); setShowSortMenu(false); }}
                                className={`flex items-center gap-2 px-3 py-2 text-xs font-medium rounded-lg transition ${sortOrder === 'oldest' ? 'bg-blue-500/20 text-blue-400' : 'text-gray-300 hover:bg-white/5'}`}
                            >
                                <Calendar size={14} /> {t('sort_oldest') || "Старі"}
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </div>

        {/* Categories Row */}
        {categories.length > 1 && (
            <div className="flex gap-2 overflow-x-auto custom-scrollbar -mx-6 px-6 pb-1">
                {categories.map(cat => (
                    <button
                        key={cat}
                        onClick={() => setActiveCategory(cat)}
                        className={`px-3.5 py-1.5 rounded-full text-[11px] font-bold whitespace-nowrap transition active:scale-95 border ${
                            activeCategory === cat 
                            ? 'bg-white text-black border-white shadow-lg' 
                            : 'bg-white/5 text-gray-400 border-white/5 hover:bg-white/10 hover:text-white'
                        }`}
                    >
                        {cat}
                    </button>
                ))}
            </div>
        )}
      </div>

      <div className="space-y-2 pt-6 px-6">
        
        {/* EMPTY STATE */}
        {playlists.length === 0 && !loading && (
            <div className="flex flex-col items-center justify-center py-20 text-gray-500 gap-4 opacity-50">
                <Layers size={48} strokeWidth={1} />
                <p className="text-sm">{t('empty_state_title') || "Тут поки порожньо"}</p>
            </div>
        )}

        {/* TRENDING SECTION */}
        {activeCategory === defaultCategory && !searchQuery && trendingPlaylists.length > 0 && sortOrder === 'newest' && (
            <div className="flex flex-col gap-3 animate-slide-up mb-6">
                <div className="flex items-center gap-2 text-white/90">
                    <Flame size={18} className="text-orange-500 fill-orange-500" />
                    <h3 className="font-bold text-lg">{t('section_trending') || "У тренді"}</h3>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {trendingPlaylists.map((pl) => (
                        <TrendingCard key={pl.id} pl={pl} />
                    ))}
                </div>
            </div>
        )}

        {/* ALL RESULTS */}
        {filteredPlaylists.length > 0 && (
            <div className="flex flex-col gap-3 pb-1">
                <div className="flex items-center justify-between text-white/90">
                    <h3 className="font-bold text-lg">
                        {searchQuery ? (t('search_results') || 'Пошук') : (
                            sortOrder === 'popular' ? (t('sort_popular') || 'Популярні') :
                            sortOrder === 'oldest' ? (t('sort_oldest') || 'Архів') :
                            (activeCategory === defaultCategory ? (t('section_fresh') || 'Новинки') : activeCategory)
                        )}
                    </h3>
                    <span className="text-[10px] text-gray-500 bg-white/5 px-2 py-0.5 rounded-full">
                        {visibleCount < filteredPlaylists.length ? `${visibleCount} / ${filteredPlaylists.length}` : filteredPlaylists.length}
                    </span>
                </div>

                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
                    {displayedPlaylists.map((pl) => (
                        <StandardCard key={pl.id} pl={pl} />
                    ))}
                </div>

                {/* Load More Button */}
                {visibleCount < filteredPlaylists.length && (
                    <div className="flex justify-center mt-6">
                        <button 
                            onClick={(e) => { e.stopPropagation(); setVisibleCount(prev => prev + ITEMS_PER_PAGE); }}
                            className="flex items-center gap-2 px-5 py-2.5 bg-white/5 hover:bg-white/10 text-white text-xs font-bold rounded-full transition border border-white/5"
                        >
                            {t('load_more') || "Завантажити ще"}
                            <ChevronDown size={14} />
                        </button>
                    </div>
                )}
            </div>
        )}
      </div>
    </div>
  );
}