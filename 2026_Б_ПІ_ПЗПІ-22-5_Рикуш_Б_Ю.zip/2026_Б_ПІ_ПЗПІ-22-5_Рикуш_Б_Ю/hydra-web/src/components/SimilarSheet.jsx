import React, { useEffect, useState } from 'react';
import { X, Loader2, AlertCircle, Play } from 'lucide-react';
import { apiClient } from '../config';
import { useLanguage } from '../context/LanguageContext';

export default function SimilarSheet({ isOpen, onClose, currentTrack, onPlayTrack }) {
    const { t } = useLanguage();
    const [tracks, setTracks] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        if (!isOpen || !currentTrack) return;

        let isMounted = true;
        const trackId = currentTrack.id || currentTrack.source_id;

        const fetchRecommendations = async () => {
            setLoading(true);
            setError(null);
            setTracks([]);

            let attempts = 0;
            const maxAttempts = 30;

            try {
                while (attempts < maxAttempts) {
                    if (!isMounted) return;
                    try {
                        const res = await apiClient.get(`/api/recommendations/${trackId}`);
                        if (res.status === 200) {
                            if (isMounted) {
                                setTracks(res.data);
                                setLoading(false);
                            }
                            return;
                        }
                    } catch (err) {
                        if (err.response && err.response.status === 202) {
                            // Продовжуємо чекати
                        } else {
                            throw err;
                        }
                    }
                    await new Promise(r => setTimeout(r, 2000));
                    attempts++;
                }
                if (isMounted) setError(t('timeout_error'));
            } catch (err) {
                if (isMounted) {
                    setError(t('network_error'));
                    console.error(err);
                }
            } finally {
                if (isMounted) setLoading(false);
            }
        };

        fetchRecommendations();
        return () => { isMounted = false; };
    // id/source_id достатньо; повний currentTrack дав би зайві перезапити
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isOpen, currentTrack?.id, currentTrack?.source_id, t]);

    if (!isOpen) return null;

    return (
        <div className="absolute inset-0 z-50 bg-[#09090b]/95 backdrop-blur-xl flex flex-col animate-in slide-in-from-bottom duration-300">
            <div className="px-6 pt-6 pb-4 flex items-center justify-between border-b border-white/10">
                <div>
                    <h2 className="text-lg font-bold text-white">{t('similar_title')}</h2>
                    <p className="text-xs text-gray-400 max-w-[200px] truncate">
                        {t('based_on')} {currentTrack?.title}
                    </p>
                </div>
                <button onClick={onClose} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition">
                    <X size={20} className="text-white" />
                </button>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar p-4">
                {loading ? (
                    <div className="flex flex-col items-center justify-center h-full text-purple-400 gap-3">
                        <Loader2 size={40} className="animate-spin" />
                        <p className="text-sm font-medium">{t('ai_picking')}</p>
                    </div>
                ) : error ? (
                    <div className="flex flex-col items-center justify-center h-full text-red-400 gap-3">
                        <AlertCircle size={40} />
                        <p className="text-sm">{error}</p>
                    </div>
                ) : tracks.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-gray-500">
                        <p>{t('no_similar_content')}</p>
                    </div>
                ) : (
                    <div className="flex flex-col gap-2">
                        {tracks.map((track, index) => (
                            <div 
                                key={track.id || index}
                                onClick={() => onPlayTrack(track, tracks, index)}
                                className="flex items-center gap-3 p-3 rounded-xl bg-[#1A1A1A] border border-white/5 hover:bg-white/10 transition cursor-pointer group active:scale-98"
                            >
                                <div className="relative w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
                                    <img src={track.cover} alt={track.title} className="w-full h-full object-cover" />
                                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                                        <Play size={20} className="text-white fill-white" />
                                    </div>
                                </div>
                                <div className="flex-1 min-w-0">
                                    <h4 className="text-sm font-medium text-white truncate">{track.title}</h4>
                                    <p className="text-xs text-gray-400 truncate">{track.artist}</p>
                                </div>
                                <div className="text-xs text-gray-600 font-mono">
                                    {track.duration ? `${Math.floor(track.duration / 60)}:${String(track.duration % 60).padStart(2, '0')}` : ''}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}