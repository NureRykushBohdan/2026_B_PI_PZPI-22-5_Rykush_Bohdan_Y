import { X, Play, GripVertical, Trash2 } from 'lucide-react';
import { Reorder, useDragControls } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';

// Компонент одного рядка в списку (щоб ізолювати DragControls)
const QueueItem = ({ track, isActive, onClick, onRemove }) => {
  const controls = useDragControls();

  return (
    <Reorder.Item
      value={track}
      dragListener={false} // Тягнути тільки за іконку
      dragControls={controls}
      className={`flex items-center gap-3 p-3 rounded-xl border mb-2 transition-colors select-none ${
        isActive 
          ? 'bg-purple-500/10 border-purple-500/20' 
          : 'bg-[#1A1A1A] border-white/5 hover:bg-white/5'
      }`}
    >
      {/* Ручка для перетягування */}
      <div 
        onPointerDown={(e) => controls.start(e)}
        className="cursor-grab active:cursor-grabbing text-gray-500 hover:text-white touch-none"
      >
        <GripVertical size={20} />
      </div>

      {/* Обкладинка */}
      <div onClick={onClick} className="relative w-10 h-10 rounded-lg overflow-hidden flex-shrink-0 cursor-pointer">
        <img src={track.cover || "https://picsum.photos/200"} alt={track.title} className="w-full h-full object-cover" />
        {isActive && (
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
            <div className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-pulse" />
          </div>
        )}
      </div>

      {/* Інфо */}
      <div onClick={onClick} className="flex-1 min-w-0 cursor-pointer">
        <h4 className={`text-sm font-medium truncate ${isActive ? 'text-purple-400' : 'text-white'}`}>
          {track.title}
        </h4>
        <p className="text-xs text-gray-400 truncate">{track.artist}</p>
      </div>

      {/* Кнопка видалення */}
      <button 
        onClick={(e) => { e.stopPropagation(); onRemove(); }}
        className="p-2 text-gray-600 hover:text-red-400 hover:bg-white/5 rounded-full transition"
      >
        <Trash2 size={16} />
      </button>
    </Reorder.Item>
  );
};

export default function PlaylistSheet({ isOpen, onClose, currentPlaylist, currentIndex, onSelect, onReorder, onRemove }) {
  const { t } = useLanguage();

  if (!isOpen) return null;

  return (
    <div className="absolute inset-0 z-50 bg-[#09090b]/95 backdrop-blur-xl flex flex-col animate-in slide-in-from-bottom duration-300">
      
      {/* Header */}
      <div className="px-6 pt-6 pb-4 flex items-center justify-between border-b border-white/10">
        <div>
          <h2 className="text-lg font-bold text-white">{t('queue_title')}</h2>
          <p className="text-xs text-gray-400">{currentPlaylist.length} {t('tracks_count')}</p>
        </div>
        <button onClick={onClose} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition">
          <X size={20} className="text-white" />
        </button>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-4">
        {/* Reorder Group - Обгортка для списку */}
        <Reorder.Group 
            axis="y" 
            values={currentPlaylist} 
            onReorder={onReorder} 
            className="flex flex-col"
        >
          {currentPlaylist.map((track, index) => (
            <QueueItem 
                // Unique key when the same track appears more than once
                key={`${track.id || track.source_id}-${index}`} 
                
                track={track} 
                isActive={index === currentIndex}
                onClick={() => onSelect(index)}
                onRemove={() => onRemove(index)}
            />
          ))}
        </Reorder.Group>

        {currentPlaylist.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-gray-500 opacity-50 mt-20">
                <Play size={48} className="mb-2" />
                <p>{t('queue_empty')}</p>
            </div>
        )}
      </div>
    </div>
  );
}