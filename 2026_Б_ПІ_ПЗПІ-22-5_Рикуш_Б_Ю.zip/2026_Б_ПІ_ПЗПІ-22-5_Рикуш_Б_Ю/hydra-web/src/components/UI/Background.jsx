import { motion, AnimatePresence } from 'framer-motion';

export default function Background({ cover }) {
  return (
    <div className="absolute inset-0 z-0 pointer-events-none">
      <AnimatePresence mode="popLayout">
        <motion.div 
          key={cover}
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.5 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.5 }}
          className="absolute inset-0 bg-cover bg-center blur-[80px] scale-125"
          style={{ backgroundImage: `url(${cover})` }}
        />
      </AnimatePresence>
      <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-black/40 to-black/90" />
    </div>
  );
}