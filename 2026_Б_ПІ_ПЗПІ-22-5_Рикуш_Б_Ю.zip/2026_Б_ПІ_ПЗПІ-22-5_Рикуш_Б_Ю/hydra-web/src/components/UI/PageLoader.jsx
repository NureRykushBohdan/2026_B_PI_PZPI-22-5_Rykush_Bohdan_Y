import React from 'react';
import { Loader2 } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export default function PageLoader() {
  const { t } = useLanguage();

  return (
    <div className="w-full h-full min-h-[50vh] flex flex-col items-center justify-center text-gray-500 animate-fade-in">
      <Loader2 size={32} className="animate-spin mb-2 text-purple-500" />
      <p className="text-xs font-medium">{t('loading')}</p>
    </div>
  );
}