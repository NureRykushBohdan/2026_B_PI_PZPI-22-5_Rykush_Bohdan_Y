import { useState, useRef, useEffect } from 'react';
import { apiClient } from '../config';

const clampVolume = (value) => Math.min(1, Math.max(0, Number(value) || 0));

export function useAudioPlayer(initialPlaylist = []) {
  const [currentPlaylist, setCurrentPlaylist] = useState(initialPlaylist);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);

  // === НОВІ СТАНИ ДЛЯ ЧЕРГИ ===
  const [isShuffle, setIsShuffle] = useState(false);
  const [repeatMode, setRepeatMode] = useState('off'); // 'off' | 'all' | 'one'
  const [crossfadeEnabled, setCrossfadeEnabled] = useState(false);
  const [initialSeek, setInitialSeek] = useState(null);
  const crossfadeTriggeredRef = useRef(false);
  const volumeFadeRef = useRef({ raf: null, gen: 0 });
  const CROSSFADE_SEC = 2.5;

  const cancelVolumeFade = () => {
    if (volumeFadeRef.current.raf) {
      cancelAnimationFrame(volumeFadeRef.current.raf);
      volumeFadeRef.current.raf = null;
    }
    volumeFadeRef.current.gen += 1;
  };

  const setVolumeSafe = (audio, value) => {
    const v = clampVolume(value);
    try {
      audio.volume = v;
    } catch {
      try {
        audio.volume = v > 0 ? 1 : 0;
      } catch {
        /* ignore — element may be detached */
      }
    }
  };

  const runVolumeFade = (audio, from, to, durationMs, gen, onDone) => {
    const start = performance.now();
    const tick = () => {
      if (gen !== volumeFadeRef.current.gen) return;
      const t = clampVolume((performance.now() - start) / durationMs);
      setVolumeSafe(audio, from + (to - from) * t);
      if (t < 1) {
        volumeFadeRef.current.raf = requestAnimationFrame(tick);
      } else {
        volumeFadeRef.current.raf = null;
        onDone?.();
      }
    };
    volumeFadeRef.current.raf = requestAnimationFrame(tick);
  };

  const track = currentPlaylist[currentIndex] || null;
  const audioRef = useRef(new Audio());
  const nextTrackRef = useRef(() => {});
  const analyticsRef = useRef({ trackId: null, startTime: 0, playedMs: 0, hasSent: false });

  // ... (КОД АНАЛІТИКИ ЗАЛИШАЄТЬСЯ БЕЗ ЗМІН) ...
  useEffect(() => {
      const now = Date.now();
      const stat = analyticsRef.current;
      const currentId = track ? (track.id || track.source_id) : null;

      if (stat.trackId !== currentId) {
          if (stat.trackId) {
              let finalTime = stat.playedMs;
              if (stat.startTime > 0) finalTime += (now - stat.startTime);
              
              if (finalTime > 2000 && !stat.hasSent) {
                  const pos = audioRef.current?.currentTime || 0;
                  apiClient.post(`/api/analytics/listen/${stat.trackId}`, { playback_position: pos })
                      .then(() => console.log("✅ History saved"))
                      .catch(err => console.warn("❌ Failed:", err));
              } 
          }
          stat.trackId = currentId;
          stat.playedMs = 0;
          stat.hasSent = false;
          stat.startTime = (isPlaying && currentId) ? now : 0;
      } else {
          if (isPlaying) stat.startTime = now;
          else {
              if (stat.startTime > 0) {
                  stat.playedMs += (now - stat.startTime);
                  stat.startTime = 0; 
              }
          }
      }
  }, [track, isPlaying]);

  // ... (КОД ПОКРАЩЕННЯ ОБКЛАДИНКИ БЕЗ ЗМІН) ...
  useEffect(() => {
    if (!track || !track.cover) return;
    const checkImage = (url) => new Promise((resolve) => {
        const img = new Image();
        img.src = url;
        img.onload = () => resolve(img.width > 120);
        img.onerror = () => resolve(false);
    });
    const upgradeCover = async () => {
        if (!track.cover.includes("ytimg.com") && !track.cover.includes("youtube.com")) return;
        const videoIdMatch = track.cover.match(/\/vi\/([^/]+)\//);
        const videoId = videoIdMatch ? videoIdMatch[1] : (track.id || track.source_id);
        if (!videoId) return;
        const maxResUrl = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
        const sdResUrl = `https://img.youtube.com/vi/${videoId}/sddefault.jpg`;
        if (track.cover === maxResUrl || track.cover === sdResUrl) return;
        if (await checkImage(maxResUrl)) { updateCoverInPlaylist(maxResUrl); return; }
        if (await checkImage(sdResUrl)) { updateCoverInPlaylist(sdResUrl); return; }
    };
    const updateCoverInPlaylist = (newUrl) => {
        setCurrentPlaylist(prev => {
            const newPl = [...prev];
            if (newPl[currentIndex] && (newPl[currentIndex].id === track.id)) {
                newPl[currentIndex] = { ...newPl[currentIndex], cover: newUrl };
            }
            return newPl;
        });
    };
    upgradeCover();
  }, [currentIndex, track]);

  // ... (ЗАВАНТАЖЕННЯ АУДІО БЕЗ ЗМІН) ...
  useEffect(() => {
    const audio = audioRef.current;
    if (!track) { audio.pause(); audio.removeAttribute('src'); return; }
    const validUrl = track.r2_url || (track.url && !track.url.includes("youtube.com") ? track.url : null);

    if (validUrl) {
        if (audio.src !== validUrl && decodeURIComponent(audio.src) !== decodeURIComponent(validUrl)) {
            console.log("💿 [Player] Load:", track.title);
            audio.pause(); audio.src = validUrl; audio.load();
            queueMicrotask(() => {
              setProgress(0);
              if (initialSeek != null && initialSeek > 0) {
                audio.currentTime = initialSeek;
                setProgress(initialSeek);
                setInitialSeek(null);
              }
            });
            if (isPlaying) audio.play().catch(e => e.name !== 'AbortError' && console.log(e));
        } else {
            if (isPlaying && audio.paused) audio.play().catch(() => {});
            if (!isPlaying && !audio.paused) audio.pause();
        }
    } else {
        audio.pause();
    }
  }, [currentIndex, track, track?.r2_url, track?.url, isPlaying]);

  // Crossfade: плавний перехід між треками (затухання → наступний трек → наростання)
  useEffect(() => {
    crossfadeTriggeredRef.current = false;
    const audio = audioRef.current;
    if (!crossfadeEnabled) {
      cancelVolumeFade();
      setVolumeSafe(audio, 1);
      return;
    }
    if (!isPlaying) {
      setVolumeSafe(audio, 1);
      return;
    }

    cancelVolumeFade();
    const gen = volumeFadeRef.current.gen;
    setVolumeSafe(audio, 0);
    runVolumeFade(audio, 0, 1, 700, gen, null);
    return () => cancelVolumeFade();
  }, [currentIndex, crossfadeEnabled, isPlaying]);

  useEffect(() => {
    if (!crossfadeEnabled || !isPlaying) return;
    const audio = audioRef.current;

    const onTimeUpdate = () => {
      const dur = audio.duration;
      if (!dur || isNaN(dur) || dur < CROSSFADE_SEC + 1) return;
      const remaining = dur - audio.currentTime;
      if (remaining > CROSSFADE_SEC || crossfadeTriggeredRef.current) return;

      crossfadeTriggeredRef.current = true;
      cancelVolumeFade();
      const gen = volumeFadeRef.current.gen;
      const fromVol = clampVolume(audio.volume);
      runVolumeFade(audio, fromVol, 0, CROSSFADE_SEC * 1000, gen, () => {
        setVolumeSafe(audio, 1);
        nextTrackRef.current();
      });
    };

    audio.addEventListener('timeupdate', onTimeUpdate);
    return () => audio.removeEventListener('timeupdate', onTimeUpdate);
  }, [crossfadeEnabled, isPlaying, currentIndex, track?.r2_url, track?.url]);


  // === ЛОГІКА ПЕРЕМИКАННЯ (Shuffle / Repeat) ===
  const nextTrack = () => {
      if (currentPlaylist.length === 0) return;

      // 1. Якщо режим "Повторювати одну"
      if (repeatMode === 'one') {
          audioRef.current.currentTime = 0;
          audioRef.current.play();
          if (!isPlaying) setIsPlaying(true);
          return;
      }

      // 2. Якщо режим "Shuffle"
      if (isShuffle) {
          // Вибираємо випадковий індекс, відмінний від поточного (якщо треків > 1)
          let randomIdx = Math.floor(Math.random() * currentPlaylist.length);
          if (currentPlaylist.length > 1 && randomIdx === currentIndex) {
              randomIdx = (randomIdx + 1) % currentPlaylist.length;
          }
          setCurrentIndex(randomIdx);
          setIsPlaying(true);
          setProgress(0);
          return;
      }

      // 3. Звичайний порядок
      const nextIndex = currentIndex + 1;
      
      if (nextIndex < currentPlaylist.length) {
          // Є наступний трек
          setCurrentIndex(nextIndex);
          setIsPlaying(true);
      } else {
          // Кінець плейлиста
          if (repeatMode === 'all') {
              setCurrentIndex(0); // Зациклюємо
              setIsPlaying(true);
          } else {
              setIsPlaying(false); // Зупиняємось
              setProgress(0);
          }
      }
      setProgress(0);
  };

  useEffect(() => {
    nextTrackRef.current = nextTrack;
  });

  const prevTrack = () => {
      if (currentPlaylist.length === 0) return;
      
      // Якщо слухали більше 3 секунд - повертаємось на початок треку
      if (audioRef.current.currentTime > 3) {
          audioRef.current.currentTime = 0;
          return;
      }

      if (isShuffle) {
           // При шафлі кнопка назад теж може кидати рандомно або просто на попередній
           // Для простоти поки робимо як nextTrack (рандом)
           nextTrack();
           return;
      }

      const newIndex = (currentIndex - 1 + currentPlaylist.length) % currentPlaylist.length;
      setCurrentIndex(newIndex);
      setIsPlaying(true);
      setProgress(0);
  };

  // === НОВІ ФУНКЦІЇ КЕРУВАННЯ ===
  const toggleShuffle = () => setIsShuffle(!isShuffle);
  
  const toggleRepeat = () => {
      const modes = ['off', 'all', 'one'];
      const nextIndex = (modes.indexOf(repeatMode) + 1) % modes.length;
      setRepeatMode(modes[nextIndex]);
  };

  const toggleCrossfade = () => setCrossfadeEnabled((v) => !v);

  // === ПОДІЇ АУДІО ===
  useEffect(() => {
    const audio = audioRef.current;
    const updateProgress = () => { if (!isNaN(audio.currentTime)) setProgress(audio.currentTime); };
    const setAudioDuration = () => { if (!isNaN(audio.duration) && audio.duration !== Infinity) setDuration(audio.duration); };
    
    const handleEnd = () => {
        if (crossfadeTriggeredRef.current) {
            crossfadeTriggeredRef.current = false;
            return;
        }
        console.log("🏁 [Player] Finished.");
        nextTrackRef.current();
    };

    const handleError = () => {
        const error = audioRef.current.error;
        if (error && error.code === 1) return;
        if (!audioRef.current.src || audioRef.current.src === window.location.href) return;
        if (!track?.r2_url && !track?.url) return;
        if (error && (error.code === 3 || error.code === 4)) setIsPlaying(false);
    };

    audio.addEventListener('timeupdate', updateProgress);
    audio.addEventListener('loadedmetadata', setAudioDuration);
    audio.addEventListener('durationchange', setAudioDuration);
    audio.addEventListener('ended', handleEnd);
    audio.addEventListener('error', handleError);

    return () => {
      audio.removeEventListener('timeupdate', updateProgress);
      audio.removeEventListener('loadedmetadata', setAudioDuration);
      audio.removeEventListener('durationchange', setAudioDuration);
      audio.removeEventListener('ended', handleEnd);
      audio.removeEventListener('error', handleError);
    };
  }, [currentPlaylist, isShuffle, repeatMode, currentIndex, track?.r2_url, track?.url]); 

  // ... (УПРАВЛІННЯ - seek, selectTrack тощо без змін) ...
  const togglePlay = () => setIsPlaying(!isPlaying);
  
  const seek = (time) => {
    if (audioRef.current.duration) {
        audioRef.current.currentTime = time;
        setProgress(time);
    }
  };

  const selectTrack = (index) => {
      if (index >= 0 && index < currentPlaylist.length) {
          setCurrentIndex(index);
          setIsPlaying(true);
          setProgress(0);
      }
  };

  const playNewContext = (newTracks, startIndex = 0, seekTo = null) => {
    const tracksToPlay = Array.isArray(newTracks) ? newTracks : [newTracks];
    setCurrentPlaylist(tracksToPlay);
    setCurrentIndex(startIndex);
    setProgress(0);
    setDuration(0);
    setInitialSeek(seekTo);
    setIsPlaying(true);
  };

  const updateTrack = (index, updatedData) => {
      setCurrentPlaylist(prev => {
          const newPl = [...prev];
          if (newPl[index]) newPl[index] = { ...newPl[index], ...updatedData };
          return newPl;
      });
  };

  const reorderPlaylist = (newOrder) => {
      const currentTrackId = currentPlaylist[currentIndex]?.id || currentPlaylist[currentIndex]?.source_id;
      setCurrentPlaylist(newOrder);
      const newIndex = newOrder.findIndex(t => (t.id || t.source_id) === currentTrackId);
      if (newIndex !== -1) setCurrentIndex(newIndex);
  };

  const removeFromQueue = (indexToRemove) => {
      if (indexToRemove === currentIndex) {
          if (currentPlaylist.length > 1) {
             // Тут nextTrack викличемо вручну без логіки шафлу, просто наступний
             const nextIdx = (currentIndex + 1) % currentPlaylist.length;
             setCurrentIndex(nextIdx);
             setCurrentPlaylist(prev => prev.filter((_, i) => i !== indexToRemove));
             // Індекс зміститься, тому треба коригувати
             setCurrentIndex(prev => Math.max(0, prev - 1));
          } else {
             setIsPlaying(false);
             setCurrentPlaylist([]);
             setCurrentIndex(0);
          }
      } else {
          setCurrentPlaylist(prev => prev.filter((_, i) => i !== indexToRemove));
          if (indexToRemove < currentIndex) {
              setCurrentIndex(prev => prev - 1);
          }
      }
  };

  return {
    isPlaying, progress, duration, track, currentIndex, currentPlaylist,
    isShuffle, repeatMode, crossfadeEnabled,
    togglePlay, seek, nextTrack, prevTrack, selectTrack, playNewContext, updateTrack,
    reorderPlaylist, removeFromQueue,
    toggleShuffle, toggleRepeat, toggleCrossfade,
    setCrossfadeEnabled,
  };
}