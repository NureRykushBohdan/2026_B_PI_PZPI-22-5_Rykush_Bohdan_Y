export default {
    // --- SETTINGS ---
    settings_title: "Einstellungen",
    section_general: "Allgemein",
    lang_label: "App-Sprache",
    section_tg: "Telegram-Integration",
    silent_mode: "Stumm-Modus",
    silent_desc: "Musik ohne Ton an den Bot senden",
    section_info: "Info",
    support_chat: "Support-Chat",
    version: "Version",

    // --- NAVIGATION ---
    nav_home: "Startseite",
    nav_overview: "Übersicht",
    nav_library: "Bibliothek",
    nav_playlists: "Playlists",

    // --- HOME ---
    app_title: "HYDRA MUSIC",
    recently_listened: "Zuletzt gehört",
    section_you_may_like: "Das könnte dir gefallen",
    section_library: "Deine Bibliothek",
    folder_favorites: "Favoriten",
    picking_music: "Musik wird ausgewählt...",

    // --- SEARCH & UI ---
    search_placeholder: "Titel suchen...",
    cancel: "Abbrechen",
    loading: "Laden...",
    
    // --- LIBRARY ---
    library_title: "Bibliothek",
    liked_songs: "Lieblingssongs",
    your_playlists: "Deine Playlists",
    no_playlists: "Noch keine Playlists",
    new_playlist: "Neue Playlist",
    create_playlist: "Erstellen",
    playlist_name_placeholder: "Name...",
    playlist_desc_placeholder: "Beschreibung (optional)",
    edit_playlist: "Playlist bearbeiten",
    save_changes: "Speichern",
    delete_playlist: "Endgültig löschen",
    confirm_delete_playlist: "Diese Playlist endgültig löschen?",
    confirm_duplicate_playlist: "Eine Kopie dieser Playlist erstellen?",
    selected: "Ausgewählt",
    tracks_count: "Titel",
    
    // --- PLAYLIST ACTIONS ---
    manage: "Verwalten",
    edit_details: "Name & Beschreibung ändern",
    remove_tracks: "Titel entfernen...",
    share_link: "Link teilen",
    duplicate: "In die Bibliothek duplizieren",
    send_to_telegram: "Auf Telegram hochladen",
    sending: "Wird gesendet...",
    sent: "Gesendet!",
    confirm_action: "Aktion bestätigen",
    music_bot_hint: "Musik wird an den Bot-Chat gesendet.",
    copied: "Kopiert!",

    // --- SORTING ---
    sort_label: "Sortierung",
    sort_date: "Datum",
    sort_title: "Titel",
    sort_artist: "Interpret",

    // --- OVERVIEW ---
    overview_title: "Übersicht",
    find_trends: "Trends finden...",
    trends_section: "Trends",
    genres_section: "Genres",
    coming_soon_text: "Charts, Neuerscheinungen und Empfehlungen kommen bald.",
    
    // New Grid Sections
    section_popular: "Beliebt",
    section_moods_events: "Stimmungen & Events",
    section_all_genres: "Genres",

    // --- CATEGORIES (MOODS & GENRES) ---
    // Popular
    cat_jap_rap: "Japanischer Rap",
    cat_desi_hiphop: "Desi Hip-Hop",
    cat_cpop: "C-Pop",
    cat_brazil_hiphop: "Brasilianischer Hip-Hop",
    cat_classic: "Klassik",
    cat_family: "Für Familien",

    // Moods
    cat_on_road: "Unterwegs",
    cat_party: "Party",
    cat_good_mood: "Gute Laune",
    cat_energy: "Energie-Kick",
    cat_focus: "Fokus",
    cat_relax: "Entspannung",
    cat_romance: "Romantik",
    cat_sleep: "Schlafen",
    cat_sad: "Traurig",
    cat_workout: "Workout",
    cat_gaming: "Gaming",
    cat_winter: "Winter",

    // Genres
    cat_arab: "Arabische Musik",
    cat_african: "Afrikanisch",
    cat_blues: "Blues",
    cat_bollywood: "Bollywood",
    cat_jazz: "Jazz",
    cat_indie_alt: "Indie & Alternative",
    cat_country_americana: "Country & Americana",
    cat_latin: "Lateinamerikanisch",
    cat_metal: "Metal",
    cat_german_hiphop: "Deutschrap",
    cat_reggae: "Reggae & Karibik",
    cat_soundtracks: "Soundtracks",
    cat_dance_electronic: "Dance & Electronic",
    cat_folk: "Folk & Akustik",
    cat_jpop: "J-Pop",
    cat_decades: "Jahrzehnte",
    cat_german_pop: "Deutschpop",
    cat_hiphop: "Hip-Hop",
    cat_kpop: "K-Pop",
    cat_pop: "Pop",
    cat_rnb_soul: "R&B & Soul",
    cat_rock: "Rock",
    cat_schlager: "Schlager",

    // --- PLAYLISTS PAGE ---
    my_media: "Meine Bibliothek",
    playlists_title: "Playlists",
    create_new: "Neu erstellen",

    // --- PLAYER ---
    now_playing: "Aktuelle Wiedergabe",
    search_result: "Suchergebnis",
    quick_start: "Schnellstart",
    btn_similar: "Ähnliche",
    btn_queue: "Warteschlange",

    // --- SEARCH RESULTS ---
    searching_for: "Suche nach",
    type_to_search: "Gib eine Suchanfrage ein und drücke Enter",
    nothing_found: "Nichts gefunden 😔",
    search_results_header: "Suchergebnisse",

    // --- ACTION MENU ---
    action_send_tg: "An Telegram senden (Datei)",
    action_add_playlist: "Zur Playlist hinzufügen",
    action_share: "Teilen",
    action_radio: "Titel-Radio starten",
    action_like: "Zu Favoriten hinzufügen",
    action_unlike: "Aus Favoriten entfernen",
    
    header_add_playlist: "Zur Playlist hinzufügen",
    header_new_playlist: "Neue Playlist",
    hint_enter_name: "Gib einen Namen für die neue Playlist ein.",
    btn_create: "Erstellen",
    no_playlists_short: "Keine Playlists",

    // --- TOASTS ---
    toast_sent_tg: "An Telegram gesendet!",
    toast_send_error: "Fehler beim Senden",
    toast_link_copied: "Link kopiert!",
    toast_copy_error: "Kopieren fehlgeschlagen",
    toast_searching_similar: "Suche ähnliche Titel...",
    toast_radio_creating: "Erstelle Radio... Versuche es in 5s erneut",
    toast_no_similar: "Keine ähnlichen Titel gefunden",
    toast_radio_error: "Fehler beim Starten des Radios",
    toast_added_playlist: "Zur Playlist hinzugefügt!",
    toast_add_error: "Fehler beim Hinzufügen",
    toast_create_error: "Fehler beim Erstellen",

    // --- PLAYLIST DETAILS ---
    author_prefix: "Autor:",
    col_title: "Titel",
    col_album: "Album",
    tracks_suffix: "Titel",

    // --- SIMILAR TRACKS ---
    similar_title: "Ähnliche Titel",
    based_on: "Basierend auf:",
    ai_picking: "KI wählt Musik aus...",
    timeout_error: "Zeitüberschreitung",
    network_error: "Netzwerk- oder API-Fehler",
    no_similar_content: "Keine ähnlichen Titel gefunden",

    // --- QUEUE ---
    queue_title: "Warteschlange",
    queue_empty: "Warteschlange ist leer",

    // === COMPILATIONS PAGE (CompilationsView) ===
    page_compilations: "Zusammenstellungen",
    category_all: "Alle",
    search_playlist_placeholder: "Playlists suchen...",
    
    // Sections
    section_trending: "Im Trend",
    section_fresh: "Neuheiten",
    search_results: "Suchergebnisse",
    found_items: "gefunden",
    
    // Sorting
    sort_newest: "Neueste",
    sort_popular: "Beliebteste",
    sort_oldest: "Älteste",
    
    // Cards & Actions
    unknown_user: "Unbekannt",
    like: "Gefällt mir",
    liked: "Gefällt mir",
    action_clone_playlist: "Zu meiner Bibliothek hinzufügen",
    action_download_telegram: "Auf Telegram herunterladen",
    load_more: "Mehr laden",
    
    // Messages & Errors
    empty_state_title: "Hier ist es noch leer",
    empty_state_desc: "Erstelle die erste öffentliche Playlist!",
    error_clone_failed: "Kopieren der Playlist fehlgeschlagen",
    error_download_failed: "Download konnte nicht gestartet werden",
    download_started_telegram: "Playlist zur Telegram-Warteschlange hinzugefügt!",
    confirm_clone_to_download: "Um diese Playlist herunterzuladen, füge sie zuerst zu deiner Bibliothek hinzu. Jetzt hinzufügen?",

    // hydra-web/src/locales/de.js
    public_playlist: "Öffentlich",
    private_playlist: "Privat",
    public_desc: "Für alle in der Suche sichtbar",
    private_desc: "Nur für dich",

    confirm_delete: "Bist du sicher?",
    play_all: "Alle abspielen",
    page_album: "Album",
    page_artist: "Künstler",
    top_tracks: "Top-Titel",
    section_albums: "Alben",
    similar_artists: "Ähnliche Künstler",
    onboarding_title: "Was gefällt dir?",
    onboarding_subtitle: "Wähle 3–5 Genres für bessere Empfehlungen",
    onboarding_min: "Mindestens 3 Genres wählen",
    onboarding_continue: "Weiter",
    continue_listening: "Weiterhören",
    daily_mix: "Daily Mix",
    section_subscription: "Abonnement",
    subscribe: "Abonnieren",
    current_plan: "Aktueller Plan",
    import_playlist: "Playlist importieren",
    lyrics_title: "Songtext",
    lyrics_not_found: "Songtext nicht verfügbar",
    lyrics_tap_hint: "Zeile antippen zum Springen",
    sleep_timer: "Schlaf-Timer",
    sleep_timer_active: "Timer läuft",
    sleep_timer_desc: "Musik stoppt nach Ablauf des Timers",
    sleep_timer_cancel: "Timer abbrechen",
    crossfade: "Crossfade",
    crossfade_hint: "Sanfter Übergang zwischen Titeln",
    shuffle: "Zufall",
    repeat: "Wiederholen",
    minutes: "Min",
    followers: "Follower",
    following: "folgt",
    follow: "Folgen",
    unfollow: "Entfolgen",
    public_playlists: "Öffentliche Playlists",
};