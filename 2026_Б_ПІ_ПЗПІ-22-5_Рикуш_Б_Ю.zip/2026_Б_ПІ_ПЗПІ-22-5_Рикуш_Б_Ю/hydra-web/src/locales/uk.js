export default {
    // --- НАЛАШТУВАННЯ ---
    settings_title: "Налаштування",
    section_general: "Загальні",
    lang_label: "Мова додатку",
    section_tg: "Інтеграція з Telegram",
    silent_mode: "Тихий режим",
    silent_desc: "Надсилати музику в бот без звуку",
    section_info: "Інфо",
    support_chat: "Чат підтримки",
    version: "Версія",

    // --- НАВІГАЦІЯ ---
    nav_home: "Головна",
    nav_overview: "Огляд",
    nav_library: "Медіатека",
    nav_playlists: "Плейлисти",

    // --- ГОЛОВНА ---
    app_title: "HYDRA MUSIC",
    recently_listened: "Ви недавно слухали",
    section_you_may_like: "Вам може сподобатись",
    section_library: "Ваша медіатека",
    folder_favorites: "Улюблене",
    picking_music: "Підбираємо музику...",

    // --- ПОШУК ТА UI ---
    search_placeholder: "Пошук треків...",
    cancel: "Скасувати",
    loading: "Завантаження...",
    
    // --- БІБЛІОТЕКА ---
    library_title: "Медіатека",
    liked_songs: "Улюблені пісні",
    your_playlists: "Ваші плейлисти",
    no_playlists: "Плейлистів ще немає",
    new_playlist: "Новий плейлист",
    create_playlist: "Створити",
    playlist_name_placeholder: "Назва...",
    playlist_desc_placeholder: "Опис (необов'язково)",
    edit_playlist: "Редагувати плейлист",
    save_changes: "Зберегти",
    delete_playlist: "Видалити назавжди",
    confirm_delete_playlist: "Видалити цей плейлист назавжди?",
    confirm_duplicate_playlist: "Створити копію цього плейлиста?",
    selected: "Вибрано",
    tracks_count: "треків",
    
    // --- ДІЇ З ПЛЕЙЛИСТОМ ---
    manage: "Керування",
    edit_details: "Змінити назву та опис",
    remove_tracks: "Видалити треки...",
    share_link: "Поділитися посиланням",
    duplicate: "Дублювати в медіатеку",
    send_to_telegram: "Завантажити в Telegram",
    sending: "Надсилання...",
    sent: "Надіслано!",
    confirm_action: "Підтвердити дію",
    music_bot_hint: "Музика буде надіслана в чат з ботом.",
    copied: "Скопійовано!",

    // --- СОРТУВАННЯ ---
    sort_label: "Сортування",
    sort_date: "Дата",
    sort_title: "Назва",
    sort_artist: "Виконавець",

    // --- ОГЛЯД (OVERVIEW) ---
    overview_title: "Огляд",
    find_trends: "Знайти тренди...",
    trends_section: "Тренди",
    genres_section: "Жанри",
    coming_soon_text: "Чарти, новинки та рекомендації вже скоро.",
    
    // Нові секції для сітки
    section_popular: "Популярне",
    section_moods_events: "Настрої та події",
    section_all_genres: "Жанри",

    // --- КАТЕГОРІЇ (MOODS & GENRES) ---
    // Популярне
    cat_jap_rap: "Японський реп",
    cat_desi_hiphop: "Хіп-хоп дезі",
    cat_cpop: "Китайськомовна поп-музика",
    cat_brazil_hiphop: "Бразильський хіп-хоп",
    cat_classic: "Класика",
    cat_family: "Для сім'ї",

    // Настрої
    cat_on_road: "В дорозі",
    cat_party: "Вечірка",
    cat_good_mood: "Гарний настрій",
    cat_energy: "Заряд енергії",
    cat_focus: "Зосередження",
    cat_relax: "Релакс",
    cat_romance: "Романтика",
    cat_sleep: "Сон",
    cat_sad: "Сум",
    cat_workout: "Тренування",
    cat_gaming: "Геймінг",
    cat_winter: "Зима",

    // Жанри
    cat_arab: "Арабська музика",
    cat_african: "Африканська",
    cat_blues: "Блюз",
    cat_bollywood: "Боллівуд",
    cat_jazz: "Джаз",
    cat_indie_alt: "Інді й альтернатива",
    cat_country_americana: "Кантрі та Американа",
    cat_latin: "Латинська",
    cat_metal: "Метал",
    cat_german_hiphop: "Німецький хіп-хоп",
    cat_reggae: "Регі й карибська",
    cat_soundtracks: "Саундтреки",
    cat_dance_electronic: "Танцювальна й електронна",
    cat_folk: "Фолк і народна",
    cat_jpop: "Японська поп-музика",
    cat_decades: "Хіти десятиліть",
    cat_german_pop: "Німецький поп",
    cat_hiphop: "Хіп-хоп",
    cat_kpop: "K-Pop",
    cat_pop: "Поп",
    cat_rnb_soul: "R&B та соул",
    cat_rock: "Рок",
    cat_schlager: "Шлягер",

    // --- СТОРІНКА ПЛЕЙЛИСТІВ ---
    my_media: "Моя медіатека",
    playlists_title: "Плейлисти",
    create_new: "Створити",

    // --- ПЛЕЄР ---
    now_playing: "Зараз грає",
    search_result: "Результат пошуку",
    quick_start: "Швидкий старт",
    btn_similar: "Схожі",
    btn_queue: "Черга",

    // --- РЕЗУЛЬТАТИ ПОШУКУ ---
    searching_for: "Шукаємо",
    type_to_search: "Введіть запит та натисніть Enter",
    nothing_found: "Нічого не знайдено 😔",
    search_results_header: "Результати пошуку",

    // --- МЕНЮ ДІЙ ---
    action_send_tg: "Надіслати в Telegram (Файл)",
    action_add_playlist: "Додати в плейлист",
    action_share: "Поділитися",
    action_radio: "Запустити радіо треку",
    action_like: "Додати в улюблене",
    action_unlike: "Видалити з улюбленого",
    
    header_add_playlist: "Додати в плейлист",
    header_new_playlist: "Новий плейлист",
    hint_enter_name: "Введіть назву для нового плейлиста.",
    btn_create: "Створити",
    no_playlists_short: "Немає плейлистів",

    // --- ПОВІДОМЛЕННЯ (TOASTS) ---
    toast_sent_tg: "Надіслано в Telegram!",
    toast_send_error: "Помилка надсилання",
    toast_link_copied: "Посилання скопійовано!",
    toast_copy_error: "Не вдалося скопіювати",
    toast_searching_similar: "Шукаємо схожі треки...",
    toast_radio_creating: "Створюємо радіо... Спробуйте через 5с",
    toast_no_similar: "Схожих треків не знайдено",
    toast_radio_error: "Помилка запуску радіо",
    toast_added_playlist: "Додано в плейлист!",
    toast_add_error: "Помилка додавання",
    toast_create_error: "Помилка створення",

    // --- ДЕТАЛІ ПЛЕЙЛИСТА ---
    author_prefix: "Автор:",
    col_title: "Назва",
    col_album: "Альбом",
    tracks_suffix: "тр.",

    // --- СХОЖІ ТРЕКИ ---
    similar_title: "Схожі треки",
    based_on: "На основі:",
    ai_picking: "ШІ підбирає музику...",
    timeout_error: "Час очікування вийшов",
    network_error: "Помилка мережі або API",
    no_similar_content: "Схожих треків не знайдено",

    // --- ЧЕРГА ---
    queue_title: "Черга відтворення",
    queue_empty: "Черга порожня",

    // === СТОРІНКА ПІДБІРКИ (CompilationsView) ===
    page_compilations: "Підбірки",
    category_all: "Всі",
    search_playlist_placeholder: "Пошук плейлистів...",
    
    // Секції
    section_trending: "У тренді",
    section_fresh: "Новинки",
    search_results: "Результати пошуку",
    found_items: "знайдено",
    
    // Сортування
    sort_newest: "Новинки",
    sort_popular: "Популярні",
    sort_oldest: "Старі",
    
    // Картка та дії
    unknown_user: "Невідомий",
    like: "Вподобати",
    liked: "Вподобано",
    action_clone_playlist: "Додати до моєї медіатеки",
    action_download_telegram: "Завантажити в Telegram",
    load_more: "Завантажити ще",
    
    // Повідомлення та помилки
    empty_state_title: "Тут поки порожньо",
    empty_state_desc: "Створіть перший публічний плейлист!",
    error_clone_failed: "Не вдалося скопіювати плейлист",
    error_download_failed: "Не вдалося розпочати завантаження",
    download_started_telegram: "Плейлист надіслано в чергу завантаження Telegram!",
    confirm_clone_to_download: "Щоб завантажити цей плейлист, спочатку додайте його до своєї медіатеки. Додати зараз?",

    // hydra-web/src/locales/uk.js
    public_playlist: "Публічний",
    private_playlist: "Приватний",
    public_desc: "Видно всім у пошуку",
    private_desc: "Тільки для вас",

    confirm_delete: "Ви впевнені?",
    play_all: "Почати відтворення",
    page_album: "Альбом",
    page_artist: "Артист",
    top_tracks: "Топ-треки",
    section_albums: "Альбоми",
    similar_artists: "Схожі артисти",
    onboarding_title: "Що вам подобається?",
    onboarding_subtitle: "Оберіть 3–5 жанрів для кращих рекомендацій",
    onboarding_min: "Оберіть щонайменше 3 жанри",
    onboarding_continue: "Продовжити",
    continue_listening: "Продовжити слухати",
    daily_mix: "Мікс дня",
    section_subscription: "Підписка",
    subscribe: "Оформити",
    current_plan: "Поточний план",
    import_playlist: "Імпорт плейлиста",
    lyrics_title: "Текст пісні",
    lyrics_not_found: "Текст недоступний",
    lyrics_tap_hint: "Натисніть рядок, щоб перемотати",
    sleep_timer: "Таймер сну",
    sleep_timer_active: "Таймер активний",
    sleep_timer_desc: "Музика зупиниться після закінчення часу",
    sleep_timer_cancel: "Скасувати таймер",
    crossfade: "Crossfade",
    crossfade_hint: "Плавний перехід між треками (затухання / наростання)",
    shuffle: "Перемішати",
    repeat: "Повтор",
    minutes: "хв",
    followers: "підписників",
    following: "підписок",
    follow: "Підписатися",
    unfollow: "Відписатися",
    public_playlists: "Публічні плейлисти",
};