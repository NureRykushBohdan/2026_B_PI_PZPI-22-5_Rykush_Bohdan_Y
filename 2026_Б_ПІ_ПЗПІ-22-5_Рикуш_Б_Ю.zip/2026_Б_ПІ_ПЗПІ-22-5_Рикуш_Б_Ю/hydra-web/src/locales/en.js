export default {
    // --- SETTINGS ---
    settings_title: "Settings",
    section_general: "General",
    lang_label: "App Language",
    section_tg: "Telegram Integration",
    silent_mode: "Silent Mode",
    silent_desc: "Send music to bot without sound",
    section_info: "Info",
    support_chat: "Support Chat",
    version: "Version",

    // --- NAVIGATION ---
    nav_home: "Home",
    nav_overview: "Overview",
    nav_library: "Library",
    nav_playlists: "Playlists",

    // --- HOME ---
    app_title: "HYDRA MUSIC",
    recently_listened: "Recently Listened",
    section_you_may_like: "You Might Like",
    section_library: "Your Library",
    folder_favorites: "Favorites",
    picking_music: "Picking music...",

    // --- SEARCH & UI ---
    search_placeholder: "Search tracks...",
    cancel: "Cancel",
    loading: "Loading...",
    
    // --- LIBRARY ---
    library_title: "Library",
    liked_songs: "Liked Songs",
    your_playlists: "Your Playlists",
    no_playlists: "No playlists yet",
    new_playlist: "New Playlist",
    create_playlist: "Create",
    playlist_name_placeholder: "Name...",
    playlist_desc_placeholder: "Description (optional)",
    edit_playlist: "Edit Playlist",
    save_changes: "Save",
    delete_playlist: "Delete Forever",
    confirm_delete_playlist: "Delete this playlist forever?",
    confirm_duplicate_playlist: "Create a copy of this playlist?",
    selected: "Selected",
    tracks_count: "tracks",
    
    // --- PLAYLIST ACTIONS ---
    manage: "Manage",
    edit_details: "Edit Name & Description",
    remove_tracks: "Remove Tracks...",
    share_link: "Share Link",
    duplicate: "Duplicate to Library",
    send_to_telegram: "Upload to Telegram",
    sending: "Sending...",
    sent: "Sent!",
    confirm_action: "Confirm Action",
    music_bot_hint: "Music will be sent to the bot chat.",
    copied: "Copied!",

    // --- SORTING ---
    sort_label: "Sort By",
    sort_date: "Date",
    sort_title: "Title",
    sort_artist: "Artist",

    // --- OVERVIEW ---
    overview_title: "Overview",
    find_trends: "Find trends...",
    trends_section: "Trends",
    genres_section: "Genres",
    coming_soon_text: "Charts, new releases, and recommendations coming soon.",
    
    // New Grid Sections
    section_popular: "Popular",
    section_moods_events: "Moods & Events",
    section_all_genres: "Genres",

    // --- CATEGORIES (MOODS & GENRES) ---
    // Popular
    cat_jap_rap: "Japanese Rap",
    cat_desi_hiphop: "Desi Hip-Hop",
    cat_cpop: "C-Pop",
    cat_brazil_hiphop: "Brazilian Hip-Hop",
    cat_classic: "Classical",
    cat_family: "Family",

    // Moods
    cat_on_road: "On the Road",
    cat_party: "Party",
    cat_good_mood: "Good Mood",
    cat_energy: "Energy Boost",
    cat_focus: "Focus",
    cat_relax: "Relax",
    cat_romance: "Romance",
    cat_sleep: "Sleep",
    cat_sad: "Sad",
    cat_workout: "Workout",
    cat_gaming: "Gaming",
    cat_winter: "Winter",

    // Genres
    cat_arab: "Arab Music",
    cat_african: "African",
    cat_blues: "Blues",
    cat_bollywood: "Bollywood",
    cat_jazz: "Jazz",
    cat_indie_alt: "Indie & Alternative",
    cat_country_americana: "Country & Americana",
    cat_latin: "Latin",
    cat_metal: "Metal",
    cat_german_hiphop: "German Hip-Hop",
    cat_reggae: "Reggae & Caribbean",
    cat_soundtracks: "Soundtracks",
    cat_dance_electronic: "Dance & Electronic",
    cat_folk: "Folk & Acoustic",
    cat_jpop: "J-Pop",
    cat_decades: "Decades",
    cat_german_pop: "German Pop",
    cat_hiphop: "Hip-Hop",
    cat_kpop: "K-Pop",
    cat_pop: "Pop",
    cat_rnb_soul: "R&B & Soul",
    cat_rock: "Rock",
    cat_schlager: "Schlager",

    // --- PLAYLISTS PAGE ---
    my_media: "My Library",
    playlists_title: "Playlists",
    create_new: "Create New",

    // --- PLAYER ---
    now_playing: "Now Playing",
    search_result: "Search Result",
    quick_start: "Quick Start",
    btn_similar: "Similar",
    btn_queue: "Queue",

    // --- SEARCH RESULTS ---
    searching_for: "Searching for",
    type_to_search: "Type a query and press Enter",
    nothing_found: "Nothing found 😔",
    search_results_header: "Search Results",

    // --- ACTION MENU ---
    action_send_tg: "Send to Telegram (File)",
    action_add_playlist: "Add to Playlist",
    action_share: "Share",
    action_radio: "Start Track Radio",
    action_like: "Add to Favorites",
    action_unlike: "Remove from Favorites",
    
    header_add_playlist: "Add to Playlist",
    header_new_playlist: "New Playlist",
    hint_enter_name: "Enter a name for the new playlist.",
    btn_create: "Create",
    no_playlists_short: "No Playlists",

    // --- TOASTS ---
    toast_sent_tg: "Sent to Telegram!",
    toast_send_error: "Sending Error",
    toast_link_copied: "Link Copied!",
    toast_copy_error: "Failed to Copy",
    toast_searching_similar: "Searching for similar tracks...",
    toast_radio_creating: "Creating radio... Try again in 5s",
    toast_no_similar: "No similar tracks found",
    toast_radio_error: "Radio Launch Error",
    toast_added_playlist: "Added to Playlist!",
    toast_add_error: "Addition Error",
    toast_create_error: "Creation Error",

    // --- PLAYLIST DETAILS ---
    author_prefix: "Author:",
    col_title: "Title",
    col_album: "Album",
    tracks_suffix: "tr.",

    // --- SIMILAR TRACKS ---
    similar_title: "Similar Tracks",
    based_on: "Based on:",
    ai_picking: "AI is picking music...",
    timeout_error: "Timeout exceeded",
    network_error: "Network or API Error",
    no_similar_content: "No similar tracks found",

    // --- QUEUE ---
    queue_title: "Play Queue",
    queue_empty: "Queue is empty",

    // === COMPILATIONS PAGE (CompilationsView) ===
    page_compilations: "Compilations",
    category_all: "All",
    search_playlist_placeholder: "Search playlists...",
    
    // Sections
    section_trending: "Trending",
    section_fresh: "New Arrivals",
    search_results: "Search Results",
    found_items: "found",
    
    // Sorting
    sort_newest: "Newest",
    sort_popular: "Popular",
    sort_oldest: "Oldest",
    
    // Cards & Actions
    unknown_user: "Unknown",
    like: "Like",
    liked: "Liked",
    action_clone_playlist: "Add to My Library",
    action_download_telegram: "Download to Telegram",
    load_more: "Load More",
    
    // Messages & Errors
    empty_state_title: "It's empty here",
    empty_state_desc: "Create the first public playlist!",
    error_clone_failed: "Failed to copy playlist",
    error_download_failed: "Failed to start download",
    download_started_telegram: "Playlist sent to Telegram download queue!",
    confirm_clone_to_download: "To download this playlist, first add it to your library. Add now?",

    // hydra-web/src/locales/en.js
    public_playlist: "Public",
    private_playlist: "Private",
    public_desc: "Visible to everyone in search",
    private_desc: "Only for you",

    confirm_delete: "Are you sure?",
    play_all: "Play All",
    page_album: "Album",
    page_artist: "Artist",
    top_tracks: "Top Tracks",
    section_albums: "Albums",
    similar_artists: "Similar Artists",
    onboarding_title: "What do you like?",
    onboarding_subtitle: "Pick 3–5 genres for better recommendations",
    onboarding_min: "Select at least 3 genres",
    onboarding_continue: "Continue",
    continue_listening: "Continue Listening",
    daily_mix: "Daily Mix",
    section_subscription: "Subscription",
    subscribe: "Subscribe",
    current_plan: "Current Plan",
    import_playlist: "Import Playlist",
    lyrics_title: "Lyrics",
    lyrics_not_found: "Lyrics not available",
    lyrics_tap_hint: "Tap a line to jump",
    sleep_timer: "Sleep Timer",
    sleep_timer_active: "Timer running",
    sleep_timer_desc: "Music stops when the timer ends",
    sleep_timer_cancel: "Cancel timer",
    crossfade: "Crossfade",
    crossfade_hint: "Smooth transition between tracks (fade out / fade in)",
    shuffle: "Shuffle",
    repeat: "Repeat",
    minutes: "min",
    followers: "followers",
    following: "following",
    follow: "Follow",
    unfollow: "Unfollow",
    public_playlists: "Public Playlists",
};