// hydra-web/src/config.js
import axios from 'axios';

const viteApi = (import.meta.env.VITE_API_URL ?? '').toString().trim();

/**
 * API origin. Prefer `VITE_API_URL` in hydra-web/.env (see .env.example).
 * - Production: leave unset to use same-origin `/api` (reverse proxy).
 * - Development: leave unset to use Vite proxy (see vite.config.js) to your local API.
 */
export const API_BASE_URL = viteApi || (import.meta.env.DEV ? '' : '');

export const DEV_USER_ID = 871451920;
const AUTH_DEBUG = (import.meta.env.VITE_AUTH_DEBUG ?? 'false').toString() === 'true';

// Створюємо налаштований екземпляр axios
export const apiClient = axios.create({
    baseURL: API_BASE_URL
});

// Додаємо "перехоплювач" (Interceptor)
// Він спрацьовує перед кожним запитом
apiClient.interceptors.request.use((config) => {
    let authData = null;

    const initData = window.Telegram?.WebApp?.initData?.trim?.() ?? '';
    if (initData) {
        authData = initData;
    } else if (AUTH_DEBUG) {
        // Browser testing without real Telegram initData (VITE_AUTH_DEBUG=true).
        authData = DEV_USER_ID.toString();
    }

    // Додаємо заголовок лише якщо є реальне/дебагове значення
    if (authData) {
        config.headers['X-Telegram-Data'] = authData;
    }
    
    return config;
});

// Global 401 handling for UI-level reactions (logout/redirect/toast)
apiClient.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error?.response?.status === 401) {
            window.dispatchEvent(new CustomEvent('hydra:unauthorized'));
        }
        return Promise.reject(error);
    }
);