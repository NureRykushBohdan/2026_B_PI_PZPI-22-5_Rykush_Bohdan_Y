/** Parse LRC synced lyrics into [{ time (seconds), text }] */
const TAG_RE = /\[(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\]/g;

function tagsToSeconds(min, sec, frac) {
  const ms = frac ? parseInt(frac.padEnd(3, '0').slice(0, 3), 10) / 1000 : 0;
  return parseInt(min, 10) * 60 + parseInt(sec, 10) + ms;
}

export function parseLrc(lrcText) {
  if (!lrcText || typeof lrcText !== 'string') return [];

  const result = [];
  for (const rawLine of lrcText.split('\n')) {
    const line = rawLine.trim();
    if (!line) continue;

    const times = [];
    let m;
    TAG_RE.lastIndex = 0;
    while ((m = TAG_RE.exec(line)) !== null) {
      times.push(tagsToSeconds(m[1], m[2], m[3]));
    }

    const text = line.replace(/\[(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\]/g, '').trim();
    if (!text) continue;

    if (times.length === 0) {
      continue;
    }
    for (const time of times) {
      result.push({ time, text });
    }
  }

  result.sort((a, b) => a.time - b.time);
  return result;
}

/** Evenly distribute plain lyrics when no timestamps available */
export function plainToSyncedLines(plainText, durationSec) {
  const lines = plainText
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);
  if (lines.length === 0) return [];

  const dur = durationSec && durationSec > 0 ? durationSec : lines.length * 3;
  const step = dur / lines.length;

  return lines.map((text, i) => ({
    time: i * step,
    text,
  }));
}

export function findActiveLineIndex(lines, progressSec) {
  if (!lines.length) return -1;
  let idx = 0;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].time <= progressSec + 0.05) {
      idx = i;
    } else {
      break;
    }
  }
  return idx;
}

export function hasLrcTimestamps(text) {
  return /\[(\d{1,2}):(\d{2})(?:\.\d{1,3})?\]/.test(text || '');
}
