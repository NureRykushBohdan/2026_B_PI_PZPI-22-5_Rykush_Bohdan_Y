import { apiClient } from '../config';

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export async function fetchWithAsyncContract(endpoint, options = {}) {
  const maxAttempts = options.maxAttempts ?? 30;
  const defaultRetryAfterMs = options.defaultRetryAfterMs ?? 2000;

  const first = await apiClient.get(endpoint);
  if (first.status !== 202) return first.data;

  const pollPath = first.data?.poll_path;
  const requestId = first.data?.request_id;
  if (!pollPath || !requestId) return first.data;

  let attempt = 0;
  let retryAfterMs =
    Number(first.data?.retry_after ?? defaultRetryAfterMs / 1000) * 1000;

  while (attempt < maxAttempts) {
    await sleep(Math.max(300, retryAfterMs));
    const poll = await apiClient.get(pollPath);
    const data = poll.data || {};
    if (data.status === 'ready') return data;
    retryAfterMs =
      Number(data.retry_after ?? defaultRetryAfterMs / 1000) * 1000;
    attempt += 1;
  }

  throw new Error(`Async API timeout for ${endpoint}`);
}
