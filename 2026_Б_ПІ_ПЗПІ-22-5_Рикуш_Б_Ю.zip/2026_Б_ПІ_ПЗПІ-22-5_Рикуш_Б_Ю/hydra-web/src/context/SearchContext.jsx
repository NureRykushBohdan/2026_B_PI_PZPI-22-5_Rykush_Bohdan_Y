import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
// ✅ Імпортуємо тільки apiClient
import { apiClient, API_BASE_URL } from '../config';

const SearchContext = createContext();

export const useSearch = () => useContext(SearchContext);

export const SearchProvider = ({ children }) => {
    const [isSearchOpen, setIsSearchOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState([]);
    const [page, setPage] = useState(1);
    const [hasMore, setHasMore] = useState(true);
    const [isLoadingSearch, setIsLoadingSearch] = useState(false);
    const [isLoadingMore, setIsLoadingMore] = useState(false);
    const [hasSearched, setHasSearched] = useState(false);

    const [searchHistory, setSearchHistory] = useState(() => {
        try {
            const saved = localStorage.getItem('hydra_search_history');
            return saved ? JSON.parse(saved) : [];
        } catch {
            return [];
        }
    });

    useEffect(() => {
        localStorage.setItem('hydra_search_history', JSON.stringify(searchHistory));
    }, [searchHistory]);

    const addToHistory = (query) => {
        setSearchHistory(prev => {
            const newHistory = [query, ...prev.filter(item => item !== query)];
            return newHistory.slice(0, 10);
        });
    };

    const removeFromHistory = (query) => {
        setSearchHistory(prev => prev.filter(item => item !== query));
    };

    // --- ФУНКЦІЯ ПОШУКУ ---
    const runSearch = useCallback(async (query) => {
        if (!query || query.trim().length < 2) return [];
        
        setIsLoadingSearch(true);
        setHasSearched(true);
        setSearchResults([]);
        setPage(1);
        setHasMore(true);
        addToHistory(query);

        try {
            console.log(`[Search] Connecting to: ${API_BASE_URL}`);
            // ✅ Використовуємо apiClient без user_id
            const response = await apiClient.get('/api/search', {
                params: { query, page: 1, limit: 10 },
                timeout: 15000 
            });
            setSearchResults(response.data);
            return response.data;
        } catch (error) {
            console.error("❌ Search Error:", error);
            setSearchResults([]);
            return [];
        } finally {
            setIsLoadingSearch(false);
        }
    }, []);

    // --- ФУНКЦІЯ ДОВАНТАЖЕННЯ ---
    const loadMoreResults = useCallback(async () => {
        if (isLoadingMore || !hasMore || !searchQuery) return;
        setIsLoadingMore(true);

        try {
            const nextPage = page + 1;
            // ✅ Використовуємо apiClient
            const response = await apiClient.get('/api/search', {
                params: { query: searchQuery, page: nextPage, limit: 10 },
                timeout: 15000 
            });

            if (response.data.length === 0) {
                setHasMore(false);
            } else {
                setSearchResults(prev => {
                    const newTracks = response.data.filter(
                        newTrack => !prev.some(existing => existing.id === newTrack.id)
                    );
                    return [...prev, ...newTracks];
                });
                setPage(nextPage);
            }
        } catch (error) {
            console.error("❌ Load More Error:", error);
        } finally {
            setIsLoadingMore(false);
        }
    }, [page, searchQuery, hasMore, isLoadingMore]);

    // --- ФУНКЦІЯ ЗАВАНТАЖЕННЯ ТРЕКУ ---
    const initiateDownload = useCallback(async (track) => {
        if (!track) return { status: 'ERROR', message: 'No track data' };

        const trackId = track.id || track.source_id; 
        console.log(`🎵 Preparing track: ${trackId}`);

        try {
            // ✅ Використовуємо apiClient без user_id
            const response = await apiClient.get(`/api/track/${trackId}`);

            if (response.status === 200) {
                return { status: 'READY', data: response.data };
            }
        } catch (error) {
            if (error.response && error.response.status === 202) {
                return { status: 'QUEUED', message: 'Downloading...' };
            }
            console.error("❌ Init Download Error:", error);
            return { status: 'ERROR', message: 'Network error' };
        }
    }, []);

    const closeSearch = () => {
        setIsSearchOpen(false);
    };

    const value = {
        isSearchOpen, setIsSearchOpen,
        searchQuery, setSearchQuery,
        searchResults, isLoadingSearch, isLoadingMore,
        hasSearched, searchHistory,     
        removeFromHistory, runSearch, loadMoreResults,
        closeSearch, initiateDownload
    };

    return <SearchContext.Provider value={value}>{children}</SearchContext.Provider>;
};