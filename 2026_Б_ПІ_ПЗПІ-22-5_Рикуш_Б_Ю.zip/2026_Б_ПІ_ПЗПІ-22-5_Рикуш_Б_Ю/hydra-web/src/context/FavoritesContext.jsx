import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
// ✅ Імпорт клієнта
import { apiClient, API_BASE_URL } from '../config';

const FavoritesContext = createContext();

export const useFavorites = () => useContext(FavoritesContext);

export const FavoritesProvider = ({ children }) => {
    const [likedTracks, setLikedTracks] = useState([]);

    const likedTrackIds = useMemo(() => {
        return new Set(likedTracks.map(t => t.id || t.source_id));
    }, [likedTracks]);

    useEffect(() => {
        const fetchFavorites = async () => {
            try {
                // ✅ apiClient підставить токен автоматично
                const response = await apiClient.get('/api/favorites');
                console.log("✅ [Favorites] Loaded:", response.data.length, "tracks");
                setLikedTracks(response.data);
            } catch (error) {
                console.error("❌ [Favorites] Failed load:", error);
            }
        };
        fetchFavorites();
    }, []);

    const toggleFavorite = useCallback(async (track) => {
        if (!track) return;
        const trackId = track.id || track.source_id;

        setLikedTracks(prev => {
            const exists = prev.find(t => (t.id || t.source_id) === trackId);
            if (exists) {
                return prev.filter(t => (t.id || t.source_id) !== trackId);
            } else {
                return [track, ...prev];
            }
        });

        try {
            // ✅ apiClient
            await apiClient.post(`/api/like/${trackId}`, null, {
                params: { 
                    // user_id більше не потрібен!
                    title: track.title,
                    artist: track.artist,
                    duration: typeof track.duration === 'string' ? 0 : track.duration
                }
            });
        } catch (error) {
            console.error("Like error:", error);
        }
    }, []);

    const isFavorite = useCallback((trackId) => {
        return likedTrackIds.has(trackId);
    }, [likedTrackIds]);

    return (
        <FavoritesContext.Provider value={{ likedTracks, toggleFavorite, isFavorite }}>
            {children}
        </FavoritesContext.Provider>
    );
};